import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CertFiletrackerEditComponent } from './cert-filetracker-edit.component';



// describe('CertFiletrackerEditComponent', () => {
//   let component: CertFiletrackerEditComponent;
//   let fixture: ComponentFixture<CertFiletrackerEditComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ CertFiletrackerEditComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(CertFiletrackerEditComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });

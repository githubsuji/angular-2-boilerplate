// /** Angular Modules */
import { Component, OnInit, ViewChild, ElementRef, Inject, ViewEncapsulation } from '@angular/core';

// /** Angular Material */
import { MatTableDataSource, MatPaginator, MatSort, MatSnackBar, MatExpansionPanel } from '@angular/material';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { PPMESearchModel } from '../../../model/ppmembereligibility/PPMESearchModel';
import { MemberEligibilityService } from '../../../business/modules/service/ppmembereligibility/MemberEligibilityService';
import { MemberEligibilityRestClient } from '../../../business/modules/provider/ppmembereligibility/MemberEligibilityRestClient';
import { AuthorizedPermissionInformationModel } from '../../../model/user/AuthorizedPermissionInformation';
import { UserModel } from '../../../model/user/UserModel';
import { AuthService } from '../../../business/modules/service/authentication/AuthService';
import { ReplaySubject, Subject, Subscription } from 'rxjs/';
import { takeUntil } from 'rxjs/operators';
import { PPMEDropDownModel } from '../../../model/ppmembereligibility/PPMEDropDownModel';
import * as moment from 'moment';
import { PPDownloadReqModel } from '../../../model/ppFilterSearch/PPDownloadReqModel';

@Component({
    selector: 'member-eligibility',
    templateUrl: './MemberEligibility.html',
    styleUrls: ['./MemberEligibility.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class MemberEligibilityComponent implements OnInit {

    busy: Subscription;
    selectedSearchValue: string;
    isEnableSearchResult: Boolean = false;
    mPanelOpenState: Boolean = false;
    fPanelOpenState: Boolean = false;
    isEnableFilterSelection: Boolean = false;
    filterSelectionForm: FormGroup;
    memberIdForm: FormGroup;

    filterValueList: PPMEDropDownModel[];
    searchModel: PPMESearchModel;
    downloadReq: PPDownloadReqModel;
    isEnableMemberId: Boolean = false;

    sort: any;
    loggedInUser: UserModel;
    memberEligibilityService: MemberEligibilityService;
    memberEligibilityRestClient: MemberEligibilityRestClient;
    authService: AuthService;

    transactions: any;
    messages: string;
    totalPageCount: any;
    totalPageCountArray: Array<any>;
    selectedPageCount: any;
    searchMaxLimit: number = 1000;
    totalCount: any;
    downloadRange: number = 1000;


    selectedSourceSystem: PPMEDropDownModel;
    public sourceSystemCtrl: FormControl = new FormControl();
    winHeight: string = '';
    tableHeight: string = '';

    private _onDestroy = new Subject<void>();
    public filteredSourceSystemList: ReplaySubject<PPMEDropDownModel[]> = new ReplaySubject<PPMEDropDownModel[]>(1);

    cols = ['sourceSystem', 'contractorFamilyID', 'status', 'participantFirstName',
            'participantMiddleName', 'participantLastName', 'dateofBirth',
            'participantEffectiveDate', 'participantExpirationDate', 'clientGroupID',
             'clientId', 'cMSPlanBenefitPackageID', 'clientPlanType', 'primaryCarrierFlag', 'loadDate'];


    // fileDataSource = new MatTableDataSource<DT_Model>(DT_MODEL_DATA);
    fileDataSource: any;

    @ViewChild('panel1') firstPanel: MatExpansionPanel;
    @ViewChild('panel2') secondPanel: MatExpansionPanel;
    @ViewChild(MatPaginator) paginator: MatPaginator;

    @ViewChild(MatSort) set content(content: ElementRef) {
        this.sort = content;
        if (this.sort) {
            this.fileDataSource.sort = this.sort;

        }
    }


    constructor(@Inject(ElementRef) private elRef, private snackBar: MatSnackBar,
        authService: AuthService, private formBuilder: FormBuilder,
        memberEligibilityService: MemberEligibilityService) {
        this.memberEligibilityService = memberEligibilityService;
        this.authService = authService;

    }
    ngOnInit() {

        this.selectedSourceSystem = PPMEDropDownModel.newInstance();
        this.downloadReq = PPDownloadReqModel.newInstance();
        this.loggedInUser = UserModel.newInstance();
        this.loggedInUser.userId = localStorage.getItem('userId');
        this.loggedInUser.userGroup = localStorage.getItem('userRole');
        this.loadFilterValues();


        const resourceCode = 'SCR018';
        this.authService.getUserGroupPermissions(this.loggedInUser.userId, resourceCode).subscribe(data => {
            const permissionModel = <AuthorizedPermissionInformationModel>data;

        });

        this.searchModel = PPMESearchModel.newInstance();
        const f = this.searchModel;

        // memberId formBuilder
        this.memberIdForm = this.formBuilder.group({
            memberId: new FormControl({ value: f.memberID }, [Validators.required])
        });
        // Filter selection FormBuilder
        this.filterSelectionForm = this.formBuilder.group({
            participantFirstName: new FormControl({ value: f.firstName },
                [Validators.required]),
            middleName: new FormControl({ value: f.middleName }),
            lastName: new FormControl({ value: f.lastName },
                [Validators.required]),
            dobDatePicker: new FormControl({ value: f.dateOfBirth },
                [Validators.required]),
            // fileSendDate: new FormControl({ value: f.fileSendDate }),
            sourceSystem: new FormControl({ value: f.sourceSystem })
        });


        this.sourceSystemCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList,
                    this.filteredSourceSystemList,
                    this.sourceSystemCtrl
                );

            });

    }

    protected filterValues(parentList, displayList, dropDownCtrl) {
        if (!this.filterValueList) {
            return;
        }
        // get the search keyword
        let search = dropDownCtrl.value;
        if (!search) {
            displayList.next(parentList.slice());
            return;
        } else {
            search = search.toLowerCase();
        }
        // filter the values
        displayList.next(
            parentList.filter(x => {
                if (x && x.name) {
                    return ((x.name).toLowerCase().indexOf(search) > -1);
                }
            })
        );
    }

    // ngAfterViewInit(): void {
    //      this.fileDataSource.sort = this.sort;
    // }



    public hasError = (controlName: string, errorName: string) => {   //Validation of fields
        if (controlName === 'memberId') {
            return this.memberIdForm.controls[controlName].hasError(errorName);
        } else {
            return this.filterSelectionForm.controls[controlName].hasError(errorName);
        }

    }



    searchValue(val: string) {  // Dropdown change for memberId or filterBy
        this.selectedSearchValue = val;
        this.messages = null;
        this.isEnableSearchResult = false;

        if (this.selectedSearchValue === 'Member Id') {
            this.isEnableFilterSelection = false;
            this.isEnableMemberId = true;
            this.mPanelOpenState = true;
            this.fPanelOpenState = false;
        } else if (this.selectedSearchValue === 'Filter Selection') {
            this.isEnableFilterSelection = true;
            this.isEnableMemberId = false;
            this.mPanelOpenState = false;
            this.fPanelOpenState = true;

        }
    }

    loadFilterValues() {  // loading sourcesystem dropdown

        this.filterValueList = [];
        this.memberEligibilityService.getSourceSystemList().subscribe(data => {
            this.filterValueList = data;
            this.filteredSourceSystemList.next(this.filterValueList.slice());
        });
    }

    sectionWiseSearchResult() { // selecting page range dropdown

        this.searchResult();
    }


    searchResult() {   // submit button click

        this.initSearchResult();
        if (this.isEnableMemberId) {
            this.loadMemberIdSearchResult();
        } else if (this.isEnableFilterSelection) {
            this.loadFilterBySearchResult();
        }
    }

    loadFilterBySearchResult() {
        this.searchModel.firstName = this.filterSelectionForm.controls['participantFirstName'].value;
        this.searchModel.lastName = this.filterSelectionForm.controls['lastName'].value.trim();
        this.searchModel.dateOfBirth = this.getDateStr(this.filterSelectionForm.controls['dobDatePicker'].value);
        if (this.filterSelectionForm.controls['middleName'].value) {
            this.searchModel.middleName = this.filterSelectionForm.controls['middleName'].value.trim();
        } else {
            this.searchModel.middleName = '';
        }
        this.searchModel.sourceSystem = this.selectedSourceSystem.code;
        this.searchModel.pageSize = this.searchMaxLimit + '';
        this.searchModel.pageNumber = this.selectedPageCount ? (this.selectedPageCount.value + '') : '1';
        this.downloadReq.searchRequest = PPMESearchModel.newInstance();
        this.downloadReq.searchRequest = this.searchModel;
        let mapresult: any;
        this.busy = this.memberEligibilityService.memberEligibilitySearchByFilter(this.searchModel).subscribe(data => {
            mapresult = data;
            this.transactions = mapresult.memberList;
            // console.log(this.transactions);
            if (this.selectedPageCount == null) {
                this.totalCount = mapresult.totalCount;
                if (this.totalCount >= this.searchMaxLimit) {
                    this.totalPageCount = Math.ceil(this.totalCount / this.searchMaxLimit);
                } else {
                    this.totalPageCount = 1;
                }
                this.buildPageRangeDropdownValues();

            }
            this.showTable();
        }, error => {
            this.messages = error.error.text;

        });

    }

    loadMemberIdSearchResult() {

        let memberId = this.memberIdForm.controls['memberId'].value;
        this.downloadReq.memberId = memberId;

        // this.downloadReq.memEligMemberId = '';
        this.busy = this.memberEligibilityService.memberEligSearchByMemberId(memberId).subscribe(data => {
            this.transactions = data;
            if ((this.transactions !== '') &&
            (this.transactions != null)) {
                this.totalCount = this.transactions.length;
            }

            this.showTable();
        }, error => {
            this.messages = error.error.text;
        });


    }


    initSearchResult() {
        this.mPanelOpenState = false;
        this.fPanelOpenState = false;
        this.transactions = null;
        this.totalCount = 0;
        this.messages = null;
        this.isEnableSearchResult = false;
        this.selectedPageCount = null;
        this.downloadReq.searchRequest = null;
        this.downloadReq.memberId = '';

    }

    showTable() {

        if (this.transactions == '' || this.transactions == null) {
            this.messages = 'No records found !!!';
        } else {
            setTimeout(() => {
                this.fileDataSource.paginator = this.paginator;
            });

            this.fileDataSource = new MatTableDataSource<any>(this.transactions);
            this.isEnableSearchResult = true;
        }

    }


    buildPageRangeDropdownValues() {

        let startPage = 1;
        let endPage = 1;

        this.totalPageCountArray = [];
        for (let i = 1; i <= this.totalPageCount; i++) {
            if (startPage != 1) {
                startPage = endPage + 1;
            }
            endPage = i * this.searchMaxLimit;
            if (this.totalCount < endPage) {
                endPage = this.totalCount
            }

            let labelStr = startPage + ' - ' + endPage;
            let labelValue = { label: labelStr, value: i };
            this.totalPageCountArray.push(labelValue);
            if (i == 1) {
                this.selectedPageCount = labelValue;
            }
            startPage = endPage;
        }
    }


    downloadFile() {


        const today = moment().format('MMDDYYYY-HHmmss');
        let pageStart = 1;
        let pageEnd = this.downloadRange;
        //this.downloadReq.financialAnalysisRequest.pageNumber = this.selectedDownloadCount ? (this.selectedDownloadCount.value + '') : '1';
        // this.downloadReq.financialAnalysisRequest.pageSize = this.downloadRange + '';
        if (this.totalCount <= this.downloadRange) {
            pageEnd = this.totalCount;
        } else {
            pageStart = (Number.parseInt(this.downloadReq.searchRequest.pageNumber) - 1) * (Number.parseInt(this.downloadReq.financialAnalysisRequest.pageSize)) + 1;
            pageEnd = Number.parseInt(this.downloadReq.searchRequest.pageNumber) * Number.parseInt(this.downloadReq.financialAnalysisRequest.pageSize);

            if (this.totalCount <= pageEnd) {
                pageEnd = this.totalCount;
            }
        }
        // const filename = 'Member_Eligibility_' + today + '_' + pageStart +'-' + pageEnd + '.csv';
        const filename = 'Member_Eligibility_' + today + '.csv';


        this.busy = this.memberEligibilityService.downloadMemberEligibilityFile(this.downloadReq).subscribe(data => {

            if (window.navigator.msSaveOrOpenBlob) {
                // msSaveBlob only available for IE & Edge
                window.navigator.msSaveBlob(data.body, filename);
            } else {
                const blob = new Blob([data.body], { type: 'text/csv' });
                const downloadLink = document.createElement('a');
                downloadLink.href = URL.createObjectURL(blob);
                downloadLink.download = filename;
                document.body.appendChild(downloadLink);
                downloadLink.click();
            }


            this.snackBar.open('Successfully Downloaded!!', 'Close', {
                duration: 3000
            });
        },
            err => {

                this.snackBar.open('Failed to Download!', 'Close', {
                    duration: 3000
                });
            });
    }

    /* Convert date to string - local datetime */
    getDateStr(dateInput) {
        var result = null;
        if (dateInput != null) {
            result = moment.utc(dateInput).local().format('MM/DD/YYYY');
        }
        return result;
    }

    resetSearch() {

        this.isEnableSearchResult = false;
        this.messages = null;
        this.filterSelectionForm.controls['participantFirstName'].patchValue('');
        this.filterSelectionForm.controls['middleName'].patchValue('');
        this.filterSelectionForm.controls['lastName'].patchValue('');
        this.filterSelectionForm.controls['dobDatePicker'].patchValue('');
        this.filterSelectionForm.controls['sourceSystem'].patchValue('');

    }

    applyFilter(filterValue: string) {
        this.fileDataSource.filter = filterValue.trim().toLowerCase();
    }

}

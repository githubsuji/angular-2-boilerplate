// Angular Modules
import { Component, OnInit, Inject, ViewChild, ElementRef, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { take, takeUntil, map, startWith } from 'rxjs/operators';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatSnackBar, MatSelect } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
// tslint:disable-next-line:import-blacklist
import { Observable, ReplaySubject, Subject, Subscription } from 'rxjs';

/** Pipes */
import { DatePipe } from '@angular/common';

/** Models */
import { Iteration } from '../../../../model/tac/iteration';
import { UserModel } from '../../../../model/user/UserModel';
import { CertFileTracker } from '../../../../model/tac/CertFileTracker';
import { RejectFileModel } from '../../../../model/tac/RejectFileModel';
import { ComboFileMetadata } from '../../../../model/tac/ComboFileMetadata';
import { AuthService } from '../../../../business/modules/service/authentication/AuthService';
import { AuthorizedPermissionInformationModel } from '../../../../model/user/AuthorizedPermissionInformation';
import { RxSmartPermissionModel } from '../../../../model/util/RxSmartPermission';
import { AuthorizedUserModel } from '../../../../model/user/AuthorizedUserModel';

/** Services */
// import { AuthenticationService } from
// '../../../../business/modules/service/authentication/AuthenticationService';
import { ClaimComboFile } from '../../../../model/ppAllocation/ClaimComboFile';
import { DISABLED } from '@angular/forms/src/model';
import * as moment from 'moment';
import { ParallelProcessingService } from '../../../../../shared/services/parallel-processing.service';
@Component({
  selector: 'app-cert-filetracker-edit',
  templateUrl: './cert-filetracker-edit.component.html',
  styleUrls: ['./cert-filetracker-edit.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CertFiletrackerEditComponent implements OnInit, AfterViewInit {
  selectedTab: number;
  certFile: CertFileTracker;
  rejectFileModel: RejectFileModel;
  editCertFileForm: FormGroup;
  filteredUsers: Observable<UserModel[]>;
  iterations: Iteration[];
  updateLv = 0;
  public userArray: UserModel[] = [];
  // authenticationService: AuthenticationService;
  userModelList: UserModel[];
  selectedUserId: AuthorizedUserModel;
  selectedReviewerId: AuthorizedUserModel;
  selectedAssignBy: UserModel;
  reviewerUserModelList: AuthorizedUserModel[];
  userList: AuthorizedUserModel[];
  public filteredUserIds: ReplaySubject<UserModel[]> = new ReplaySubject<UserModel[]>(1);
  disableUploadButton: Boolean = true;
  warningError: Boolean = false;
  showLoadingIndicator: Boolean = false;
  private currentFileUpload: File;
  private selectedFiles: FileList;
  private userRole: string;
  busy: Subscription;
  errors: string[];
  messages: string[];
  auditorRejectReason = '';
  public testerUserIdCtrl: FormControl = new FormControl();
  public reviewerUserIdCtrl: FormControl = new FormControl();
  public filteredUserModelAssignToList: ReplaySubject<AuthorizedUserModel[]> = new ReplaySubject<AuthorizedUserModel[]>(1);
  public filteredUserModelReviewerList: ReplaySubject<AuthorizedUserModel[]> = new ReplaySubject<AuthorizedUserModel[]>(1);

  @ViewChild('singleSelect') singleSelect: MatSelect;
  @ViewChild('assignToInput') assignToInput: ElementRef;
  @ViewChild('fileInput') fileInputVariable: ElementRef;

  authorisationService: AuthService;
  authorizedPermissionInformationModel: AuthorizedPermissionInformationModel;
  resourceCode: string;
  rxSmartPermission: RxSmartPermissionModel;
  testerUserModelList: AuthorizedUserModel[];

  allocationFileNamePermission: Boolean = false;
  receivedDatePermission: Boolean = false;
  lobPermission: Boolean = false;
  statePlanPermission: Boolean = false;
  chcyPermission: Boolean = false;
  typeOfFilesPermission: Boolean = false;
  notesPermission: Boolean = false;
  iterationPermission: Boolean = false;
  assignedDatePermission: Boolean = false;
  completionDatePermission: Boolean = false;
  auditDatePermission: Boolean = false;
  signOffDatePermission: Boolean = false;
  testerUserIdPermission: Boolean = false;
  supervisorIdPermission: Boolean = false;
  reviewerPermission: Boolean = false;
  claimCountPermission: Boolean = false;
  deferredPermission: Boolean = false;
  rejectedPermission: Boolean = false;
  approvedPermission: Boolean = false;
  inReviewPermission: Boolean = false;
  commentPermission: Boolean = false;
  openIssuesPermission: Boolean = false;
  dailyStatusPermission: Boolean = false;
  defineResendsPermission: Boolean = false;
  chooseFilePermission: Boolean = false;
  uploadPermission: Boolean = false;
  updatePermission: Boolean = false;
  downloadPermission: Boolean = false;
  updateProgressErrorMessage: Boolean = false;
  updateProgressVErrorMessage: Boolean = false;
  rejectReasonPermission: Boolean = false;
  RejectBtnPermission: Boolean = false;
  initialTesterUserId: string;
  isDisableTabFields: Boolean = false;
  isUploadDone: Boolean = false;


  /** Subject that emits when the component has been destroyed. */
  private _onDestroy = new Subject<void>();
  claimComboFileList: ClaimComboFile[];
  isClaimComboFileExists: Boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    @Inject(ParallelProcessingService) public ppService,
    // authenticationService: AuthenticationService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public snackBar: MatSnackBar,
    public datepipe: DatePipe,
    public dialogRef: MatDialogRef<CertFiletrackerEditComponent>,
    authorisationService: AuthService) {
    // this.certFileService = certFileService;
    // this.authenticationService = authenticationService;
    this.authorisationService = authorisationService;
    dialogRef.disableClose = true;
  }

  ngOnInit() {

    console.log('>>>>>> start time : ' + new Date().getTime());
    const loggedInUser = UserModel.newInstance();
    loggedInUser.userId = localStorage.getItem('userId');
    this.authorizedPermissionInformationModel = JSON.parse(localStorage.getItem('AuthorizationModelScreen6'));
    const f: CertFileTracker = this.data.file;
    this.selectedTab = this.data.tab;
    // this.iterations = this.data.iterations;
    const popUpMode = localStorage.getItem('PP_POPUP_GLOBAL_DATA');

    this.userList = JSON.parse(sessionStorage.getItem('allUserList'));
    this.reviewerUserModelList = JSON.parse(sessionStorage.getItem('reviewerList'));
    this.filteredUserModelReviewerList.next(this.reviewerUserModelList.slice());
    this.loadAssignToUserList();
    // this.loadReviewerUserList();
    // this.getAllEditableUsers();

    if ((popUpMode === 'EDIT') || (popUpMode === 'VIEW' && f.testerUserId === loggedInUser.userId)) {
      if (this.authorizedPermissionInformationModel.attributePermissions.length > 0) {
        this.setAttributePermissions();
      }
    }

    this.initialTesterUserId = this.data.file.testerUserId;
    this.editCertFileForm = this.formBuilder.group({
      // Mode: File Name
      allocationFileName: new FormControl({ value: f.allocationFileName, disabled: !this.allocationFileNamePermission }, Validators.required),
      // Mode: Status
      receivedDate: new FormControl({ value: f.receivedDate, disabled: !this.receivedDatePermission }),
      // receivedDate: new FormControl({value : f.receivedDate, disabled : true} ) ,
      completionDate: new FormControl({ value: f.completionDate, disabled: !this.completionDatePermission }),
      assignedDate: new FormControl({ value: f.assignedDate, disabled: !this.assignedDatePermission }),
      // assignedDate: new FormControl({value : f.assignedDate, disabled : true}),
      testerUserId: new FormControl({ value: f.testerUserId, disabled: !this.testerUserIdPermission }),
      auditDate: new FormControl({ value: f.auditDate, disabled: !this.auditDatePermission }),
      signOffDate: new FormControl({ value: f.signOffDate, disabled: !this.signOffDatePermission }),
      iteration: new FormControl({ value: f.iteration, disabled: !this.iterationPermission }),
      // supervisorId: new FormControl({value : f.supervisorId, disabled : !this.supervisorIdPermission}),
      supervisorId: new FormControl({ value: f.supervisorId, disabled: true }),
      reviewer: new FormControl({ value: f.reviewer, disabled: !this.reviewerPermission }),
      // Details
      lineOfBusiness: new FormControl({ value: f.lineOfBusiness, disabled: !this.lobPermission }),
      // lineOfBusiness: new FormControl({value : f.lineOfBusiness, disabled : true}),
      statePlan: new FormControl({ value: f.stateOrPlan, disabled: !this.statePlanPermission }),
      chcy: new FormControl({ value: f.chcy, disabled: !this.chcyPermission }),
      typeOfFile: new FormControl({ value: f.fileType, disabled: !this.typeOfFilesPermission }),
      // typeOfFile: new FormControl({value : f.fileType, disabled : true}),
      notes: new FormControl({ value: f.notes, disabled: !this.notesPermission }),
      // Mode: Claim Counts
      claimCount: new FormControl({ value: f.claimCount, disabled: !this.claimCountPermission }),
      approved: new FormControl({ value: f.approved, disabled: !this.approvedPermission }),
      inReview: new FormControl({ value: f.inReview, disabled: !this.inReviewPermission }, Validators.min(0)),
      rejected: new FormControl({ value: f.rejected, disabled: !this.rejectedPermission }, Validators.min(0)),
      deferred: new FormControl({ value: f.deferred, disabled: !this.deferredPermission }, Validators.min(0)),
      // Mode: Comments
      openIssues: new FormControl({ value: f.openIssues, disabled: !this.openIssuesPermission }),
      dailyStatus: new FormControl({ value: f.dailyStatus, disabled: !this.dailyStatusPermission }),
      comments: new FormControl({ value: f.comments, disabled: !this.commentPermission }),
      defineResends: new FormControl({ value: f.defineResends, disabled: !this.defineResendsPermission }),
      rejectReason: new FormControl({ value: this.auditorRejectReason, disabled: !this.rejectReasonPermission }, [Validators.required])

    });

    if (this.data.file.resultReviewStatus !== undefined) {
      const authRolePermission = JSON.parse(localStorage.getItem('AuthorizationModelScreen6'));
      const offShoreTesterRole = authRolePermission.associatedUserGroups.includes('PP Tester Onshore');
      const onShoreTesterRole = authRolePermission.associatedUserGroups.includes('PP Tester Offshore');
      const isReviewer = authRolePermission.associatedUserGroups.includes('PP Reviewer');

      console.log('this.uploadPermission========================================' + this.uploadPermission);
      if (offShoreTesterRole || onShoreTesterRole) {
        if (this.data.file.testerUserId !== undefined && this.data.file.testerUserId !== ''
          && loggedInUser.userId === this.data.file.testerUserId) {
          if (this.data.file.resultReviewStatus !== 'READY-FOR-TESTING' && !isReviewer) {
            this.uploadPermission = false;
            this.chooseFilePermission = false;
          }
        } else if (this.data.file.resultReviewStatus === 'READY-FOR-TESTING') {
          this.uploadPermission = false;
          this.chooseFilePermission = false;
        }
      }
      if (isReviewer) {
        /*if  (this.data.file.resultReviewStatus !== 'READY-FOR-REVIEW' && !(offShoreTesterRole || onShoreTesterRole)) {
          this.uploadPermission = false;
          this.chooseFilePermission = false;
        }*/
        if (this.data.file.resultReviewStatus !== 'READY-FOR-REVIEW') {
          if (!(offShoreTesterRole || onShoreTesterRole)) {
            this.uploadPermission = false;
            this.chooseFilePermission = false;
          } else if (this.data.file.resultReviewStatus !== 'READY-FOR-TESTING' && (offShoreTesterRole || onShoreTesterRole)) {
            this.uploadPermission = false;
            this.chooseFilePermission = false;
          }
        }
      } else if (this.data.file.resultReviewStatus === 'READY-FOR-REVIEW' && (offShoreTesterRole || onShoreTesterRole)) {
        this.uploadPermission = false;
        this.chooseFilePermission = false;
      }
    }
    // console.log("this.uploadPermission========================================"+this.uploadPermission);
    // this.editCertFileForm.get('supervisorId').disable();

    this.loadTestUserId();
    this.loadReviewerId();
    this.updateprogressFields();
    this.showComboFiles();

    this.testerUserIdCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterTestUsers(
          this.testerUserModelList,
          this.filteredUserModelAssignToList,
          this.testerUserIdCtrl
        );
      });
    this.reviewerUserIdCtrl.valueChanges
      .pipe(takeUntil(this._onDestroy))
      .subscribe(() => {
        this.filterTestUsers(
          this.reviewerUserModelList,
          this.filteredUserModelReviewerList,
          this.reviewerUserIdCtrl
        );
      });
    // });


  }
  setAttributePermissions() {
    let attrPermIndex = -1;
    let isEnable = false;
    let attrPermTuple: [string, number][];
    attrPermTuple = [['Filename', 1],
    ['LOB', 2],
    ['StatePlan', 3],
    ['CH/CY', 4],
    ['Typeoffiles', 5],
    ['Notes', 6],
    ['Iterations', 7],
    ['Received Date', 8],
    ['Assigned Date', 9],
    ['Tester Completion Date', 10],
    ['Audit Date', 11],
    ['Sign Off Date', 12],
    ['Assign To', 13],
    ['Assigned by', 14],
    ['Reviewer', 15],
    ['Claim Count', 16],
    ['Deferred', 17],
    ['Rejected', 18],
    ['Approved', 19],
    ['In Review', 20],
    ['Additional comments', 21],
    ['Open Issues', 22],
    ['Daily Status', 23],
    ['Define Resends', 24],
    ['CHOOSE FILE', 25],
    ['UPLOAD', 26],
    ['UPDATE', 27],
    ['DOWNLOAD', 28],
    ['REJECT BTN', 29],
    ['REJECT REASON', 30]];
    for (const val of attrPermTuple) {
      isEnable = false;
      attrPermIndex = this.authorizedPermissionInformationModel.attributePermissions.findIndex(x => x.attributeName === val[0]);
      if (attrPermIndex > -1) {
        isEnable = this.authorizedPermissionInformationModel.attributePermissions[attrPermIndex].permittedActions.includes('EDIT');
      }
      switch (val[1]) {
        case 1: {
          this.allocationFileNamePermission = isEnable;
          break;
        }
        case 2: {
          this.lobPermission = isEnable;
          break;
        }
        case 3: {
          this.statePlanPermission = isEnable;
          break;
        }
        case 4: {
          this.chcyPermission = isEnable;
          break;
        }
        case 5: {
          this.typeOfFilesPermission = isEnable;
          break;
        }
        case 6: {
          this.notesPermission = isEnable;
          break;
        }
        case 7: {
          this.iterationPermission = isEnable;
          break;
        }
        case 8: {
          this.receivedDatePermission = isEnable;
          break;
        }
        case 9: {
          this.assignedDatePermission = isEnable;
          break;
        }
        case 10: {
          this.completionDatePermission = isEnable;
          break;
        }
        case 11: {
          this.auditDatePermission = isEnable;
          break;
        }
        case 12: {
          this.signOffDatePermission = isEnable;
          break;
        }
        case 13: {
          this.testerUserIdPermission = isEnable;
          break;
        }
        case 14: {
          this.supervisorIdPermission = isEnable;
          break;
        }
        case 15: {
          this.reviewerPermission = isEnable;
          break;
        }
        case 16: {
          this.claimCountPermission = isEnable;
          break;
        }
        case 17: {
          this.deferredPermission = isEnable;
          break;
        }
        case 18: {
          this.rejectedPermission = isEnable;
          break;
        }
        case 19: {
          this.approvedPermission = isEnable;
          break;
        }
        case 20: {
          this.inReviewPermission = isEnable;
          break;
        }

        case 21: {
          this.commentPermission = isEnable;
          break;
        }
        case 22: {
          this.openIssuesPermission = isEnable;
          break;
        }
        case 23: {
          this.dailyStatusPermission = isEnable;
          break;
        }
        case 24: {
          this.defineResendsPermission = isEnable;
          break;
        }
        case 25: {
          this.chooseFilePermission = isEnable;
          break;
        }
        case 26: {
          this.uploadPermission = isEnable;
          break;
        }
        case 27: {
          this.updatePermission = isEnable;
          break;
        }
        case 28: {
          this.downloadPermission = isEnable;
          break;
        }
        case 29: {
          this.rejectReasonPermission = isEnable;
          break;
        }
        case 30: {
          this.RejectBtnPermission = isEnable;
          break;
        }
      } // end of switch
    } // end of for
  }
  ngAfterViewInit() {

    setTimeout(() => {
      this.editCertFileForm.patchValue({ 'receivedDate': this.getDateString(this.data.file.receivedDate) });
      this.editCertFileForm.patchValue({ 'completionDate': this.getDateString(this.data.file.completionDate) });
      this.editCertFileForm.patchValue({ 'assignedDate': this.getDateString(this.data.file.assignedDate) });
      this.editCertFileForm.patchValue({ 'auditDate': this.getDateString(this.data.file.auditDate) });
      this.editCertFileForm.patchValue({ 'signOffDate': this.getDateString(this.data.file.signOffDate) });
    });
    console.log('>>>>>> end time : ' + new Date().getTime());

  }
  // tslint:disable-next-line: use-life-cycle-interface
  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }

  getDateString(date: any) {
    let formattedDate: any = null;
    if (null != date && date.trim() !== '') {
      try {
        formattedDate = moment.utc(date).format('YYYY-MM-DD');
        // new Date(dateObj.getFullYear(), dateObj.getUTCMonth(), dateObj.getUTCDate());;
        formattedDate = moment(formattedDate).toDate();
        //  formattedDate = moment(date).format('YYYY-MM-DD');
      } catch (e) {
      }
    }
    return formattedDate;
  }

  protected filterTestUsers(parentList, userList, userIdCtrl) {
    if (!this.testerUserModelList) {
      return;
    }
    // get the search keyword
    let search = userIdCtrl.value;
    if (!search) {
      userList.next(parentList.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the Users
    userList.next(
      parentList.filter(user => {
        if (user && user.firstName && user.lastName) {
          return ((user.firstName + ' ' + user.lastName).toLowerCase().indexOf(search) > -1);
        }
      })
    );
  }


  updateprogressFields() {
    if ((this.data.file.testerUserId == null || this.data.file.testerUserId === '') &&
      (this.selectedUserId.userId == null || this.selectedUserId.userId === '')) {

      this.isDisableTabFields = true;
      this.editCertFileForm.get('claimCount').disable();
      this.editCertFileForm.get('approved').disable();
      this.editCertFileForm.get('inReview').disable();
      this.editCertFileForm.get('rejected').disable();
      this.editCertFileForm.get('deferred').disable();
    } else {

      this.isDisableTabFields = false;
      this.editCertFileForm.get('claimCount').enable();
      this.editCertFileForm.get('approved').enable();
      this.editCertFileForm.get('inReview').enable();
      this.editCertFileForm.get('rejected').enable();
      this.editCertFileForm.get('deferred').enable();
    }

  }

  displayFn(user?: UserModel): string | undefined {
    return user ? user.firstName + ' ' + user.lastName : undefined;
  }

  loadTestUserId() {
    this.selectedUserId = AuthorizedUserModel.newInstance();
    this.selectedUserId.userId = this.data.file.testerUserId;
  }

  loadReviewerId() {
    this.selectedReviewerId = AuthorizedUserModel.newInstance();
    this.selectedReviewerId.userId = this.data.file.reviewer;
  }


  loadAssignToUserList() {
    // console.log(">>>>>> start time LT : " + new Date().getTime());
    this.rxSmartPermission = RxSmartPermissionModel.newInstance();
    this.rxSmartPermission.resourceCode = 'SCR002';
    this.rxSmartPermission.actionCode = ['EDIT'];
    if (this.data.file.isGbd === true) {
      this.rxSmartPermission.attributeName = 'GBD';
    } else if (this.data.file.financeFlag === true) {
      this.rxSmartPermission.attributeName = 'FINANCIAL';
    } else {
      this.rxSmartPermission.attributeName = 'COMMERCIAL';
    }

    this.authorisationService.getUsers(this.rxSmartPermission).subscribe(data => {
      this.testerUserModelList = <AuthorizedUserModel[]>data;
      this.filteredUserModelAssignToList.next(this.testerUserModelList.slice());
      // console.log(">>>>>> end time LT: " + new Date().getTime());
    });
    // load the user list


  }

  /* Convert date to string - local datetime */
  getDateStr(dateInput) {
    let result = null;
    if (dateInput != null) {
      result = moment.utc(dateInput).local().format('MM/DD/YYYY');
    }
    return result;
  }

  updateCertFile() {
    console.log(this.data.file.testerUserId + '===' + this.selectedUserId.userId);
    if ((this.selectedUserId.userId && (this.initialTesterUserId == null || this.initialTesterUserId === ''))) {
      this.data.file.resultReviewStatus = 'ALLOCATED';
    }
    this.data.file.testerUserId = this.selectedUserId.userId;
    this.data.file.reviewer = this.selectedReviewerId.userId;
    this.certFile = this.data.file;

    // this.editCertFileForm.patchValue({ 'auditDate' : moment(this.editCertFileForm.value.auditDate).format('YYYY-MM-DD')});
    // console.log(">>>>> auditDate >>>> " + this.editCertFileForm.value.auditDate);
    // console.log(">>>>> auditDate >>>> " + this.editCertFileForm.controls.auditDate.value)
    this.data.file.auditDate = this.getDateStr(this.editCertFileForm.controls.auditDate.value);
    this.certFile.auditDate = this.getDateStr(this.editCertFileForm.controls.auditDate.value);

    this.data.file.receivedDate = this.editCertFileForm.controls.receivedDate.value;
    this.certFile.receivedDate = this.editCertFileForm.controls.receivedDate.value;

    this.data.file.completionDate = this.getDateStr(this.editCertFileForm.controls.completionDate.value);
    this.certFile.completionDate = this.getDateStr(this.editCertFileForm.controls.completionDate.value);

    this.data.file.assignedDate = this.getDateStr(this.editCertFileForm.controls.assignedDate.value);
    this.certFile.assignedDate = this.getDateStr(this.editCertFileForm.controls.assignedDate.value);

    this.data.file.signOffDate = this.getDateStr(this.editCertFileForm.controls.signOffDate.value);
    this.certFile.signOffDate = this.getDateStr(this.editCertFileForm.controls.signOffDate.value);


    console.log(this.certFile);
    console.log(this.editCertFileForm.value);


    //  this.busy = this.certFileService.editCertFile(this.certFile).subscribe(
    this.busy = this.ppService.editCertFile(this.certFile).subscribe(
      succ => {
        this.snackBar.open('Successfully Edited the File!!', 'Close', {
          duration: 3000
        });
        this.showComboFiles();
        this.updatePermission = true;
        this.uploadPermission = false;
        this.chooseFilePermission = false;
        // this.dialogRef.close(this.editCertFileForm.getRawValue());
        this.dialogRef.close('update');
      },
      err => {
        this.snackBar.open(
          'Failed to update a file!, Name Already Exists!',
          'Close',
          {
            duration: 3000
          }
        );
        this.dialogRef.close();
      }
    );
  }

  close() {
    if (this.isUploadDone) {
      this.dialogRef.close('upload');
    } else {
      this.dialogRef.close('cancel');
    }

  }


  setAssignBy() {

    const currentUser = localStorage.getItem('userId');
    this.editCertFileForm.controls['supervisorId'].setValue(currentUser);
    console.log('currentUser==' + currentUser);
    this.editCertFileForm.patchValue({ 'assignedDate': moment().toDate() });
    console.log(this.selectedUserId.userId);
    // this.editCertFileForm.controls['assignedDate'].setValue(new Date().toISOString().substring(0, 10));
    this.updateprogressFields();

  }

  enableUpload() {
    this.disableUploadButton = false;
  }

  selectFile(event) {
    this.warningError = false;
    this.errors = [];
    this.messages = [];
    this.disableUploadButton = true;
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      if (
        (file.type === 'application/vnd.ms-excel' ||
          file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        && file.name === this.data.file.allocationFileName) {
        this.warningError = false;
        this.disableUploadButton = false;
      } else {
        this.warningError = true;
        this.disableUploadButton = true;
      }
    }
    this.selectedFiles = event.target.files;
    if (this.currentFileUpload != null || this.currentFileUpload !== undefined) {
      this.currentFileUpload = null;
    }
    this.currentFileUpload = this.selectedFiles.item(0);
  }

  resetFileUpload() {
    this.warningError = false;
    this.fileInputVariable.nativeElement.value = '';
    this.disableUploadButton = true;
    this.errors = [];
    this.messages = [];
  }

  uploadFile() {
    if ((this.currentFileUpload !== undefined) && (this.currentFileUpload !== null)) {
      this.uploadPermission = false;
      this.chooseFilePermission = false;
      this.messages = ['Upload is in progress.Combo file will be available for download once it is completed.'];
      this.disableUploadButton = true;
      this.showLoadingIndicator = true;
      // Service Integration Pending
      const comboFileMetadata = ComboFileMetadata.newInstance();
      this.certFile = this.data.file;
      comboFileMetadata.allocationFileId = this.certFile.id;
      // comboFileMetadata.claimUploaderType = this.userRole;
      comboFileMetadata.reviewerId = this.certFile.reviewer;
      // getting the userRoleArray and finding the TESTER role in it
      const authRolePermission = JSON.parse(localStorage.getItem('AuthorizationModelScreen6'));
      console.log(authRolePermission.associatedUserGroups);
      console.log('>>> this.currentFileUpload  >>. ' + this.currentFileUpload);
      const offShoreTesterRole = authRolePermission.associatedUserGroups.includes('PP Tester Onshore');
      const onShoreTesterRole = authRolePermission.associatedUserGroups.includes('PP Tester Offshore');
      // this.data.file.resultReviewStatus == 'READY-FOR-TESTING'
      /* if (offShoreTesterRole || onShoreTesterRole ) {
         comboFileMetadata.claimUploaderType = 'TESTER';
       } else {
         comboFileMetadata.claimUploaderType = 'NON TESTER';
       }*/
      console.log('uploadFile.this.data.file.resultReviewStatus=' + this.data.file.resultReviewStatus);
      if (this.data.file.resultReviewStatus === 'READY-FOR-TESTING') {
        comboFileMetadata.claimUploaderType = 'TESTER';
      } else {
        comboFileMetadata.claimUploaderType = 'NON TESTER';
      }
      comboFileMetadata.currentStatus = 'In Progress';
      comboFileMetadata.status = 'Active';
      comboFileMetadata.fileName = this.currentFileUpload.name;
      comboFileMetadata.createdByUserId = localStorage.getItem('userId');
      comboFileMetadata.reviewerId = this.certFile.reviewer;
      comboFileMetadata.isSkipPageLoad = true;
      console.log('comboFileMetadata.reviewerId=' + comboFileMetadata.reviewerId);
      // this.certFileService.uploadFile(comboFileMetadata, this.currentFileUpload).subscribe(data => {
      this.ppService.uploadClaimComboDataFile(comboFileMetadata, this.currentFileUpload).subscribe(data => {
        this.showLoadingIndicator = false;
        this.isUploadDone = true;
        this.showComboFiles();
      });
      this.messages = ['Upload is in progress.Combo file will be available for download once it is completed.'];
    } else {
      this.errors = ['Please select file before you upload'];
    }
  }


  showComboFiles() {
    this.showLoadingIndicator = true;
    // this.certFileService.fetchAllComboFiles(this.data.file.id).subscribe(data => {
    this.ppService.fetchAllComboFiles(this.data.file.id).subscribe(data => {
      this.claimComboFileList = <ClaimComboFile[]>data;
      this.showLoadingIndicator = false;
      if (this.claimComboFileList !== undefined && this.claimComboFileList.length > 0) {

        for (const val of this.claimComboFileList) {
          if (val.claimUploaderType !== 'TESTER') {
            val.claimUploaderType = 'AUDITOR';
          }
          if (val.isSuccess !== true) {
            this.isClaimComboFileExists = false;
          } else {
            this.isClaimComboFileExists = true;
          }
          // val.createdByUserName = this.getUserName(val.createdByUserId);

        }
      }
      console.log('this.claimComboFileList=' + this.claimComboFileList);
    });
  }

  downloadComboFile(fileId: string) {
    console.log('fileId = ' + fileId);
    this.showLoadingIndicator = true;
    // this.busy = this.certFileService.downloadFile(fileId).subscribe(data => {
    this.busy = this.ppService.downloadComboFile(fileId).subscribe(data => {
      this.showLoadingIndicator = false;
      if (window.navigator.msSaveOrOpenBlob) {
        // msSaveBlob only available for IE & Edge
        window.navigator.msSaveBlob(data.body, 'Combo_' + this.data.file.allocationFileName);
      } else {
        const blob = new Blob([data.body], { type: 'text/csv' });
        const downloadLink = document.createElement('a');
        downloadLink.href = URL.createObjectURL(blob);
        downloadLink.download = 'Combo_' + this.data.file.allocationFileName;
        document.body.appendChild(downloadLink);
        downloadLink.click();
      }
    });
  }

  checkEnableAuditorReject(file) {
    let isReviewer = false;
    let enableRejectFields = false;
    // let authRolePermission = JSON.parse(localStorage.getItem('AuthorizationModelScreen6'));
    if (this.RejectBtnPermission === true) {
      isReviewer = true;
    }
    if (isReviewer && (file.resultReviewStatus === 'READY-FOR-REVIEW')) {
      enableRejectFields = true;
    }
    return enableRejectFields;
  }



  rejectFile() {
    this.rejectFileModel = RejectFileModel.newInstance();
    this.rejectFileModel.id = this.data.file.id;
    this.rejectFileModel.resultReviewStatus = 'READY-FOR-TESTING';
    this.rejectFileModel.lastModifiedByUserId = localStorage.getItem('userId');
    this.rejectFileModel.reason = 'AuditorReject:' + this.auditorRejectReason;
    this.ppService.rejectFile(this.rejectFileModel).subscribe(data => {
      // this.certFileService.rejectFile(this.rejectFileModel).subscribe(data => {
      if (data) {
        this.snackBar.open('Rejected the File!!', 'Close', { duration: 3000 });
        this.dialogRef.close(this.editCertFileForm.getRawValue());
      }
    });
  }

  checkValidation(file) {
    this.updateProgressErrorMessage = false;
    this.updateProgressVErrorMessage = false;
    const total = file.approved + file.rejected + file.deferred + file.inReview;
    if (total > file.claimCount) {
      this.updateProgressErrorMessage = true;
    }

  }

  negNumberHandler(e) {
    if (!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58)
      || e.keyCode === 8)) {
      return false;
    }
  }
}

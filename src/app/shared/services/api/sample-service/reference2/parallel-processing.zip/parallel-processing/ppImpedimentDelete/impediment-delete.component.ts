import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material';

@Component({
  selector: 'app-impediment-delete',
  templateUrl: './impediment-delete.component.html',
  styleUrls: ['./impediment-delete.component.css']
})
export class ImpedimentDeleteComponent implements OnInit {

  constructor(private dialogRef: MatDialogRef<ImpedimentDeleteComponent>) { }

  ngOnInit() {
  }

  delete() {
    this.dialogRef.close(true);
  }
}
// Angular Modules
import { Component, OnInit, Inject, ViewChild, ElementRef, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { take, takeUntil, map, startWith } from 'rxjs/operators';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatSnackBar, MatSelect } from '@angular/material';
import { DetailTransactionService } from '../../../../business/modules/service/ppdetailtransaction/DetailTransactionService';
import { BenefitModel } from '../../../../model/ppdetailtransaction/BenefitModel';
import { Subscription } from 'rxjs/Subscription';


@Component({
  // tslint:disable-next-line:component-selector
  selector: 'detail-transaction-edit',
  templateUrl: './detail-transaction-edit.component.html',
  styleUrls: ['./detail-transaction-edit.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DetailTransactionEditComponent implements OnInit {


  fieldsArray: any = [];
  selectedTab: number;
  // editDetailTransactionForm: FormGroup;
  detailTransactionService: DetailTransactionService;
  detailTransactionModelList: BenefitModel[];


  constructor(public dialogRef: MatDialogRef<DetailTransactionEditComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private formBuilder: FormBuilder,
  ) {

  }


  ngOnInit() {

    // tslint:disable-next-line:forin
    for (const obj in this.data.file) {
      const labelValue = { label: obj, value: this.data.file[obj] };
      this.fieldsArray.push(labelValue);

    }


  }

  close() {

    this.dialogRef.close();
  }


}

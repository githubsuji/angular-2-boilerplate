/** Angular Modules */
import { Component, OnInit, ViewChild, ElementRef, Inject,
    //  HostListener,
      ViewEncapsulation, ChangeDetectorRef } from '@angular/core';

import { Subscription } from 'rxjs/Subscription';
import { Subject } from 'rxjs/Subject';
import { ReplaySubject } from 'rxjs/ReplaySubject';

/** Angular Material */
import {
    MatTableDataSource, MatPaginator, MatSort,
    MatDialog, Sort, MatSnackBar, MatDialogConfig, MatExpansionPanel
} from '@angular/material';
import { Router } from '@angular/router';
import { SelectionModel } from '@angular/cdk/collections';
import { DetailTransactionEditComponent } from '../detail-transaction-edit/detail-transaction-edit.component';
import { Overlay } from '@angular/cdk/overlay';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { PPSearchModel } from '../../../../model/ppFilterSearch/PPSearchModel';
import { BenefitModel } from '../../../../model/ppDetailTransaction/BenefitModel';
import { PPDownloadReqModel } from '../../../../model/ppFilterSearch/PPDownloadReqModel';

// import { DetailTransactionService } from '../../../../business/modules/service/ppdetailtransaction/DetailTransactionService';
import { SearchOptionModel } from '../../../../model/ppDetailTransaction/SearchOptionModel';
import { takeUntil } from 'rxjs/operators';
import { SearchOutput } from '../../../../model/ppDetailTransaction/SearchOutput';
import * as moment from 'moment';
import { ParallelProcessingService } from '../../../../../shared/services/parallel-processing.service';

@Component({
    // tslint:disable-next-line:component-selector
    selector: 'detail-transaction',
    templateUrl: './detailTransaction.html',
    styleUrls: ['./detailTransaction.css'],
    encapsulation: ViewEncapsulation.None
})

export class DetailTransactionComponent implements OnInit {

    router: Router;
    busy: Subscription;

    /* Loading animatin feature */
    isLoading: boolean;
    isEnableSearchResult: Boolean = false;
    isEnableClaimNumber: Boolean = false;
    searchType: string;
    isEnableFilterSelection: Boolean = false;
    isEnableRXCMemberId: Boolean = false;
    isPopupOpened: Boolean = false;
    overlay: Overlay;
    popupAppear: Boolean = false;
    cPanelOpenState = false;
    fPanelOpenState = false;
    detailTransactionForm: FormGroup;
    dtSearchCMform: FormGroup;
    detailTransactionModel: BenefitModel;
    searchModel: PPSearchModel;
    sort: any;
    transactions: any;
    fileDataSource: any;
    messages: string;
    filterValueList: SearchOptionModel;

    public weekCtrl: FormControl = new FormControl();
    public explainableCategoryCtrl: FormControl = new FormControl();
    public antCarrierCtrl: FormControl = new FormControl();
    public rxcGrpIDCtrl: FormControl = new FormControl();
    public rxcAccIDCtrl: FormControl = new FormControl();
    public fileTypeCtrl: FormControl = new FormControl();
    public goLiveCtrl: FormControl = new FormControl();

    selectedWeek: SearchOutput;
    selectedCategory: SearchOutput;
    selectedAntCarrier: SearchOutput;
    selectedRxcGroupID: SearchOutput;
    selectedRxcAccID: SearchOutput;
    selectedFileType: SearchOutput;
    selectedGoLive: SearchOutput;

    downloadReq: PPDownloadReqModel;
    totalCount: number;
    isClaimIdNull: Boolean = false;
    isMemberIdNull: Boolean = false;
    totalPageCount: any;
    totalPageCountArray: Array<any>;
    selectedPageCount: any;

    selectedRow: any;

    downloadRange = 1000;
    searchMaxLimit = 1000;
    downloadRangeCount: number;
    downloadRangeCountArray: Array<any>;
    selectedDownloadCount: any;

    winHeight = '';
    tableHeight = '';


    /** Subject that emits when the component has been destroyed. */
    private _onDestroy = new Subject<void>();
    public filteredWeekList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredCategoryList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredAntCarrierList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredRxcGrpIDList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredRxcAccIDList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredFileTypeList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredGoLiveList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);


    @ViewChild('panel1') firstPanel: MatExpansionPanel;
    @ViewChild('panel2') secondPanel: MatExpansionPanel;
    @ViewChild(MatPaginator) paginator: MatPaginator;
    @ViewChild('searchResultDiv') searchResultDiv: ElementRef;

    cols = ['ANT_TRANSACTION_ID', 'RXC_TRANSACTION_ID',
        'Defect_ID', 'Status', 'Issue_Short_Description',
        'Worked_By', 'LOB', 'ANT_REJECT_CODE_1', 'RXC_REJECT_CODE_1', 'ANT_COPAY_AMOUNT', 'RXC_COPAY_AMOUNT',
        'ANT_PRIOR_AUTH_IND', 'RXC_PRIOR_AUTH_IND', 'ANT_REFILL_NUMBER', 'RXC_REFILL_NUMBER', 'ANT_DATE_OF_SERVICE', 'RXC_DATE_OF_SERVICE',
        'ANT_CARRIER', 'RXC_CARRIER', 'ANT_PLAN_ID',
        'RXC_PLAN_ID', 'ANT_DEDUCTIBLE', 'RXC_DEDUCTIBLE',
        'ANT_WRITTEN_DATE', 'RXC_WRITTEN_DATE', 'ANT_ADJUDICATION_DAT', 'RXC_ADJUDICATION_DAT',
        'ANT_PRODUCT_ID', 'RXC_PRODUCT_ID', 'RXC_PRODUCT_DESCRPTN',
        'ANT_DISPENSE_QTY', 'RXC_DISPENSE_QTY', 'ANT_DAYS_SUPPLY', 'RXC_DAYS_SUPPLY', 'ANT_MEMBER_ID', 'RXC_MEMBER_ID', 'ANT_FIRST_NAME',
        'RXC_FIRST_NAME', 'ANT_LAST_NAME', 'RXC_LAST_NAME', 'ANT_PATIENT_DOB',
        'RXC_PATIENT_DOB', 'RXC_LOCAL_MSG', 'RXC_SETTLEMENT', 'RXC_EXPLN_CAT', 'RXC_COMMENTS'];

    selection = new SelectionModel<any>(true, []);

    // @HostListener('window:resize', ['$event'])
    // getScreenSize(event?) {
    //     // this.winHeight = (window.innerHeight - 131) + 'px';
    // }
    @ViewChild(MatSort) set content(content: ElementRef) {
        this.sort = content;
        if (this.sort) {
            this.fileDataSource.sort = this.sort;

        }
    }

    constructor(router: Router, public dialog: MatDialog,
        @Inject(ChangeDetectorRef) private cdr,
        private snackBar: MatSnackBar, private formBuilder: FormBuilder,
        @Inject(ParallelProcessingService) private ppService,
        // private detailTransactionService: DetailTransactionService,
        overlay: Overlay, @Inject(ElementRef) private elRef) {

        this.router = router;
        this.overlay = overlay;
        this.popupAppear = false;
        // this.detailTransactionService = detailTransactionService;

    }

    ngOnInit() {
        this.loadFilterValues();
        this.selectedWeek = SearchOutput.newInstance();
        this.selectedAntCarrier = SearchOutput.newInstance();
        this.selectedCategory = SearchOutput.newInstance();
        // this.selectedRxcAccID = SearchOutput.newInstance();
        // this.selectedRxcGroupID = SearchOutput.newInstance();
        this.searchModel = PPSearchModel.newInstance();
        this.selectedFileType = SearchOutput.newInstance();
        this.selectedGoLive = SearchOutput.newInstance();
       // this.winHeight = (window.innerHeight - 131) + 'px';

        const f = this.searchModel;
        this.dtSearchCMform = this.formBuilder.group({
            claimNumber: new FormControl({ value: f.claimID },
                [Validators.required])
        });
        this.detailTransactionForm = this.formBuilder.group({

            goLive: new FormControl({ value: f.goLiveDt },
                [Validators.required]
            ),
            week: new FormControl({ value: f.week },
                [Validators.required]
            ),
            // week: new FormControl({ value: f.week }),
            fileType: new FormControl({ value: f.fileType },
                [Validators.required]),
            explainableCategory: new FormControl({ value: f.expCategory },
                [Validators.required]),
            // antCarrier: new FormControl({ value: f.antCarrier }),
            antCarrier: new FormControl({ value: f.antCarrier },
                [Validators.required]
            ),
            rxcAccountId: new FormControl({ value: f.rxcAccountId }),
            rxcGroupId: new FormControl({ value: f.rxcGroupId }),
            reviewStatus: new FormControl({ value: f.reviewStatus }),

        });
        this.weekCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.weekNumbers,
                    this.filteredWeekList,
                    this.weekCtrl
                );
            });
        this.fileTypeCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.fileType,
                    this.filteredFileTypeList,
                    this.fileTypeCtrl
                );
            });
        this.explainableCategoryCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.explainableCategories,
                    this.filteredCategoryList,
                    this.explainableCategoryCtrl
                );
            });
        this.antCarrierCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.antCarriers,
                    this.filteredAntCarrierList,
                    this.antCarrierCtrl
                );
            });

        // this.rxcGrpIDCtrl.valueChanges
        //     .pipe(takeUntil(this._onDestroy))
        //     .subscribe(() => {
        //         this.filterValues(
        //             this.filterValueList.rxcGroupIds,
        //             this.filteredRxcGrpIDList,
        //             this.rxcGrpIDCtrl
        //         );
        //     });

        // this.rxcAccIDCtrl.valueChanges
        //     .pipe(takeUntil(this._onDestroy))
        //     .subscribe(() => {
        //         this.filterValues(
        //             this.filterValueList.rxcAccountIds,
        //             this.filteredRxcAccIDList,
        //             this.rxcAccIDCtrl
        //         );
        //     });
        this.goLiveCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.goLive,
                    this.filteredGoLiveList,
                    this.goLiveCtrl
                );
            });
    }

    protected filterValues(parentList, displayList, dropDownCtrl) {
        if (!this.filterValueList) {
            return;
        }
        // get the search keyword
        let search = dropDownCtrl.value;
        if (!search) {
            displayList.next(parentList.slice());
            return;
        } else {
            search = search.toLowerCase();
        }
        // filter the values
        displayList.next(
            parentList.filter(x => {
                if (x && x.attributeValue) {
                    return ((x.attributeValue).toLowerCase().indexOf(search) > -1);
                }
            })
        );
    }


    loadFilterValues() {
        this.filterValueList = SearchOptionModel.newInstance();
        this.ppService.getDetailTransactionFilterValues().subscribe(data => {
        // this.detailTransactionService.getFilterValues().subscribe(data => {
            this.filterValueList = data;
            this.filteredWeekList.next(this.filterValueList.weekNumbers.slice());
            this.filteredCategoryList.next(this.filterValueList.explainableCategories.slice());
            this.filteredAntCarrierList.next(this.filterValueList.antCarriers.slice());
            this.filteredFileTypeList.next(this.filterValueList.fileType.slice());
            this.filteredGoLiveList.next(this.filterValueList.goLive.slice());
        });
    }

    applyFilter(filterValue: string) {
        this.fileDataSource.filter = filterValue.trim().toLowerCase();
    }


    showSearchWindow(val: string) {
        this.messages = null;
        this.searchType = val;
        this.isEnableSearchResult = false;
        if (this.searchType === 'Claim Number') {
            this.isEnableClaimNumber = true;
            this.isEnableFilterSelection = false;
            this.isEnableRXCMemberId = false;
            this.cPanelOpenState = true;
            this.fPanelOpenState = false;
            this.dtSearchCMform.patchValue({ 'claimNumber': '' });
        } else if (this.searchType === 'Filter Selection') {
            this.isEnableClaimNumber = false;
            this.isEnableRXCMemberId = false;
            this.cPanelOpenState = false;
            this.fPanelOpenState = true;
            this.isEnableFilterSelection = true;
            this.cdr.detectChanges();
            //  this.dtSearchCMform.patchValue({ 'claimNumber': "" });
        } else {
            this.isEnableClaimNumber = false;
            this.isEnableFilterSelection = false;
            this.isEnableRXCMemberId = true;
            this.cPanelOpenState = true;
            this.fPanelOpenState = false;
            this.dtSearchCMform.patchValue({ 'claimNumber': '' });
        }
    }
    initSearchResult() {
        this.isLoading = true;
        this.isEnableSearchResult = false;
        this.transactions = null;
        this.cPanelOpenState = false;
        this.fPanelOpenState = false;
        this.messages = null;
        this.selectedPageCount = null;
        this.selectedDownloadCount = null;
    }

    searchResult() {

        this.initSearchResult();

        this.downloadReq = PPDownloadReqModel.newInstance();
        if (this.isEnableClaimNumber) {
            const claimNumber = this.dtSearchCMform.controls['claimNumber'].value;

            if (claimNumber == null || claimNumber === '' || claimNumber === undefined) {
                this.isClaimIdNull = true;
                this.cPanelOpenState = true;
            } else {
                this.isClaimIdNull = false;

                this.downloadReq.claimNumber = claimNumber;
                this.busy = this.ppService.getBenefitDataByClaim(claimNumber).subscribe(data => {
                // this.busy = this.detailTransactionService.getBenefitDataByClaim(claimNumber).subscribe(data => {
                    this.transactions = data;
                    this.totalCount = data.length;
                    this.isLoading = false;
                    this.showTable();

                }, error => {
                    this.messages = error.error.text;
                    this.isLoading = false;

                });
            }
        }

        if (this.isEnableRXCMemberId) {
            const memberId = this.dtSearchCMform.controls['claimNumber'].value;
            if (memberId == null || memberId === '' || memberId === undefined) {
                this.isMemberIdNull = true;
                this.cPanelOpenState = true;
            } else {
                this.isMemberIdNull = false;
                this.downloadReq.rxcMemberId = memberId;
                this.busy = this.ppService.getBenefitDataByMember(memberId)
                    .subscribe(data => {
                // this.busy = this.detailTransactionService.getBenefitDataByMember(memberId).subscribe(data => {
                    this.transactions = data;
                    this.totalCount = data.length;
                    this.isLoading = false;
                    this.showTable();

                }, error => {

                    this.messages = error.error.text;
                    this.isLoading = false;
                });
            }
        }
        if (this.isEnableFilterSelection) {
            this.searchByFilterValues();
        }
    }

    sectionWiseSearchResult() {
        this.isLoading = true;
        this.searchByFilterValues();

    }

    searchByFilterValues() {
        let mapresult: any;
        this.searchModel.week = this.selectedWeek.attributeCode;
        this.searchModel.expCategory = this.selectedCategory.attributeCode;
        // this.searchModel.expCategory = "";
        this.searchModel.antCarrier = this.selectedAntCarrier.attributeCode;
        // this.searchModel.rxcAccountId = this.selectedRxcAccID.attributeCode;
        // this.searchModel.rxcGroupId = this.selectedRxcGroupID.attributeCode;
        this.searchModel.fileType = this.selectedFileType.attributeCode;
        this.searchModel.goLiveDt = this.selectedGoLive.attributeCode;
        this.downloadReq.detailedTransactionRequest = PPSearchModel.newInstance();

        // console.log(" >> filetype" + this.searchModel.fileType);
        const ftypeStr = this.selectedFileType.attributeCode;
        // let ftypeStr = this.searchModel.fileType;
        if (null != ftypeStr) {
            // var splitted = ftypeStr.split("_");
            const splitted = ftypeStr.split('$');
            if (splitted.length > 0) {
                this.searchModel.category = splitted[0];
                this.searchModel.fileType = splitted[1];
            }
        }
        this.searchModel.pageSize = this.searchMaxLimit + '';
        this.searchModel.pageNumber = this.selectedPageCount ? (this.selectedPageCount.value + '') : '1';
        this.downloadReq.detailedTransactionRequest = this.searchModel;
        // console.log(this.searchModel);
        this.busy = this.ppService.getBenefitDataByFilter(this.searchModel)
            .subscribe(data => {
        // this.busy = this.detailTransactionService.getBenefitDataByFilter(this.searchModel).subscribe(data => {
            mapresult = data;
            this.transactions = mapresult.claimsList;
            this.totalCount = mapresult.totalCount;
            if (this.selectedPageCount == null) {
                this.totalCount = mapresult.totalCount;
                if (this.totalCount >= this.searchMaxLimit) {
                    this.totalPageCount = Math.ceil(this.totalCount / this.searchMaxLimit);
                } else {
                    this.totalPageCount = 1;
                }
                this.buildPageRangeDropdownValues();
            }
            // if(this.selectedDownloadCount == null){
            //     this.totalCount = mapresult.totalCount;
            //     if (this.totalCount >= this.downloadRange ) {
            //         this.downloadRangeCount = Math.ceil(this.totalCount/this.downloadRange);
            //     }else{
            //         this.downloadRangeCount  = 1;
            //     }
            //     //this.buildDownloadDropDownValues();
            // }
            this.showTable();
        }, error => {
            this.messages = error.error.text;
            this.isLoading = false;
        });
    }

    buildPageRangeDropdownValues() {
        // console.log("buildPageRangeDropdownValues()");
        let startPage = 1;
        let endPage = 1;
        // console.log(" >>> this.totalPageCount : " +  this.totalPageCount);
        this.totalPageCountArray = [];
        for (let i = 1; i <= this.totalPageCount; i++) {
            if (startPage !== 1) {
                startPage = endPage + 1;
            }
            endPage = i * this.searchMaxLimit;
            if (this.totalCount < endPage) {
                endPage = this.totalCount;
            }

            const labelStr = startPage + ' - ' + endPage;
            const labelValue = { label: labelStr, value: i };
            this.totalPageCountArray.push(labelValue);
            if (i === 1) {
                this.selectedPageCount = labelValue;
            }
            // console.log(this.selectedPageCount);
            startPage = endPage;
            // console.log(this.totalPageCountArray);
        }
    }

    buildDownloadDropDownValues() {

        let startPageDownload = 1;
        let endPageDownload = 1;
        // console.log(" >>> this.totalPageCount : " +  this.totalPageCount);
        this.downloadRangeCountArray = [];
        for (let i = 1; i <= this.downloadRangeCount; i++) {
            if (startPageDownload !== 1) {
                startPageDownload = endPageDownload + 1;
            }
            endPageDownload = i * this.downloadRange;
            if (this.totalCount < endPageDownload) {
                endPageDownload = this.totalCount;
            }

            const labelStr = startPageDownload + ' - ' + endPageDownload;
            const labelValue = { label: labelStr, value: i };
            this.downloadRangeCountArray.push(labelValue);
            if (i === 1) {
                this.selectedDownloadCount = labelValue;
            }
            console.log(this.selectedDownloadCount);
            startPageDownload = endPageDownload;
            console.log(this.totalPageCountArray);
        }
    }

    showTable() {
        if (this.transactions === '' || this.transactions == null) {
            this.messages = 'No records found !!!';
            // console.log(this.messages);
        } else {
            setTimeout(() => {
                this.fileDataSource.paginator = this.paginator;
            });

            this.checkAuditorfields();
            this.fileDataSource = new MatTableDataSource<any>(this.transactions);
            this.isEnableSearchResult = true;
            this.isLoading = false;
            // const element = this.elRef.nativeElement.parentNode.querySelector('#searchResultDiv');
            // // console.log(element);
            // if (element) {
            //     const divTop = element.offsetTop;
            //     // windowheight - searchresultdiv position = 30 for toolbar ==> set as height of table
            //     this.tableHeight = (Number.parseInt(this.winHeight) - divTop + 30) + 'px';
            //     // console.log(">>>>>> divTop : " + divTop + " wh : " + this.divHeight + " h : " + this.tableHeight);
            //     setTimeout(() => {
            //         element.scrollIntoView({ behavior: 'smooth' });
            //     });
            // }
        }

    }

    checkAuditorfields() {
        console.log(this.transactions);
        for (const obj of this.transactions) {
            console.log(obj);
            if (obj['is_financial'] === 'true') {
                // console.log(" >>>>> financial");
                // Auditor_Finance_DefectID
                if (obj['Auditor_Finance_DefectID'] != null &&
                    obj['Auditor_Finance_DefectID'].trim() !== '') {
                    obj['Defect_ID'] = obj['Auditor_Finance_DefectID'];
                }

                // Auditor_Finance_Status
                if (obj['Auditor_Finance_Status'] != null &&
                    obj['Auditor_Finance_Status'].trim() !== '') {
                    obj['Status'] = obj['Auditor_Finance_Status'];
                }

                // Auditor_Finance_IssueDescription
                if (obj['Auditor_Finance_IssueDescription'] != null &&
                    obj['Auditor_Finance_IssueDescription'].trim() !== '') {
                    obj['Issue_Short_Description'] = obj['Auditor_Finance_IssueDescription'];
                }
            } else {
                // console.log(" >>>>> non financial");
                // Auditor_DefectID
                if (obj['Auditor_DefectID'] != null &&
                    obj['Auditor_DefectID'].trim() !== '') {
                    obj['Defect_ID'] = obj['Auditor_DefectID'];
                }

                // Auditor_Status
                if (obj['Auditor_Status'] != null &&
                    obj['Auditor_Status'].trim() !== '') {
                    obj['Status'] = obj['Auditor_Status'];
                }

                // Auditor_Issue_Short_Description
                if (obj['Auditor_Issue_Short_Description'] != null &&
                    obj['Auditor_Issue_Short_Description'].trim() !== '') {
                    obj['Issue_Short_Description'] = obj['Auditor_Issue_Short_Description'];
                }

                // Auditor_Worked_By
                if (obj['Auditor_Worked_By'] != null &&
                    obj['Auditor_Worked_By'].trim() !== '') {
                    obj['Worked_By'] = obj['Auditor_Worked_By'];
                }
            }
        }

    }

    resetSearch() {
        this.isEnableSearchResult = false;
        this.searchModel.fileType = '';
        this.searchModel.category = '';
        this.searchModel.goLiveDt = '';
        this.searchModel.reviewStatus = '';
        this.searchModel.rxcAccountId = '';
        this.searchModel.rxcGroupId = '';
        this.selectedAntCarrier = SearchOutput.newInstance();
        this.selectedWeek = SearchOutput.newInstance();
        this.selectedCategory = SearchOutput.newInstance();
        // this.selectedRxcAccID = SearchOutput.newInstance();
        // this.selectedRxcGroupID = SearchOutput.newInstance();
        this.selectedFileType = SearchOutput.newInstance();
        this.selectedGoLive = SearchOutput.newInstance();
        this.dtSearchCMform.controls['claimNumber'].patchValue('');
    }

    public hasError = (controlName: string, errorName: string) => {
        return this.detailTransactionForm.controls[controlName].hasError(errorName);
    }

    downloadFile() {
        // console.log('fileId = ' + fileId);
        this.isLoading = true;
        let pageStart = 1;
        let pageEnd = this.downloadRange;
        // this.downloadReq.detailedTransactionRequest.pageNumber = this.selectedDownloadCount
        // ? (this.selectedDownloadCount.value + '') : '1';
        // this.downloadReq.detailedTransactionRequest.pageSize = this.downloadRange + '';
        if (this.totalCount <= this.downloadRange) {
            pageEnd = this.totalCount;
        } else {
            pageStart = (Number.parseInt(this.downloadReq.detailedTransactionRequest.pageNumber) - 1)
             * Number.parseInt(this.downloadReq.detailedTransactionRequest.pageSize) + 1;
            pageEnd = Number.parseInt(this.downloadReq.detailedTransactionRequest.pageNumber)
             * Number.parseInt(this.downloadReq.detailedTransactionRequest.pageSize);

            if (this.totalCount <= pageEnd) {
                pageEnd = this.totalCount;
            }
        }
        const today = moment().format('MMDDYYYY-HHmmss');
        const filename = 'Benefits_Transactions_' + today + '_' + pageStart + '-' + pageEnd + '.csv';

        // if (null != this.downloadReq.detailedTransactionRequest) {
        // this.downloadReq.detailedTransactionRequest.pageNumber = "";
        // this.downloadReq.detailedTransactionRequest.pageSize = "";
        // }
        // this.busy = this.detailTransactionService.downloadFile(this.downloadReq).subscribe(data => {
        this.busy = this.ppService.detailTransactiondownloadFile(this.downloadReq)
        .subscribe(data => {
            // console.log(">>>> download");
            // console.log(data);
            if (window.navigator.msSaveOrOpenBlob) {
                // msSaveBlob only available for IE & Edge
                window.navigator.msSaveBlob(data.body, filename);
            } else {
                const blob = new Blob([data.body], { type: 'text/csv' });
                const downloadLink = document.createElement('a');
                downloadLink.href = URL.createObjectURL(blob);
                downloadLink.download = filename;
                document.body.appendChild(downloadLink);
                downloadLink.click();
            }
            this.isLoading = false;
            this.snackBar.open('Successfully Downloaded!!', 'Close', {
                duration: 3000
            });
        },
            err => {
                this.isLoading = false;
                this.snackBar.open('Failed to Download!', 'Close', {
                    duration: 3000
                });
            });

    }

    editField(f: any) {


        if (!this.isPopupOpened) {
            this.popupAppear = true;
            this.isPopupOpened = true;
            this.selectedRow = f.ANT_TRANSACTION_ID;
            const dialogRef = this.dialog.open(DetailTransactionEditComponent, {

                height: '550px',
                width: '850px',
                scrollStrategy: this.overlay.scrollStrategies.block(),
                data: { file: f }
            });

            dialogRef.afterClosed().subscribe(result => {
                this.isPopupOpened = false;
                this.selectedRow = '';
            });
        }


    }



}

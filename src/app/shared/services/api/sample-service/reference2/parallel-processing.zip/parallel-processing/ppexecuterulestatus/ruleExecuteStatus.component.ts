import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { RuleExecuteStatusDataModel } from '../../../model/ppexecuterulestatus/RuleExecuteStatusDataModel';
import { AuthorizedPermissionInformationModel } from '../../../model/user/AuthorizedPermissionInformation';
import { AuthService } from '../../../business/modules/service/authentication/AuthService';
import { ParallelProcessingService } from '../../../../shared/services/parallel-processing.service';

@Component({
  moduleId: module.id,
  // tslint:disable-next-line:component-selector
  selector: 'ruleExecuteStatus',
  templateUrl: './ruleExecuteStatus.html',
  styleUrls: ['./ruleExecuteStatus.css'],
  encapsulation: ViewEncapsulation.None
})
export class RuleExecuteStatusComponent implements OnInit {

  private router: Router;
  private activatedRoute: ActivatedRoute;
  busy: Subscription;
  testSetId: string;
  userRole: string;
  userId: string;
  cols: any[];
  errorTemplate: Boolean = false;
  successTemplate: Boolean = false;
  errorMessage: string;
  ruleExecuteStatusData: RuleExecuteStatusDataModel[];
  unexpectedError: Boolean = false;
  unexpectedErrorMessage: string;
  message: string;
  viewRuleStatus: Boolean = false;
  authorizedPermissionInformationModel: AuthorizedPermissionInformationModel;
  authorisationService: AuthService;
  PP_MenuPermissionScreen8: Boolean = false;
  constructor(router: Router, activatedRoute: ActivatedRoute,
     @Inject(ParallelProcessingService) private ppService,
     authorisationService: AuthService) {
    this.router = router;
    this.activatedRoute = activatedRoute;
    this.authorisationService = authorisationService;
  }

  ngOnInit() {
    // this.authorizedPermissionInformationModel = JSON.parse(localStorage.getItem('AuthorizationModelScreen8'));

    this.userId = localStorage.getItem('userId');
    this.busy = this.authorisationService.getUserGroupPermissions(this.userId, 'SCR008').subscribe(data => {
      this.authorizedPermissionInformationModel = <AuthorizedPermissionInformationModel>data;

      if (this.authorizedPermissionInformationModel &&
        this.authorizedPermissionInformationModel.resourcePermissions != null &&
        this.authorizedPermissionInformationModel.resourcePermissions !== undefined &&
        this.authorizedPermissionInformationModel.resourcePermissions.length > 0) {
        this.PP_MenuPermissionScreen8 = this.authorizedPermissionInformationModel.resourcePermissions[0].permittedActions.includes('VIEW');
      }
      if (this.PP_MenuPermissionScreen8 === false) {
        this.message = 'Access Denied!!!';
      } else {

        this.userRole = localStorage.getItem('userRole');
        this.activatedRoute.queryParams.subscribe((params) => {
          this.testSetId = params['testSetId'];
        });

        this.cols = [
          { field: 'batchFileLobeFileName', header: 'File Name', width: '40%' },
          { field: 'rulesetVersionID', header: 'Rule Id', width: '15%' },
          { field: 'createdByDate', header: 'Created Date', width: '15%' },
          { field: 'createdByUserId', header: 'Created By', width: '15%' },
          { field: 'currentStatus', header: 'Current Status', width: '15%' }
        ];
        this.fetchRuleExecuteStatus();
        /* attribute permission block */
        //  let resourceCode = "SCR008";
        let attrPermTuple: [string, number][];
        attrPermTuple = [['VIEW_RULE_STATUS', 1]];
      }

    });

  }
  fetchRuleExecuteStatus() {
    this.unexpectedError = false;
    this.ruleExecuteStatusData = null;
    this.busy = this.ppService.fetchRuleStatus().subscribe(data => {
    // this.busy = this.ruleExecuteService.fetchRuleStatus().subscribe(data => {
      this.ruleExecuteStatusData = <RuleExecuteStatusDataModel[]>data;
      if (this.ruleExecuteStatusData === null || this.ruleExecuteStatusData === undefined || this.ruleExecuteStatusData.length <= 0) {
        this.unexpectedError = true;
        this.unexpectedErrorMessage = 'No data is currently queued to display.';
      }
    }, error => {
      this.unexpectedError = true;
      this.unexpectedErrorMessage = 'Unexpected Error Occurred!';
    });
  }
}

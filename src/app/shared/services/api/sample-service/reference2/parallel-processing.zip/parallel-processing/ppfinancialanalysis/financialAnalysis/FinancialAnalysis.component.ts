/** Angular Modules */
import { Component, OnInit, ViewChild, ElementRef, Inject, HostListener, ViewEncapsulation } from '@angular/core';

import { Subscription, Subject, ReplaySubject } from 'rxjs/';

/** Angular Material */
import {
    MatTableDataSource, MatPaginator, MatSort, MatDialog,
    MatSnackBar, MatExpansionPanel
} from '@angular/material';
import { Router } from '@angular/router';
import { SelectionModel } from '@angular/cdk/collections';
import { FinancialAnalysisEditComponent } from '../financial-analysis-edit/financial-analysis-edit.component';
import { Overlay } from '@angular/cdk/overlay';
import { PPSearchModel } from '../../../../model/ppFilterSearch/PPSearchModel';
import { SearchOptionModel } from '../../../../model/ppDetailTransaction/SearchOptionModel';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
// import { DetailTransactionService } from '../../../../business/modules/service/ppdetailtransaction/DetailTransactionService';
import { takeUntil } from 'rxjs/operators';
import { FinancialModel } from '../../../../model/ppDetailTransaction/FinancialModel';
import { SearchOutput } from '../../../../model/ppDetailTransaction/SearchOutput';
import { PPDownloadReqModel } from '../../../../model/ppFilterSearch/PPDownloadReqModel';
import * as moment from 'moment';
import { ParallelProcessingService } from '../../../../../shared/services/parallel-processing.service';




@Component({
    // tslint:disable-next-line:component-selector
    selector: 'financial-analysis',
    templateUrl: './financialanalysis.html',
    styleUrls: ['./financialanalysis.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class FinancialAnalysisComponent implements OnInit {

    router: Router;
    busy: Subscription;
    /* Loading animatin feature */
    isLoading: boolean;

    searchType: string;
    isEnableSearchResult: Boolean = false;
    isEnableClaimNumber: Boolean = false;
    isEnableFilterSelection: Boolean = false;
    isEnableRXCMemberId: Boolean = false;
    isPopupOpened: Boolean = false;
    overlay: Overlay;
    popupAppear: Boolean = false;
    cPanelOpenState = false;
    fPanelOpenState = false;
    fileDataSource: any;
    sort: any;
    financialTransactionForm: FormGroup;
    financialClmForm: FormGroup;
    searchModel: PPSearchModel;
    financialTransactionModel: FinancialModel;
    filterValueList: SearchOptionModel;
    totalCount: any;
    showSubmit = false;
    public weekCtrl: FormControl = new FormControl();
    public antCarrierCtrl: FormControl = new FormControl();
    public rxcGrpIDCtrl: FormControl = new FormControl();
    public rxcAccIDCtrl: FormControl = new FormControl();
    public rxcCarrierCtrl: FormControl = new FormControl();
    public lobCtrl: FormControl = new FormControl();
    public fileTypeCtrl: FormControl = new FormControl();
    public goLiveCtrl: FormControl = new FormControl();

    selectedWeek: SearchOutput;
    selectedAntCarrier: SearchOutput;
    selectedLob: SearchOutput;
    selectedRxcCarrier: SearchOutput;
    selectedRxcGroupID: SearchOutput;
    selectedRxcAccID: SearchOutput;
    selectedFileType: SearchOutput;
    selectedGoLive: SearchOutput;

    transactions: any;
    messages: string;
    downloadReq: PPDownloadReqModel;
    totalPageCount: any;
    totalPageCountArray: Array<any>;
    selectedPageCount: any;

    selectedRow: any;


    downloadRange = 1000;
    searchMaxLimit = 1000;
    downloadRangeCount: number;
    downloadRangeCountArray: Array<any>;
    selectedDownloadCount: any;
    winHeight = '';
    tableHeight = '';

    /** Subject that emits when the component has been destroyed. */
    private _onDestroy = new Subject<void>();
    public filteredWeekList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredAntCarrierList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredRxcGrpIDList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredRxcAccIDList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredLobList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredRxcCarrierList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredFileTypeList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);
    public filteredGoLiveList: ReplaySubject<SearchOutput[]> = new ReplaySubject<SearchOutput[]>(1);



    @ViewChild('panel1') firstPanel: MatExpansionPanel;
    @ViewChild('panel2') secondPanel: MatExpansionPanel;
    @ViewChild(MatPaginator) paginator: MatPaginator;


    cols: string[] = ['RXC_TRANSACTION_ID', 'Finance_DefectID', 'RXC_BASIS_TYPE', 'EDW_ANT_BASIS_OF_COST', 'RXC_INGREDIENT_COST', 'EDW_ANT_INGRED_COST', 'RXC_FULL_AWP_DIS', 'RXC_FULL_MAC', 'RXC_USUAL_CUSTOMARY',
        'EDW_ANT_FULL_AWP_AMT', 'ANT_USUAL_CUSTOMARY', 'ANT_DISPENSE_QTY', 'RXC_DISPENSE_QTY',
        'RXC_PRODUCT_DESCRPTN', 'RXC_GROSS_COST', 'EDW_ANT_GROSS_COST_LESS_ADMIN_FEE', 'ANT_DISPENSING_FEE', 'RXC_DISPENSING_FEE', 'ANT_TOTAL_SALES_TAX', 'RXC_TOTAL_SALES_TAX',
        'ADMIN_FEE_AMT', 'RXC_CLIENT_AMT_DUE', 'EDW_ANT_CLIENT_AMT_DUE_LESS_ADM', 'ANT_PATIENT_PAY', 'RXC_PATIENT_PAY', 'ANT_COPAY_AMOUNT', 'RXC_COPAY_AMOUNT', 'RXC_DEDUCTIBLE', 'ANT_DEDUCTIBLE',
        'ANT_OTHER_PAY', 'ANT_MEMBER_ID', 'ANT_PRESCRIPTION_REF', 'ANT_DATE_OF_SERVICE',
        'RXC_DEL', 'RXC_DRUG_INDICATOR', 'ANT_PHARMACY_NPI_ID', 'ANT_HRA', 'RXC_HRA', 'RXC_RXOTC'];

    selection = new SelectionModel<any>(true, []);

    @ViewChild(MatSort) set content(content: ElementRef) {
        this.sort = content;
        if (this.sort) {
            this.fileDataSource.sort = this.sort;

        }
    }

    constructor(router: Router, public dialog: MatDialog,
        private snackBar: MatSnackBar, overlay: Overlay,
        private formBuilder: FormBuilder,
        // private detailTransactionService: DetailTransactionService,
        @Inject(ParallelProcessingService) private ppService,
        @Inject(ElementRef) private elRef) {

        this.router = router;
        this.overlay = overlay;
        this.popupAppear = false;
        // this.detailTransactionService = detailTransactionService;

    }

    ngOnInit() {
        this.loadFilterValues();
        this.downloadReq = PPDownloadReqModel.newInstance();
        this.selectedWeek = SearchOutput.newInstance();
        this.selectedAntCarrier = SearchOutput.newInstance();
        this.selectedLob = SearchOutput.newInstance();
        this.selectedRxcCarrier = SearchOutput.newInstance();
        this.selectedFileType = SearchOutput.newInstance();
        this.selectedGoLive = SearchOutput.newInstance();
        this.searchModel = PPSearchModel.newInstance();
        const f = this.searchModel;
        this.financialTransactionForm = this.formBuilder.group({
            goLive: new FormControl({ value: f.goLiveDt },
                [Validators.required]),
            week: new FormControl({ value: f.week },
                [Validators.required]),
            fileType: new FormControl({ value: f.fileType },
                [Validators.required]),
            antCarrier: new FormControl({ value: f.antCarrier }),
            rxcCarrier: new FormControl({ value: f.rxcCarrier }),
            rxcAccountId: new FormControl({ value: f.rxcAccountId }),
            rxcGroupId: new FormControl({ value: f.rxcGroupId }),
            lob: new FormControl({ value: f.lob }),
            antTransactionId: new FormControl({ value: f.antTransactionId }),
            rxcTransactionId: new FormControl({ value: f.rxcTransactionId })
        });
        this.financialClmForm = this.formBuilder.group({
            claimID: new FormControl({ value: f.claimID },
                [Validators.required])
        });
        this.weekCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.weekNumbers,
                    this.filteredWeekList,
                    this.weekCtrl
                );
            });
        this.fileTypeCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.fileType,
                    this.filteredFileTypeList,
                    this.fileTypeCtrl
                );
            });

        this.antCarrierCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.antCarriers,
                    this.filteredAntCarrierList,
                    this.antCarrierCtrl
                );
            });
        this.rxcCarrierCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.rxcCarrier,
                    this.filteredRxcCarrierList,
                    this.rxcCarrierCtrl
                );
            });
        this.lobCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.lob,
                    this.filteredLobList,
                    this.lobCtrl
                );
            });
        this.goLiveCtrl.valueChanges
            .pipe(takeUntil(this._onDestroy))
            .subscribe(() => {
                this.filterValues(
                    this.filterValueList.goLive,
                    this.filteredGoLiveList,
                    this.goLiveCtrl
                );
            });
    }

    protected filterValues(parentList, displayList, dropDownCtrl) {
        if (!this.filterValueList) {
            return;
        }
        // get the search keyword
        let search = dropDownCtrl.value;
        if (!search) {
            displayList.next(parentList.slice());
            return;
        } else {
            search = search.toLowerCase();
        }
        // filter the values
        displayList.next(
            parentList.filter(x => {
                if (x && x.attributeValue) {
                    return ((x.attributeValue).toLowerCase().indexOf(search) > -1);
                }
            })
        );
    }

    public hasError = (controlName: string, errorName: string) => {
        return this.financialTransactionForm.controls[controlName].hasError(errorName);
    }



    applyFilter(filterValue: string) {

        this.fileDataSource.filter = filterValue.trim().toLowerCase();
    }

    loadFilterValues() {
        this.filterValueList = SearchOptionModel.newInstance();

        this.ppService.getFinancialFilterValues().subscribe(data => {
        // this.detailTransactionService.getFinancialFilterValues().subscribe(data => {
            this.filterValueList = data;
            this.filteredWeekList.next(this.filterValueList.weekNumbers.slice());
            this.filteredAntCarrierList.next(this.filterValueList.antCarriers.slice());
            this.filteredRxcCarrierList.next(this.filterValueList.rxcCarrier.slice());
            this.filteredLobList.next(this.filterValueList.lob.slice());
            this.filteredFileTypeList.next(this.filterValueList.fileType.slice());
            this.filteredGoLiveList.next(this.filterValueList.goLive.slice());

        });
    }


    showSearchWindow(val: string) {
        this.searchType = val;
        this.isEnableSearchResult = false;

        if (this.searchType === 'Claim Number') {
            this.isEnableClaimNumber = true;
            this.isEnableFilterSelection = false;
            this.isEnableRXCMemberId = false;
            this.cPanelOpenState = true;
            this.fPanelOpenState = false;
        } else if (this.searchType === 'Filter Selection') {
            this.isEnableClaimNumber = false;
            this.isEnableFilterSelection = true;
            this.isEnableRXCMemberId = false;
            this.cPanelOpenState = false;
            this.fPanelOpenState = true;
        }
    }

    searchResult() {
        this.initSearchResult();
        if (this.isEnableClaimNumber) {
            this.searchByClaimNumber();
        } else if (this.isEnableFilterSelection) {
            this.searchByFilterValues();
        }
    }

    sectionWiseSearchResult() {
        this.isLoading = true;
        this.searchByFilterValues();

    }

    initSearchResult() {
        this.isLoading = true;
        this.cPanelOpenState = false;
        this.fPanelOpenState = false;
        this.transactions = null;
        this.totalCount = 0;
        this.messages = null;
        this.selectedPageCount = null;
        this.downloadReq.financialAnalysisRequest = null;
        this.downloadReq.claimNumber = '';
        this.isEnableSearchResult = false;
        this.selectedDownloadCount = null;
    }

    searchByClaimNumber() {
        const claimNumber = this.financialClmForm.controls['claimID'].value;
        this.downloadReq.claimNumber = claimNumber;
        this.busy = this.ppService.getFinancialDataByClaim(claimNumber)
        // this.busy = this.detailTransactionService.getFinancialDataByClaim(claimNumber)
        .subscribe(data => {
            this.transactions = data;
            this.totalCount = data.length;
            this.showTable();

        }, error => {
            this.isLoading = false;
            this.messages = error.error.text;
        });
    }


    searchByFilterValues() {
        this.searchModel.week = this.selectedWeek.attributeCode;
        this.searchModel.antCarrier = this.selectedAntCarrier.attributeCode;
        this.searchModel.rxcCarrier = this.selectedRxcCarrier.attributeCode;
        this.searchModel.lob = this.selectedLob.attributeCode;
        this.searchModel.fileType = this.selectedFileType.attributeCode;
        this.searchModel.goLiveDt = this.selectedGoLive.attributeCode;
        this.downloadReq.financialAnalysisRequest = PPSearchModel.newInstance();
        const ftypeStr = this.selectedFileType.attributeCode;
        if (null != ftypeStr) {
            const splitted = ftypeStr.split('$');
            if (splitted.length > 0) {
                this.searchModel.category = splitted[0];
                this.searchModel.fileType = splitted[1];
            }
        }
        this.searchModel.pageSize = this.searchMaxLimit + '';
        this.searchModel.pageNumber = this.selectedPageCount ? (this.selectedPageCount.value + '') : '1';
        this.downloadReq.financialAnalysisRequest = this.searchModel;
        let mapresult: any;
        this.busy = this.ppService.getFinancialDataByFilter(this.searchModel)
        .subscribe(data => {
        // this.busy = this.detailTransactionService.getFinancialDataByFilter(this.searchModel).subscribe(data => {
            mapresult = data;
            this.transactions = mapresult.financialClaimsList;
            if (this.selectedPageCount == null) {
                this.totalCount = mapresult.totalCount;
                if (this.totalCount >= this.searchMaxLimit) {
                    this.totalPageCount = Math.ceil(this.totalCount / this.searchMaxLimit);
                } else {
                    this.totalPageCount = 1;
                }
                this.buildPageRangeDropdownValues();

            }
            this.showTable();
        }, error => {
            this.isLoading = false;
            this.messages = error.error.text;
        });


    }

    buildDownloadDropDownValues() {

        let startPageDownload = 1;
        let endPageDownload = 1;
        this.downloadRangeCountArray = [];
        for (let i = 1; i <= this.downloadRangeCount; i++) {
            if (startPageDownload !== 1) {
                startPageDownload = endPageDownload + 1;
            }
            endPageDownload = i * this.downloadRange;
            if (this.totalCount < endPageDownload) {
                endPageDownload = this.totalCount;
            }

            const labelStr = startPageDownload + ' - ' + endPageDownload;
            const labelValue = { label: labelStr, value: i };
            this.downloadRangeCountArray.push(labelValue);
            if (i === 1) {
                this.selectedDownloadCount = labelValue;
            }
            startPageDownload = endPageDownload;
        }
    }

    buildPageRangeDropdownValues() {
        let startPage = 1;
        let endPage = 1;

        this.totalPageCountArray = [];
        for (let i = 1; i <= this.totalPageCount; i++) {
            if (startPage !== 1) {
                startPage = endPage + 1;
            }
            endPage = i * this.searchMaxLimit;
            if (this.totalCount < endPage) {
                endPage = this.totalCount;
            }

            const labelStr = startPage + ' - ' + endPage;
            const labelValue = { label: labelStr, value: i };
            this.totalPageCountArray.push(labelValue);
            if (i === 1) {
                this.selectedPageCount = labelValue;
            }
            startPage = endPage;
        }
    }


    showTable() {
        if (this.transactions === '' || this.transactions == null) {
            this.messages = 'No records found !!!';
        } else {
            setTimeout(() => {
                this.fileDataSource.paginator = this.paginator;
            });
            this.fileDataSource = new MatTableDataSource<any>(this.transactions);
            this.isLoading = false;
            this.isEnableSearchResult = true;
        }

    }

    downloadFile() {
        this.isLoading = true;
        const today = moment().format('MMDDYYYY-HHmmss');
        let pageStart = 1;
        let pageEnd = this.downloadRange;
        if (this.totalCount <= this.downloadRange) {
            pageEnd = this.totalCount;
        } else {
            pageStart = (Number.parseInt(this.downloadReq.financialAnalysisRequest.pageNumber) - 1) * (Number.parseInt(this.downloadReq.financialAnalysisRequest.pageSize)) + 1;
            pageEnd = Number.parseInt(this.downloadReq.financialAnalysisRequest.pageNumber) * Number.parseInt(this.downloadReq.financialAnalysisRequest.pageSize);

            if (this.totalCount <= pageEnd) {
                pageEnd = this.totalCount;
            }
        }
        const filename = 'Financial_Transactions_' + today + '_' + pageStart + '-' + pageEnd + '.csv';
        this.busy = this.ppService.downloadFinancialFile(this.downloadReq)
            .subscribe(data => {
        // this.busy = this.detailTransactionService.downloadFinancialFile(this.downloadReq).subscribe(data => {
            if (window.navigator.msSaveOrOpenBlob) {
                // msSaveBlob only available for IE & Edge
                window.navigator.msSaveBlob(data.body, filename);
            } else {
                const blob = new Blob([data.body], { type: 'text/csv' });
                const downloadLink = document.createElement('a');
                downloadLink.href = URL.createObjectURL(blob);
                downloadLink.download = filename;
                document.body.appendChild(downloadLink);
                downloadLink.click();
            }
            this.isLoading = false;
            this.snackBar.open('Successfully Downloaded!!', 'Close', {
                duration: 3000
            });
        },
            err => {
                this.isLoading = false;
                this.snackBar.open('Failed to Download!', 'Close', {
                    duration: 3000
                });
            });
    }


    resetSearch() {
        this.isEnableSearchResult = false;
        this.searchModel.fileType = '';
        this.searchModel.category = '';
        this.searchModel.goLiveDt = '';
        this.searchModel.reviewStatus = '';
        this.searchModel.rxcAccountId = '';
        this.searchModel.rxcGroupId = '';
        this.downloadReq = PPDownloadReqModel.newInstance();
        this.selectedWeek = SearchOutput.newInstance();
        this.selectedAntCarrier = SearchOutput.newInstance();
        this.selectedLob = SearchOutput.newInstance();
        this.selectedRxcCarrier = SearchOutput.newInstance();
        this.selectedFileType = SearchOutput.newInstance();
        this.selectedGoLive = SearchOutput.newInstance();
        this.searchModel = PPSearchModel.newInstance();
        this.financialClmForm.controls['claimID'].patchValue('');
    }

    editField(f: any) {
        if (!this.isPopupOpened) {
            this.popupAppear = true;
            this.isPopupOpened = true;
            this.selectedRow = f.ANT_TRANSACTION_ID;
            const dialogRef = this.dialog.open(FinancialAnalysisEditComponent, {
                height: '550px',
                width: '850px',
                scrollStrategy: this.overlay.scrollStrategies.block(),
                data: { file: f }
            });

            dialogRef.afterClosed().subscribe(result => {
                this.isPopupOpened = false;
                this.selectedRow = '';
            });
        }
    }



}

/** Angular Modules */
import { Component, OnInit, ViewChild, ElementRef,
    OnDestroy, HostListener, Renderer2, ViewEncapsulation,
     Inject } from '@angular/core';
import { Fieldset } from 'primeng/primeng';
import * as json2csv from 'json2csv';
import { saveAs } from 'file-saver';
import { Angular5Csv } from 'angular5-csv/dist/Angular5-csv';
import { Subscription } from 'rxjs/Subscription';

/** Angular Material */
import { MatTableDataSource, MatPaginator, MatSort, MatDialog, Sort, MatSnackBar, MatDialogConfig } from '@angular/material';

/** Services */
import { DefectService } from '../../../business/modules/service/fileTracking/cert-defect.service';

/** Models */
import { Defect } from '../../../model/defect/defect';

/** Components */
import { ImpedimentCreateComponent } from '../ppImpedimentCreate/impediment-create.component';
import { ImpedimentDeleteComponent } from '../ppImpedimentDelete/impediment-delete.component';

/** Pipes */
import { DatePipe } from '@angular/common/';
import { UserModel } from '../../../model/user/UserModel';
import { AuthService } from '../../../business/modules/service/authentication/AuthService';
import { AuthorizedPermissionInformationModel } from '../../../model/user/AuthorizedPermissionInformation';
import { SortService } from '../../../../shared/services/util/sort.service';
import { SaveFilterService } from '../../../../shared/services/util/save-filter.service';

@Component({
  selector: 'app-defect-list',
  templateUrl: './defectList.component.html',
  styleUrls: ['../old-tac-styling.css', './defectList.component.css'],
  encapsulation: ViewEncapsulation.None,
})

export class DefectListRxComponent implements OnInit {

  cols = ['id', 'defectNumber', 'jiraId', 'status', 'statusNotes', 'openedBy', 'impactedClaims', 'workstream', 'lob', 'fileTypes',
    'antRejectCodes', 'rxRejectCodes', 'statesPlans', 'rxcexplncat', 'rxclocalmsg', 'rxccomments',
    'shortDescription', 'testerReasoning', 'associatedFiles', 'reason', 'defectDescription',
    'validUntilDate', 'goLiveDate', 'implementationDate', 'dateOfService', 'createDate', 'closeDate',
    'lastModifiedDate', 'assignDateCVS', 'closeDateCVS', 'corrections', 'memberImpact', 'projectOwner',
    'flex1', 'flex2', 'flex3', 'flex4', 'flex5', 'remove'
  ];

  virtualLength = 20;
  id = 'ID';
  searchField = '';
  displayField = '';
  displayedColumns: string[] = this.cols;
  excel = false;
  devTools = true;
  teamLead = true;
  defectMappings: Array<Mapping> = [];
  loading = true;
  loadingDefects = false;
  loadingPermissionsEdit = false;
  loadingPermissionsList = false;
  filterChips: any[] = [];
  dataSource = new MatTableDataSource<Mapping>();
  viewMode = 'all';
  isPopupOpened = true;
  saveFilterStr = 'defectlistFiltOps';
  saveFilterOps = false;
  saveSortOps: Sort;
  filteredMappings: Array<Mapping> = [];
  currentMappingStart = 0;
  currentMappingEnd = 100;
  loggedInUser: UserModel;
  listPermissionMap: Map<string, string[]>;
  editPermissionMap: Map<string, string[]>;
  e: any;

  excelColumns: string[];
  pageLoader: boolean;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('FilterInput') filterInput: ElementRef;
  @ViewChild('virtualcontainer') virtualContainer: ElementRef;
  @ViewChild('virtualwindow') virtualWindow: ElementRef;
  @ViewChild('tablecontainer') tableContainer: ElementRef;

  constructor(
    private defectService: DefectService,
    private sorter: SortService,
    private authService: AuthService,
    private datePipe: DatePipe,
    private snackBar: MatSnackBar,
    private saveFilterService: SaveFilterService,
    private renderer: Renderer2,
    private dialog?: MatDialog,
  ) { }



  ngOnInit() {
    this.loggedInUser = UserModel.newInstance();
    this.loggedInUser.userId = localStorage.getItem('userId');
    this.loggedInUser.userGroup = localStorage.getItem('userRole');
    this.excelColumns = this.displayedColumns.filter(field => !field.toLowerCase().includes('status'));
    this.getEditPermissionsFromService();
    this.getListPermissionsFromService();
    this.getFromService();
  }

  getEditPermissionsFromService() {
    const resourceCode = 'SCR011';
    this.loadingPermissionsEdit = true;
     this.authService.getUserGroupPermissions(this.loggedInUser.userId, resourceCode).subscribe(data => {
      const permissionModel = <AuthorizedPermissionInformationModel>data;
      this.editPermissionMap = new Map<string, string[]>();
      // console.log(permissionModel);

      for (const attribute of permissionModel.attributePermissions) {
        this.editPermissionMap.set(attribute.attributeName, attribute.permittedActions);
      }

      this.loadingPermissionsEdit = false;
      this.loading = this.loadingDefects || this.loadingPermissionsEdit || this.loadingPermissionsList;
    });
  }
  getListPermissionsFromService() {
    const resourceCode = 'SCR010';
    this.loadingPermissionsList = true;
    this.authService.getUserGroupPermissions(this.loggedInUser.userId, resourceCode).subscribe(data => {
      const permissionModel = <AuthorizedPermissionInformationModel>data;
      this.listPermissionMap = new Map<string, string[]>();

      for (const attribute of permissionModel.attributePermissions) {
        this.listPermissionMap.set(attribute.attributeName, attribute.permittedActions);
      }

      this.loadingPermissionsList = false;
      this.loading = this.loadingDefects || this.loadingPermissionsEdit || this.loadingPermissionsList;
    });
  }

  filterPredicate(data: Mapping) {
    let res = true;
    let str: string;
    let n: number;

    for (const f of this.filterChips) {
      let val;
      if (typeof (f) !== 'object') {
        val = f.value.toLowerCase();
      } else {
        val = f.value;
      }

      if (f.field === 'All') {
        str = data ? JSON.stringify(data).toLowerCase() : '';
        res = res && (str.indexOf(val) !== -1);
      } else if (f.field.toLowerCase().includes('date')) {
        str = data[f.field] ? this.datePipe.transform(data[f.field], 'shortDate').toLowerCase() : '';
        res = res && (str.indexOf(val) !== -1);
      } else if (f.field === 'summary') {
        str = data['statusSummary'] ? data['statusSummary'].toLowerCase() : '';
        str = str.concat(data['createDate'] ? this.datePipe.transform(data['createDate']).toLowerCase() : '');
        str = str.concat(data['assignedSme'] ? data['assignedSme'].toLowerCase() : '');
        str = str.concat(data['reportedBy'] ? data['reportedBy'].toLowerCase() : '');
        res = res && (str.indexOf(val) !== -1);
      } else if (f.field === 'rxSummary') {
        str = data['rxSummary'] ? data['rxSummary'].toLowerCase() : '';
        str = str.concat(data['rejectCodeSummary'] ? data['rejectCodeSummary'].toLowerCase() : '');
        res = res && (str.indexOf(val) !== -1);
      } else {
        if ((typeof data[f.field]).toString() === 'number') {
          n = data[f.field];
          res = res && n >= val;
        } else if ((typeof data[f.field]).toString() === 'boolean') {
          str = data[f.field].toString();
          res = res && str === val;
        } else {
          str = data[f.field] ? data[f.field] : '';
          const re = new RegExp(val, 'gi');
          res = res && (re.test(str));
        }
      }
    }
    return res;
  }

  @HostListener('mousewheel', ['$event'])
  virtualScroll(event: WheelEvent) {
    if (this.defectMappings.length === 0) {
      return;
    }
    this.setVirtualData(this.currentMappingStart + (event.deltaY / 100));
    this.scrollTo();
  }

  onTableScroll(e) {
    const h = this.virtualContainer.nativeElement['scrollHeight'] - this.virtualContainer.nativeElement['clientHeight'];
    const posPercent = this.virtualContainer.nativeElement['scrollTop'] / h;

    this.setVirtualData(posPercent * this.filteredMappings.length);
  }

  setVirtualData(startPos: number) {
    const virtualWindowHeight = Math.max(2000, this.filteredMappings.length * 200);
    this.renderer.setStyle(this.virtualWindow.nativeElement, 'min-height', virtualWindowHeight + 'px');

    this.currentMappingStart = Math.min(this.filteredMappings.length - 1, Math.max(0, Math.round(startPos)));
    this.currentMappingEnd = Math.min(this.currentMappingStart + this.virtualLength, this.filteredMappings.length);

    this.dataSource.data = this.filteredMappings.slice(this.currentMappingStart, this.currentMappingEnd);
    this.pageLoader = false;
  }

  private scrollTo(): void {
    const h = this.virtualContainer.nativeElement['scrollHeight'] - this.virtualContainer.nativeElement['clientHeight'];
    const position = this.currentMappingStart / this.filteredMappings.length * h;

    this.renderer.setProperty(this.virtualContainer.nativeElement, 'scrollTop', position);
  }

  // tslint:disable-next-line: use-life-cycle-interface
  ngOnDestroy() {
    if (this.saveFilterOps) {
      this.saveOps();
    }
  }

  applyFilter() {
    this.filteredMappings = this.defectMappings.filter(a => this.filterPredicate(a));
    this.scrollTo();
  }

  search(field: string, displayField: string) {
    this.addFilter();
    this.searchField = field;
    this.displayField = displayField;
    this.filterInput.nativeElement.focus();
  }

  /**
   * @author Austin Molina
   * remove a filter chip by field name
   */
  removeFilterByField(filterField: string) {
    this.filterChips = this.filterChips.filter(a => a.field !== filterField);
    this.updateDisplay();
  }

  /**
   * @author Charles Courtois
   * On control click, adds cell contents to the filters.
   */
  filterClick(
    event: MouseEvent,
    field: any,
    fieldName: string,
    displayFieldName: string
  ) {
    if (event.ctrlKey) {
      // change dates
      if (fieldName.toLowerCase().includes('date')) {
        field = this.datePipe.transform(field, 'shortDate');
      }

      // convert nonstrings
      if ((typeof (field) !== 'string') && (typeof (field) !== 'object')) {
        field = field.toString();
      }

      // remove other filters for selected field
      this.removeFilterByField(fieldName);

      // push the chip
      this.filterChips.push({
        field: fieldName,
        displayField: displayFieldName,
        value: field
      });
      this.updateDisplay();
    }
  }

  addFilter() {
    if (!this.filterInput.nativeElement.value) {
      return;
    }
    const val = {
      field: this.searchField || 'All',
      displayField: this.displayField,
      value: this.filterInput.nativeElement.value
    };
    this.filterChips.push(val);
    this.filterInput.nativeElement.value = '';
    this.updateDisplay();
  }

  removeFilter(filter: any) {
    // console.log('remove', filter);
    this.filterChips = this.filterChips.filter(
      a => a.field !== filter.field || a.value !== filter.value
    );
    this.updateDisplay();
  }

  removeAllFilters() {
    this.filterChips.forEach(chip => {
      this.removeFilter(chip);
    });
  }

  saveOps() {
    this.saveFilterService.save(this.saveFilterStr, this.filterChips, this.saveSortOps, this.viewMode);
  }

  getOps() {
    const ops = this.saveFilterService.get(this.saveFilterStr);
    if (ops) {
      if (ops.filters !== undefined) {
        this.filterChips = ops.filters;
        this.saveFilterOps = true;
      }
      if (ops.sorters !== undefined) {
        this.sort = ops.sorters;
        this.saveFilterOps = true;
      }
      if (ops.views !== undefined) {
        this.setViewMode(ops.views);
        this.saveFilterOps = true;
      }
    }
  }

  deleteFilter() {
    this.saveFilterService.delete(this.saveFilterStr);
  }

  updateSaveFilter() {
    if (this.saveFilterOps) {
      this.saveOps();
    } else {
      this.deleteFilter();
    }
  }

  /*********************************END OF FILTER *********************************** */
  getFromService() {
    this.loadingDefects = true; // Sets the condition to true to enable the loading animation while data is loaded.
    this.defectService.getAll().subscribe(
      succ => {
        this.pageLoader = true;
        setTimeout(() => {
          this.defectMappings = this.buildDefectMappings(succ);
          this.dataSource.data = this.defectMappings;
          this.updateDisplay();
          this.setVirtualData(0);
          this.loadingDefects = false; // Sets the loading to false to disable the loading animation and show the data.
          this.loading = this.loadingDefects || this.loadingPermissionsEdit || this.loadingPermissionsList;
        }, 1000);
      }
    );
  }

  buildDefectMappings(data: Defect[]): any[] {
    const mappings: any[] = [];
    for (const defect of data) {
      const mapping = this.createMapping(defect);
      mappings.push(mapping);
    }
    return mappings;
  }

  createMapping(defect: Defect) {
    // tslint:disable-next-line: no-use-before-declare
    const mapping = new Mapping();
    mapping.id = defect.id;
    mapping.derivedDefectId = defect.derivedDefectId;
    mapping.originalDefect = defect;
    mapping.idSummary = this.idSummary(defect);
    mapping.defectNumber = defect.defectNumber;
    mapping.jiraId = defect.jiraId;
    mapping.status = defect.status;
    mapping.statusSummary = this.statusSummary(defect);
    mapping.impactedClaims = defect.impactedClaims;
    mapping.lob = defect.lob;
    mapping.fileTypes = defect.fileTypes;
    mapping.lobBreakdown = this.breakDownArray(defect.lob);
    mapping.fileTypeBreakdown = this.breakDownArray(defect.fileTypes);
    mapping.antRejectCodes = this.breakDownArray(defect.antRejectCodes);
    mapping.rxRejectCodes = this.breakDownArray(defect.rxRejectCodes);
    mapping.rejectCodeSummary = this.rejectCodeSummary(defect);
    mapping.statesPlans = this.breakDownStates(defect);
    mapping.rxcexplncat = defect.rxcexplncat;
    mapping.rxclocalmsg = defect.rxclocalmsg;
    mapping.rxccomments = defect.rxccomments;
    mapping.rxSummary = this.rxSummary(defect);
    mapping.antProductDescription = defect.antProductDescription;
    mapping.workstream = defect.workstream;
    mapping.shortDescription = defect.shortDescription;
    mapping.reason = defect.reason;
    mapping.defectDescription = defect.defectDescription;
    mapping.testerReasoning = defect.testerReasoning;
    mapping.reportedBy = defect.reportedBy;
    mapping.assignedSme = defect.assignedSme;
    mapping.withCVSPendingWork = defect.withCVSPendingWork;
    mapping.trackedInModelParallel = defect.trackedInModelParallel;
    mapping.associatedFiles = this.getAssociatedFilesToolTip(defect);
    mapping.lastModifiedDate = defect.lastModifiedDate;
    mapping.assignDateCVS = defect.assignDateCVS;
    mapping.closeDateCVS = defect.closeDateCVS;
    mapping.createDate = defect.createDate;
    mapping.dateOfService = defect.dateOfService;
    mapping.validUntilDate = defect.validUntilDate;
    mapping.corrections = defect.corrections;
    mapping.flex1 = defect.flex1;
    mapping.flex2 = defect.flex2;
    mapping.flex3 = defect.flex3;
    mapping.flex4 = defect.flex4;
    mapping.flex5 = defect.flex5;
    mapping.memberImpact = defect.memberImpact;
    mapping.goLiveDate = defect.goLiveDate;
    mapping.implementationDate = defect.implementationDate;
    mapping.statusNotes = defect.statusNotes;
    mapping.projectOwner = defect.projectOwner;
    mapping.closeDate = defect.closeDate;
    return mapping;
  }

  getFileTypeToolTip(defect: Defect): string {
    let tooltip = '';
    if (defect.fileTypes) {
      defect.fileTypes.forEach(type => {
        if (tooltip === '') {
          tooltip += type;
        } else {
          tooltip += ', ' + type;
        }
      });
    }
    return tooltip;
  }

  getStateToolTip(defect: Defect): string {
    let tooltip = '';
    defect.statesPlans.forEach(state => {
      if (tooltip === '') {
        tooltip += state;
      } else {
        tooltip += ', ' + state;
      }
    });
    return tooltip;
  }

  getType(fname: string) {
    if (fname != null) {
      const f: string[] = fname.split('_');
      if (f.length > 8) {
        const fn = f[0];
        f[0].charAt(0);
        switch (fn) {
          case 'MISMATCHED':
            fname = 'MM' + ':' + f[2].charAt(0) + f[4].charAt(0);
            break;
          case 'MATCHED':
            fname = 'MA' + ':' + f[2].charAt(0) + f[4].charAt(0);
            break;
          case 'FALLOUT':
            fname = 'FO' + ':' + f[2].charAt(0) + f[4].charAt(0);
            break;
        }
      }
    }
    return fname;
  }

  // CHECK WHERE DO WE GET THE NICKNAME OR FILE NAME !IMPORTANT
  getAssociatedFilesToolTip(defect: Defect): string {
    const tooltip = '';
    if (defect.associatedFiles.length > 0) {
      defect.associatedFiles.forEach(file => {
        if (file) {
          if (tooltip === '') {
            // tooltip += this.certFileTrackerService.getFileNicknameLong(file);
          } else {
            // tooltip += ', ' + this.certFileTrackerService.getFileNicknameLong(file);
          }
        }
      });
    }
    return tooltip;
  }

  addDefect() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;

    dialogConfig.data = {
      panelClass: 'my-panel',
      mode: 'add',
      devTools: this.devTools,
      permissionMap: this.editPermissionMap
    };

    const dialogRef = this.dialog.open(ImpedimentCreateComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
      if (result) {
        const mappedResult = this.createMapping(result);
        this.defectMappings.push(mappedResult);
        this.updateDisplay(false);
      }
    });
  }

  addImpediment() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.data = {
      panelClass: 'my-panel',
      mode: 'impediment',
      devTools: this.devTools,
      permissionMap: this.editPermissionMap
    };

    const dialogRef = this.dialog.open(ImpedimentCreateComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
      console.log(result);
      if (result) {
        const mappedResult = this.createMapping(result);
        this.defectMappings.push(mappedResult);
        this.updateDisplay(false);
      }
    });
  }

  editDefect(event: MouseEvent, defect: Defect, tabName: string) {
    if (!event.ctrlKey) {
      let t = 0;
      switch (tabName) {
        case 'Overview': t = 0; break;
        case 'Tracking': t = 1; break;
        case 'Mismatch': t = 2; break;
        case 'Claim': t = 3; break;
        case 'Flex': t = 4; break;
      }

      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose = true;

      dialogConfig.data = {
        panelClass: 'my-panel',
        mode: 'edit',
        defect: defect,
        tab: t,
        devTools: this.devTools,
        permissionMap: this.editPermissionMap
      };

      const dialogRef = this.dialog.open(ImpedimentCreateComponent, dialogConfig);
      dialogRef.afterClosed().subscribe(result => {
        console.log(result);
        this.isPopupOpened = false;
        if (result) {
          const mappedResult = this.createMapping(result);

          this.defectMappings = this.defectMappings.map(a => {
            if (a.id !== defect.id) {
              return a;
            } else {
              return mappedResult;
            }
          });

          this.updateDisplay(false);
        }
      });
    }
  }

  deleteDefect(defect: Defect) {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = false;
    dialogConfig.data = { panelClass: 'my-panel', defect: defect };
    const dialogRef = this.dialog.open(ImpedimentDeleteComponent, dialogConfig);
    dialogRef.afterClosed().subscribe(result => {
      this.isPopupOpened = false;
      if (result) {
        this.defectService.deleteDefect(defect).subscribe(
          (succ) => {
            this.snackBar.open('Successfully deleted defect.', 'Close', {
              duration: 3000
            });
          },
          (err) => {
            this.snackBar.open('Failed to delete defect.', 'Close', {
              duration: 3000
            });
          }
        );
        this.defectMappings = this.defectMappings.filter(a => a.id !== defect.id);
        this.updateDisplay();
      }
    });
  }

  /******************************************************************************
    * @author: Austin Molina
    * Date: 11/9/18
    * Last Modified: 1/28/19
    * @param sort
    * Description: Sorter for the rows and columns applied to the table.
    ******************************************************************************/
  sortData(sort: Sort, reset = false) {
    const data = this.filteredMappings.slice();

    this.saveSortOps = sort;
    const isAsc = sort.direction === 'asc';
    this.filteredMappings = data.sort((a: Mapping, b: Mapping) => {
      switch (sort.active) {
        case 'id': return this.sorter.compare(a.id, b.id, isAsc);
        case 'impactedClaims': return this.sorter.compare(a.impactedClaims, b.impactedClaims, isAsc);
        case 'defectNumber': return this.sorter.compare(a.defectNumber, b.defectNumber, isAsc);
        case 'jiraId': return this.sorter.compare(a.jiraId, b.jiraId, isAsc);
        case 'workstream': return this.sorter.compare(a.workstream, b.workstream, isAsc);
        case 'fileTypes': return this.sorter.compare(a.fileTypes, b.fileTypes, isAsc);
        case 'lob': return this.sorter.compare(a.lob, b.lob, isAsc);
        case 'shortDescription': return this.sorter.compare(a.shortDescription, b.shortDescription, isAsc);
        case 'status': return this.sorter.compare(a.status, b.status, isAsc);
        case 'reason': return this.sorter.compare(a.reason, b.reason, isAsc);
        case 'defectDescription': return this.sorter.compare(a.defectDescription, b.defectDescription, isAsc);
        case 'rxcexplncat': return this.sorter.compare(a.rxcexplncat, b.rxcexplncat, isAsc);
        case 'rxclocalmsg': return this.sorter.compare(a.rxclocalmsg, b.rxclocalmsg, isAsc);
        case 'rxccomments': return this.sorter.compare(a.rxccomments, b.rxccomments, isAsc);
        case 'testerReasoning': return this.sorter.compare(a.testerReasoning, b.testerReasoning, isAsc);
        case 'antRejectCodes': return this.sorter.compare(a.antRejectCodes, b.antRejectCodes, isAsc);
        case 'rxRejectCodes': return this.sorter.compare(a.rxRejectCodes, b.rxRejectCodes, isAsc);
        case 'statesPlans': return this.sorter.compare(a.statesPlans, b.statesPlans, isAsc);
        case 'withCVSPendingWork': return this.sorter.compare(a.withCVSPendingWork, b.withCVSPendingWork, isAsc);
        case 'trackedInModelParallel': return this.sorter.compare(a.trackedInModelParallel, b.trackedInModelParallel, isAsc);
        case 'associatedFiles': return this.sorter.compare(a.associatedFiles, b.associatedFiles, isAsc);
        case 'reportedBy': return this.sorter.compare(a.reportedBy, b.reportedBy, isAsc);
        case 'lastModifiedDate': return this.sorter.compare(a.lastModifiedDate, b.lastModifiedDate, isAsc);
        case 'assignDateCVS': return this.sorter.compare(a.assignDateCVS, b.assignDateCVS, isAsc);
        case 'closeDateCVS': return this.sorter.compare(a.closeDateCVS, b.closeDateCVS, isAsc);
        case 'createDate': return this.sorter.compare(a.createDate, b.createDate, isAsc);
        case 'validUntilDate': return this.sorter.compare(a.validUntilDate, b.validUntilDate, isAsc);
        case 'corrections': return this.sorter.compare(a.corrections, b.corrections, isAsc);
        case 'memberImpact': return this.sorter.compare(a.memberImpact, b.memberImpact, isAsc);
        case 'flex1': return this.sorter.compare(a.flex1, b.flex1, isAsc);
        case 'flex2': return this.sorter.compare(a.flex2, b.flex2, isAsc);
        case 'flex3': return this.sorter.compare(a.flex3, b.flex3, isAsc);
        case 'flex4': return this.sorter.compare(a.flex4, b.flex4, isAsc);
        case 'flex5': return this.sorter.compare(a.flex5, b.flex5, isAsc);
        case 'idSummary': return this.sorter.compare(a.idSummary, b.idSummary, isAsc);
        case 'goLiveDate': return this.sorter.compare(a.goLiveDate, b.goLiveDate, isAsc);
        case 'implementationDate': return this.sorter.compare(a.implementationDate, b.implementationDate, isAsc);
        case 'projectOwner': return this.sorter.compare(a.projectOwner, b.projectOwner, isAsc);
        case 'statusNotes': return this.sorter.compare(a.statusNotes, b.statusNotes, isAsc);
        case 'closeDate': return this.sorter.compare(a.closeDate, b.closeDate, isAsc);
        default: return 0;
      }
    });

    if (reset) {
      this.setVirtualData(0);
    }
  }

  updateDisplay(recallMappingStart = true) {
    console.log('table started to rendering' + new Date());
    this.getOps();
    this.applyFilter();
    this.sortData(this.sort);

    if (recallMappingStart) {
      for (const m of this.dataSource.data) {
        const i = this.filteredMappings.indexOf(m);
        if (i >= 0) {
          this.currentMappingStart = i;
          break;
        }
      }
    }

    this.setVirtualData(this.currentMappingStart);
    this.scrollTo();
    this.dataSource._updateChangeSubscription();
    console.log('table started to renderred' + new Date());
  }

  breakDownArray(codes: string[]): string {
    let str = '';

    for (let i = 0; i < codes.length; i++) {
      if (i === codes.length - 1) {
        str += codes[i];
      } else {
        str += codes[i] + ', ';
      }
    }

    return str;
  }

  breakDownStates(defect: Defect): string {
    if (null === defect.statesPlans) {
      return '';
    }
    if (undefined !== defect.statesPlans) {
      if (defect.statesPlans.length === 0) {
        return '';
      }
      if (defect.statesPlans.length === 1) {
        return defect.statesPlans[0];
      }
      if (defect.statesPlans.length === 2) {
        return defect.statesPlans[0] + ', ' + defect.statesPlans[1];
      }

      return (
        defect.statesPlans[0] +
        ' and ' +
        (defect.statesPlans.length - 1) +
        ' more.'
      );
    }
  }

  setViewMode(viewMode: string) {
    this.excel = false;
    this.viewMode = viewMode;

    this.displayedColumns = this.cols;

    switch (viewMode) {
      case 'summary':
        this.displayedColumns = ['idSummary', 'summary', 'status', 'statusNotes', 'workstream', 'fileTypes',
        'lob', 'rxSummary', 'reason', 'goLiveDate', 'closeDate'];
        break;
      case 'tracking':
        this.displayedColumns = ['idSummary', 'summary', 'status', 'statusNotes', 'assignedSme', 'reason',
        'projectOwner', 'goLiveDate', 'implementationDate', 'closeDate'];
        break;
      case 'mismatch':
        this.displayedColumns = ['idSummary', 'summary', 'workstream', 'fileTypes', 'lob', 'rxRejectCodes',
          'antRejectCodes', 'rxcexplncat', 'rxclocalmsg', 'rxccomments', 'defectDescription', 'testerReasoning'];
        break;
      case 'claim':
        this.displayedColumns = ['idSummary', 'summary', 'workstream', 'dateOfService', 'lob',
          'statesPlans', 'impactedClaims', 'memberImpact', 'associatedFiles'];
        break;
      case 'flex':
        this.displayedColumns = ['idSummary', 'summary', 'workstream', 'lob',
          'corrections', 'flex1', 'flex2', 'flex3', 'flex4', 'flex5'];
        break;
      default:
        this.displayedColumns = this.cols;
        break;
    }
  }

  idSummary(defect: Defect): string {
    let id = '';

    if (defect.jiraId) {
      id = defect.jiraId;
    } else if (defect.defectNumber) {
      id = defect.defectNumber;
    } else {
      id = defect.id;
    }

    return id;
  }

  statusSummary(defect: Defect) {
    // if(defect.withCVSPendingWork)
    return 'Status: ' + defect.status;
  }

  rxSummary(defect: Defect): string {
    return defect.rxcexplncat + '; LocalMsg: ' + defect.rxclocalmsg;
  }
  rejectCodeSummary(defect: Defect): string {
    return (
      'ant [' + defect.antRejectCodes + ']   rx [' + defect.rxRejectCodes + ']'
    );
  }

  /**
  * Created By: Charles Courtois
  *
  * Exports the filtered defects into a CSV file.
  */
  exportDefectsToCSV() {
    const today = new Date().toLocaleDateString();
    const fields = [
      'Impediment Id',
      'Status',
      'Status Valid Until',
      'Reported By',
      'Workstream',
      'Defect Number',
      'Jira Id',
      'SME',
      'File Types',
      'Date Of Service',
      'LOB',
      'States/Plans',
      'Anthem Reject Codes',
      'RXC Reject Codes',
      'Short Description',
      'Impacted Claims',
      'Member Impact',
      'Reason',
      'With CVS',
      'Tracked In Model Parallel',
      'Defect Description',
      'RXC Expln Cat',
      'RXC Local Msg',
      'RXC Comments',
      'Tester Reasoning',
      'Associated Files',
      'Flex 1',
      'Flex 2',
      'Flex 3',
      'Flex 4',
      'Flex 5',
      'Go Live Date',
      'Status Notes',
      'Project Owner',
      'Implementation Date',
      'Close Date'
    ];

    const options = {
      decimalseparator: '.',
      useBom: false,
      showLabels: false,
      headers: fields
    };

    const data: any = [];

    if (this.filteredMappings.length !== 0) {
      for (const defect of this.filteredMappings) {
        let exportDateOfService;
        let exportValidUntilDate;

        if (defect.dateOfService == null) {
          exportDateOfService = '';
        } else {
          exportDateOfService = new Date(defect.dateOfService).toLocaleDateString().replace(/\u200E/g, '');
        }

        if (defect.validUntilDate == null) {
          exportValidUntilDate = '';
        } else {
          exportValidUntilDate = new Date(defect.validUntilDate).toLocaleDateString().replace(/\u200E/g, '');
        }

        const temp = {
          _id: defect.id,
          status: defect.status,
          validUntilDate: exportValidUntilDate,
          reportedBy: defect.reportedBy,
          workstream: defect.workstream,
          defectNumber: defect.defectNumber,
          jiraId: defect.jiraId,
          assignedSme: defect.assignedSme,
          fileTypes: defect.fileTypes.toString().replace(/,/g, ', '),
          dateOfService: exportDateOfService,
          lob: defect.lob.toString().replace(/,/g, ', '),
          statesPlans: defect.statesPlans.toString().replace(/,/g, ', '),
          antRejectCodes: defect.antRejectCodes.toString().replace(/,/g, ', '),
          rxRejectCodes: defect.rxRejectCodes.toString().replace(/,/g, ', '),
          shortDescription: defect.shortDescription,
          impactedClaims: defect.impactedClaims,
          memberImpact: defect.memberImpact,
          reason: defect.reason,
          withCVSPendingWork: defect.withCVSPendingWork,
          trackedInModelParallel: defect.trackedInModelParallel,
          defectDescription: defect.defectDescription,
          rxcexplncat: defect.rxcexplncat,
          rxclocalmsg: defect.rxclocalmsg,
          rxccomments: defect.rxccomments,
          testerReasoning: defect.testerReasoning,
          associatedFiles: defect.associatedFiles,
          flex1: this.exportStringConversion(defect.flex1),
          flex2: this.exportStringConversion(defect.flex2),
          flex3: this.exportStringConversion(defect.flex3),
          flex4: this.exportStringConversion(defect.flex4),
          flex5: this.exportStringConversion(defect.flex5),
          goLiveDate: defect.goLiveDate,
          statusNotes: defect.statusNotes,
          projectOwner: defect.projectOwner,
          implementationDate: defect.implementationDate,
          closeDate: defect.closeDate
        };
        data.push(temp);
      }
    }
    // tslint:disable-next-line:no-unused-expression
    new Angular5Csv(JSON.stringify(data), `TAC_Defect_Output_${today}`, options);
  }

  /**
   * Created By: Charles Courtois
   *
   * Used in the exportDefectsToCSV method to convert strings that have nulls
   * to a blank string.
   */
  exportStringConversion(value: string): String {
    if (value === null) {
      return '';
    } else {
      return value;
    }
  }
}

class Mapping {
  public id: string;
  public derivedDefectId: string;
  public originalDefect: Defect;
  public statusSummary: string;
  public idSummary: string;
  public defectNumber: string;
  public jiraId: string;
  public status: string;
  public impactedClaims: number;
  public lob: string[];
  public lobBreakdown: string;
  public fileTypes: string[];
  public fileTypeBreakdown: string;
  public antRejectCodes: string;
  public rxRejectCodes: string;
  public rejectCodeSummary: string;
  public statesPlans: string;
  public rxcexplncat: string;
  public rxclocalmsg: string;
  public rxccomments: string;
  public rxSummary: string;
  public antProductDescription: string;
  public workstream: string;
  public shortDescription: string;
  public reason: string;
  public defectDescription: string;
  public testerReasoning: string;
  public corrections: string;
  public reportedBy: string;
  public assignedSme: string;
  public withCVSPendingWork: boolean;
  public trackedInModelParallel: boolean;
  public associatedFiles: string;
  public lastModifiedDate: string;
  public assignDateCVS: string;
  public closeDateCVS: string;
  public createDate: string;
  public dateOfService: string;
  public validUntilDate: string;
  public flex1: string;
  public flex2: string;
  public flex3: string;
  public flex4: string;
  public flex5: string;
  public memberImpact: boolean;
  public goLiveDate: string[];
  public statusNotes: string;
  public projectOwner: string;
  public implementationDate: string;
  public closeDate: string;


  constructor() {
    this.id = '';
    this.derivedDefectId = '';
    this.originalDefect = null;
    this.idSummary = '';
    this.defectNumber = '';
    this.jiraId = '';
    this.status = '';
    this.statusSummary = '';
    this.impactedClaims = 0;
    this.workstream = '';
    this.lob = null;
    this.lobBreakdown = '';
    this.fileTypes = null;
    this.fileTypeBreakdown = '';
    this.antRejectCodes = '';
    this.rxRejectCodes = '';
    this.rejectCodeSummary = '';
    this.statesPlans = '';
    this.rxcexplncat = '';
    this.rxclocalmsg = '';
    this.rxccomments = '';
    this.rxSummary = '';
    this.antProductDescription = '';
    this.shortDescription = '';
    this.testerReasoning = '';
    this.associatedFiles = '';
    this.lastModifiedDate = '';
    this.reportedBy = '';
    this.assignedSme = '';
    this.trackedInModelParallel = null;
    this.createDate = '';
    this.withCVSPendingWork = null;
    this.dateOfService = '';
    this.assignDateCVS = '';
    this.closeDateCVS = '';
    this.reason = '';
    this.defectDescription = '';
    this.validUntilDate = '';
    this.flex1 = '';
    this.flex2 = '';
    this.flex3 = '';
    this.flex4 = '';
    this.flex5 = '';
    this.memberImpact = null;
    this.goLiveDate = null;
    this.statusNotes = '';
    this.projectOwner = '';
    this.implementationDate = '';
    this.closeDate = '';
  }
}


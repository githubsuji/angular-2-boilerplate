import { Component, OnInit, ViewChild, ViewEncapsulation, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog, Sort, MatSnackBar, MatSort, MatPaginator, PageEvent } from '@angular/material';
import { UserModel } from '../../../../model/user/UserModel';
import { CertFileTracker } from '../../../../model/tac/CertFileTracker';
import { Iteration } from '../../../../model/tac/iteration';
import { BatchDataModel } from '../../../../model/ppAllocation/BatchDataModel';
import { Observable } from 'rxjs/Observable';
import { Angular5Csv } from 'angular5-csv/dist/Angular5-csv';
import { CertFiletrackerEditComponent } from '../tracker-edit/cert-filetracker-edit.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import { AuthenticationService } from '../../../../business/modules/service/authentication/AuthenticationService';
import { Overlay } from '@angular/cdk/overlay';
import { AuthorizedPermissionInformationModel } from '../../../../model/user/AuthorizedPermissionInformation';
import { AuthService } from '../../../../business/modules/service/authentication/AuthService';
import * as moment from 'moment';
import { DatePipe } from '@angular/common';
import * as _ from 'lodash';
import { ParallelProcessingService } from '../../../../../shared/services/parallel-processing.service';
import { SortService } from '../../../../../shared/services/util/sort.service';
@Component({
  moduleId: module.id,
  // tslint:disable-next-line:component-selector
  selector: 'files',
  templateUrl: './files.html',
  styleUrls: ['./files.css'],
  encapsulation: ViewEncapsulation.None
})
export class FilesComponent implements OnInit {
  dataBeforeFinanceFilter: any;
  private router: Router;
  page: string;
  currentIteration: string;
  currentIterId: string;
  selectedIterationValue: BatchDataModel;
  viewMode: string;
  showMyFiles: Boolean;
  showSplitFiles: Boolean;
  showFinancialFiles: Boolean;
  certFileTrackerDataModel: CertFileTracker;
  certFileTrackerList: CertFileTracker[];
  private sorter: SortService;
  isPopupOpened = false;
  displayUIComponents = false;
  noRecordFound = false;
  // fileDataSource = new MatTableDataSource<CertFileTracker>();
  fileData: Array<CertFileTracker> = [];
  rawData: Array<CertFileTracker> = [];
  // iterationFileMap: Map<String, IterationMapping>;
  iterations: Iteration[] = [];
  iteration: string;
  fileDisplayedColumns: String[] = [
    'File Name',
    'Original File Name',
    'Date Received',
    'Date Assigned',
    'Date Completed',
    'Audit Date',
    'Sign Off Date',
    'Assign To',
    'LOB',
    'State/Plan',
    'Iteration',
    'Type',
    'Define Resends',
    'Daily Status',
    'Notes',
    'Claim Count',
    'Approved',
    'In Review',
    'Rejected',
    'Deferred',
    'Open Issues',
    'LH Prep',
    'Comments'
  ];
  // fileDataSource = new MatTableDataSource(this.fileData);
  fileDataSource = new MatTableDataSource<CertFileTracker>();
  // fileDataSource = new MatTableDataSource(this.certFileTrackerList);
  actualFileDataSource: any;
  batchRequest: BatchDataModel;
  busy: Subscription;
  batchIteration: BatchDataModel[] = [];
  batchIterationTemp: BatchDataModel[];
  tempDate: Date;
  userModelList: UserModel[];
  authenticationService: AuthenticationService;
  /* Loading animatin feature */
  isLoading: boolean;
  overlay: Overlay;
  authorisationService: AuthService;
  authorizedPermissionInformationModel: AuthorizedPermissionInformationModel;
  popUpEditPermission: Boolean = false;
  dialogpopUpPermission: string;
  isGbdFilePermission: Boolean;
  isFinancialFilePermission: Boolean;
  message: string;

  // MatPaginator Output
  // pageEvent: PageEvent;

  length: Number = 0;


  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  public array: any;
  public pageSize: any = 10;
  public currentPage = 0;
  public totalSize = 0;

  constructor(
    @Inject(ParallelProcessingService) private ppService,
    router: Router, public dialog: MatDialog,
    overlay: Overlay, private activatedRoute: ActivatedRoute,
    sorter: SortService,
    public datepipe: DatePipe,
      authenticationService: AuthenticationService,
      authorisationService: AuthService) {
    this.router = router;
    this.sorter = sorter;
    this.authenticationService = authenticationService;
    this.authorisationService = authorisationService;
    this.overlay = overlay;
  }

  ngOnInit() {

    this.showMyFiles = false;
    this.showSplitFiles = false;
    this.showFinancialFiles = false;
    this.authorizedPermissionInformationModel = JSON.parse(localStorage.getItem('AuthorizationModelScreen2'));
    if (this.authorizedPermissionInformationModel &&
      this.authorizedPermissionInformationModel.resourcePermissions !== null &&
      this.authorizedPermissionInformationModel.resourcePermissions !== undefined &&
      this.authorizedPermissionInformationModel.resourcePermissions.length > 0) {
      this.message = null;
      this.displayUIComponents = true;
    } else {
      this.message = 'Access Denied!!!';
      this.displayUIComponents = false;
    }
    if (this.displayUIComponents) {
      const popUpIndex = this.authorizedPermissionInformationModel.attributePermissions
        .findIndex(x => x.attributeName === 'PP_POPUP_GLOBAL_DATA');
      if (popUpIndex >= 0) {
        if (this.popUpEditPermission = this.authorizedPermissionInformationModel.attributePermissions[popUpIndex]
          .permittedActions.includes('EDIT')) {
          this.dialogpopUpPermission = 'EDIT';
        } else if (this.popUpEditPermission = this.authorizedPermissionInformationModel.attributePermissions[popUpIndex]
          .permittedActions.includes('VIEW')) {
          this.dialogpopUpPermission = 'VIEW';
          this.showMyFiles = true; // only testers will have view permission for popup
        } else {
          this.dialogpopUpPermission = 'None';
        }
        localStorage.setItem('PP_POPUP_GLOBAL_DATA', this.dialogpopUpPermission);
      }
      this.loadBatchIterations();
      this.setViewMode('all');
    }
  }

  // Filtering
  applyFilter(filterValue: string) {
    this.fileDataSource.filter = filterValue.trim().toLowerCase();
  }


  refreshFiles() {
    this.getCertFileFromService();
  }

  downloadFile() {
    const today = moment().format('MMDDYYYY');
    const keyList = ['File Name',
      'Original File Name',
      'Date Received',
      'Date Assigned',
      'Date Completed',
      'Audit Date',
      'Sign Off Date',
      'Assign To',
      'LOB',
      'State/Plan',
      'Iteration',
      'Type',
      'Define Resends',
      'Daily Status',
      'Notes',
      'Claim Count',
      'Approved',
      'In Review',
      'Rejected',
      'Deferred',
      'Open Issues',
      'LH Prep',
      'Comments'
    ];
    const options = {
      decimalseparator: '.',
      useBom: false,
      showLabels: false,
      headers: keyList
    };
    const data: any = [];
    if (this.fileDataSource.filteredData.length !== 0) {
      for (const file of this.fileDataSource.filteredData) {

        const temp = {
          filename: file.allocationFileName,
          originalFilename: file.originalFileName,
          receivedDate: this.getDateString(file.receivedDate),
          assignDate: file.assignedDate,
          completionDate: file.completionDate,
          auditDate: file.auditDate,
          signOffDate: file.signOffDate,
          assignTo: file.testerUserId,
          lineOfBusiness: file.lineOfBusiness,
          statePlan: file.stateOrPlan,
          iteration: file.iteration,
          typeOfFile: file.fileType,
          defineResends: file.defineResends,
          dailyStatus: file.dailyStatus,
          notes: file.notes,
          claimCount: file.claimCount,
          approved: file.approved,
          inReview: file.inReview,
          rejected: file.rejected,
          deferred: file.deferred,
          openIssues: file.openIssues,
          lhPrep: file.lhPrep,
          comments: file.comments,
        };

        data.push(temp);
      }
    }

    for (let i = 0; i < this.batchIteration.length; i++) {
      if (this.batchIteration[i].id === this.currentIterId) {
        this.selectedIterationValue = this.batchIteration[i];
      }
    }
    this.selectedIterationValue.ingestDate  = this.datepipe.transform(
      this.selectedIterationValue.ingestDate, 'MM-dd-yyyy');

    // tslint:disable-next-line:no-unused-expression
    new Angular5Csv(JSON.stringify(data, function (k, v) { return v === undefined ? null : v; }),
     `PPFiles_${this.selectedIterationValue.iteration}_${today}`, options);

  }
  getDateString( date: any) {
    let formattedDate: any = null;
    if ( null != date ) {
    try {
      formattedDate = moment.utc(date).format('YYYY/MM/DD');
    } catch (e) {
      // console.log(e);
      formattedDate = null;
    }
   }
    if ( formattedDate && null != formattedDate &&
        formattedDate.indexOf('Invalid date') === -1 ) {
       return formattedDate;
    } else {
        return null;
    }

  }
  updateDisplay() {
    this.getCertFileFromService();
  }
  /** Filter based on finance flag */
  updateDisplayForFinancialFiles() {
    if (this.showFinancialFiles) {
      this.fileDataSource.data = this.fileDataSource.data.filter(
        (certFileTracker: CertFileTracker) => certFileTracker.financeFlag === true);
    } else {
      this.fileDataSource.data = this.dataBeforeFinanceFilter;
    }
    this.actualFileDataSource = _.cloneDeep(this.fileDataSource); //
  }


  claimPercentComplete(file: CertFileTracker) {
    if (file.claimCount === 0 || file.claimCount === null) {
      return '0.00%';
    } else {
      return ((file.approved + file.rejected + file.inReview + file.deferred) / file.claimCount * 100)
                              .toPrecision(3) + '%';
    }
  }
  claimPercentCompleteValue(file: CertFileTracker) {
    if (file.claimCount === 0 || file.claimCount === null) {
      return 0.00;
    } else {
      return ((file.approved + file.rejected + file.inReview + file.deferred) / file.claimCount * 100).toPrecision(3);
    }
  }
  totalSum(file: CertFileTracker) {
    return (file.approved + file.rejected + file.inReview + file.deferred);
  }

  sortTableData(sort: Sort) {
    if (!sort) { console.log('>>>> sort table false '); return; }
    // console.log('>>>> sort table');
    // console.log('>>>> sort table true');
    // console.log(sort);
    const realDataCopy = _.cloneDeep(this.actualFileDataSource);
    if (sort.direction === '') {
      this.fileDataSource.data  = realDataCopy.data;
      return;
    }
   // this.fileDataSource.data = this.fileDataSource.data.sort((a: CertFileTracker, b: CertFileTracker) => {
    this.fileDataSource.data = realDataCopy.data.sort((a: CertFileTracker, b: CertFileTracker) => {
        const isAsc = sort.direction === 'asc';
        switch (sort.active) {
            case 'File Name':
              console.log('FileName');
              console.log(a);
              console.log(b);
            return this.sorter.compare(a.allocationFileName, b.allocationFileName, isAsc);
            case 'Original File Name':
            return this.sorter.compare(a.originalFileName, b.originalFileName, isAsc );
            case 'Date Received':
            return this.sorter.compare(<Date> moment(a.receivedDate).toDate(), <Date> moment(b.receivedDate).toDate(), isAsc);
            case 'Date Assigned':
            return this.sorter.compare(<Date> moment(a.assignedDate).toDate(), <Date> moment(b.assignedDate).toDate(), isAsc);
            case 'Completion':
            return this.sorter.compare(this.claimPercentCompleteValue(a),
                   this.claimPercentCompleteValue(b), isAsc);
            case 'Date Completed':
            return this.sorter.compare(<Date>moment(a.completionDate).toDate(), <Date>moment(b.completionDate).toDate(), isAsc);
            case 'Audit Date':
            return this.sorter.compare(<Date>moment(a.auditDate).toDate(), <Date>moment(b.auditDate).toDate(), isAsc);
            case 'Sign Off Date':
            return this.sorter.compare(<Date>moment(a.signOffDate).toDate(), <Date>moment(b.signOffDate).toDate(), isAsc);
            case 'Assign To':
            return this.sorter.compare(a.testerUserName, b.testerUserName, isAsc);
            case 'LOB':
            return this.sorter.compare(this.lobNickname(a.lineOfBusiness),
                   this.lobNickname(b.lineOfBusiness), isAsc);
            case 'State/Plan':
            return this.sorter.compare(a.stateOrPlan, b.stateOrPlan, isAsc);
            case 'Iteration':
            return this.sorter.compare(a.iteration, b.iteration, isAsc);
            case 'Type': return this.sorter.compare(a.fileType, b.fileType, isAsc);
            case 'Define Resends': return this.sorter.compare(a.defineResends, b.defineResends, isAsc);
            case 'Daily Status': return this.sorter.compare(a.dailyStatus, b.dailyStatus, isAsc);
            case 'Notes': return this.sorter.compare(a.notes, b.notes, isAsc);
            case 'Claim Count': return this.sorter.compare(+ a.claimCount, + b.claimCount, isAsc);
            case 'Approved': return this.sorter.compare(+ a.approved, + b.approved, isAsc);
            case 'In Review': return this.sorter.compare(+ a.inReview, + b.inReview, isAsc);
            case 'Rejected': return this.sorter.compare(+ a.rejected, + b.rejected, isAsc);
            case 'Deferred': return this.sorter.compare(+ a.deferred, + b.deferred, isAsc);
            case 'Open Issues': return this.sorter.compare(+ a.openIssues, + b.openIssues, isAsc);
            case 'LH Prep': return this.sorter.compare(a.lhPrep, b.lhPrep, isAsc);
            case 'Comments': return this.sorter.compare(a.comments, b.comments, isAsc);
            case 'Sum': return this.sorter.compare(+this.totalSum(a), +this.totalSum(b), isAsc);
            default : return this.sorter.compare(a.allocationFileName, b.allocationFileName, isAsc);
        }
    });
}

  editField(f: CertFileTracker, tabName: string) {
    const recordUsedForEdit = _.cloneDeep(f);
    const recordForEdit = _.cloneDeep(f);
    let t = 0;
    switch (tabName) {
      case 'File Name': t = 0; break;
      case 'Details': t = 1; break;
      case 'Status': t = 2; break;
      case 'Claim Count': t = 3; break;
      case 'Script Management': t = 5; break;
      case 'Open Issues': t = 4; break;
      case 'Daily Status': t = 4; break;
      case 'Comments': t = 4; break;
      case 'Define Resends': t = 4; break;
      case 'Flex': t = 6; break;
    }
    if (this.dialogpopUpPermission === 'None') {
      this.message = 'Access denied to edit this file!!!';
    } else {
      this.message = null;

      if (!this.isPopupOpened) {
        // console.log('>>>>>> popup time : ' + new Date().getTime());
        const dialogRef = this.dialog.open(CertFiletrackerEditComponent, {
          height: '550px',
          width: '850px',
          scrollStrategy: this.overlay.scrollStrategies.block(),
          data: { file: recordForEdit, tab: t }
        });
        dialogRef.afterClosed().subscribe(result => {
          this.isPopupOpened = false;
          if (result && typeof result === 'string' && (result === 'update' || result === 'upload')) {
            console.log('########################## 2', result);
            this.updateDisplay();
          } else {
            // Cancel Action
           const matchedItemIndex = _.findIndex(this.fileDataSource.data, {id: recordForEdit.id});
           console.log('matchedItemIndex', matchedItemIndex);
          // Replace item at index using
             this.fileDataSource.data[matchedItemIndex] = recordUsedForEdit;
            setTimeout(() => {
              this.fileDataSource.data = this.fileDataSource.data;
              this.actualFileDataSource = _.cloneDeep(this.fileDataSource);
            });
          }
        });
      }
    }
  }


  setViewMode(viewMode: string) {
    this.viewMode = viewMode;

    switch (viewMode) {
      case 'all':
        this.fileDisplayedColumns = ['File Name', 'Original File Name', 'Completion', 'Date Received', 'Date Assigned', 'Date Completed',
          'Audit Date', 'Sign Off Date', 'Assign To', 'LOB', 'State/Plan', 'Iteration', 'Type', 'Define Resends', 'Daily Status',
          'Notes', 'Claim Count', 'Approved', 'In Review', 'Rejected', 'Deferred', 'Sum', 'Open Issues', 'LH Prep', 'Comments'];
        break;
      case 'summary':
        this.fileDisplayedColumns = ['File Name', 'Type', 'LOB', 'Status', 'Notes', 'Completion',
        'Claim Count', 'Daily Status', 'Comments', 'Summary'];
        break;
      case 'ard':
        this.fileDisplayedColumns = ['File Name', 'Type', 'LOB', 'Status', 'Notes', 'Claim Count',
          'Approved', 'In Review', 'Rejected', 'Deferred', 'Sum', 'Open Issues', 'Summary'];
        break;
    }
  }

  onChangeIteration(event) {
    this.currentIterId = event.value;
    this.noRecordFound = false;
    this.getCertFileFromService();

  }

  /**
     *
     * Gets the exisitng cert files from the service.
     */
  // Gets the exisitng cert files from the service.
  getCertFileFromService() {
//    this.isLoading = false;
    const loggedInUser = UserModel.newInstance();
    loggedInUser.userId = localStorage.getItem('userId');
    if ( this.busy ) {
      this.busy.unsubscribe(); // Cancelling if ny previous http request is being progress
    }
    this.isLoading = true; // Sets the condition to true to enable the loading animation while data is loaded.
    this.fileDataSource = new MatTableDataSource<CertFileTracker>();
    this.batchRequest = BatchDataModel.newInstance();
    this.batchRequest.batchId = this.currentIterId;
    if (this.showMyFiles) {
      this.batchRequest.testerUserId = localStorage.getItem('userId');
    }
    this.array = [];
      this.busy = this.ppService.getAllBatchFiles(this.batchRequest).subscribe(data => {
        console.log('getAllBatchFiles service invoked');
      this.fileData = <CertFileTracker[]>data;
      // console.log("certFileTracker===="+this.fileData);
      this.isLoading = false; // Sets the loading to false to disable the loading animation and show the data.
      if (this.fileData && this.fileData !== null && this.fileData !== undefined) {
        for (const fileInfo of this.fileData) {
          for (const users of this.userModelList) {
            if (fileInfo.testerUserId === users.userId) {
              fileInfo.testerUserName = users.lastName + ', ' + users.firstName;
            }
            if (fileInfo.supervisorId === users.userId) {
              fileInfo.supervisorName = users.lastName + ', ' + users.firstName;
            }
          }
          if (this.showMyFiles) {
            if (fileInfo.testerUserId === loggedInUser.userId) {
              if (fileInfo.action === '' || fileInfo.action === undefined) {
                fileInfo.action = 'For Testing';
              } else {
                fileInfo.action = fileInfo.action + ', ' + 'For Testing';
              }
            }
            if (fileInfo.reviewer === loggedInUser.userId) {
              if (fileInfo.action === '' || fileInfo.action === undefined) {
                fileInfo.action = 'For Review';
              } else {
                fileInfo.action = fileInfo.action + ', ' + 'For Review';
              }
            }
          }
        }
        this.activatedRoute.queryParams.subscribe(params => {
          this.page = params['page'];
        });
        // check for gbd Files only for Testers
        const gbdFileIndex = this.authorizedPermissionInformationModel.attributePermissions.findIndex(x => x.attributeName === 'GBD');
        if (gbdFileIndex >= 0) {
          this.isGbdFilePermission = this.authorizedPermissionInformationModel.attributePermissions[gbdFileIndex]
                                         .permittedActions.includes('VIEW');
          if (this.isGbdFilePermission) {
            this.fileDataSource.data = this.fileData;
          } else {
            this.fileDataSource.data = this.fileData.filter((certFileTracker: CertFileTracker) => certFileTracker.isGbd === false);
          }
        } else {
          this.fileDataSource.data = this.fileData;
        }
        // End of GBD check
        // check for financial Files only for Testers
        const financialFileIndex = this.authorizedPermissionInformationModel.attributePermissions
                                     .findIndex(x => x.attributeName === 'FINANCIAL');
        if (financialFileIndex >= 0) {
          this.isFinancialFilePermission = this.authorizedPermissionInformationModel
                                               .attributePermissions[financialFileIndex].permittedActions.includes('VIEW');

          if (!this.isFinancialFilePermission) {
            this.fileDataSource.data = this.fileDataSource.data.filter(
              certFileTrackerDataModel => certFileTrackerDataModel.financeFlag === this.isFinancialFilePermission);
          }
        }
        // End of financial check
        // filter for financial files
        this.dataBeforeFinanceFilter = this.fileDataSource.data;
        if (this.showFinancialFiles) {
          this.fileDataSource.data = this.fileDataSource.data.filter(
            (certFileTracker: CertFileTracker) => certFileTracker.financeFlag === true);
        }
        console.log(this.dataBeforeFinanceFilter);
        this.fileDataSource.sort = this.sort;
        this.fileDataSource.paginator = this.paginator;
        this.array = this.fileData;
        this.totalSize = this.array.length;
        this.noRecordFound = false;
        this.actualFileDataSource = _.cloneDeep(this.fileDataSource);
        // this.iterator();
      } else {
        this.noRecordFound = true;
        this.actualFileDataSource = null;
      }
    });

  }

  public handlePage(e: any) {
    this.currentPage = e.pageIndex;
    this.pageSize = e.pageSize;
    this.iterator();
  }



  private iterator() {
    const end: any = (this.currentPage + 1) * this.pageSize;
    const start = this.currentPage * this.pageSize;
    const part = this.array.slice(start, end);
    this.fileDataSource = part;
  }

  loadBatchIterations() {
    this.isLoading = true;
      this.busy = this.ppService.getBatchIterations().subscribe(data => {
        console.log(data);
      this.batchIteration = <BatchDataModel[]>data;
      this.currentIteration = this.batchIteration[0].iteration;
      this.currentIterId = this.batchIteration[0].id;
      this.loadUserList();
    }
    );
  }

  loadUserList() {
    console.log('-------------->', 'loadUserList');
    this.busy = this.authenticationService.loadTestUsers().subscribe(data => {
      this.userModelList = <UserModel[]>data;
      this.getCertFileFromService();
    });
  }

  lobNickname(lob: string) {
    if (lob != null) {
      switch (lob) {
        case 'Commercial': return 'Com';
        case 'Medicaid': return 'Caid';
        case 'Medicare': return 'Care';
        case 'Exchange': return 'Ex';
      }
    }
    return lob;
  }

  getType(fname: string) {
    if (fname != null) {
      const index = this.fileData.findIndex(x => x.allocationFileName === fname);
      const category = this.fileData[index].category;
      const f = this.ppService.getFileMatchType(fname);
      const ft = this.ppService.getFileType(fname);
      switch (f) {
        case 'MISMATCHED': fname = 'MM' + ':' + ft; break;
        case 'MATCHED': fname = 'MA' + ':' + ft; break;
        case 'FALLOUT': fname = 'FO' + ':' + ft; break;
        default : fname = category;
      }
    }
    return fname;
  }

}


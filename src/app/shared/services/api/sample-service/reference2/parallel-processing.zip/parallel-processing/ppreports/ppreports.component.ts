import { Component, OnInit, AfterViewInit, Inject, ElementRef, HostListener } from '@angular/core';
import { get } from 'scriptjs';
import { PpreportsService } from './ppreports.service';
import { WebServiceConfiguration } from '../../../common/configuration/WebServiceConfiguration';
import { ActivatedRoute } from '@angular/router';
// need to call this var tablau
// because it is referencing the tableau js library
declare var tableau: any;
@Component({
  selector: 'app-ppreports',
  templateUrl: './ppreports.component.html',
  styleUrls: ['./ppreports.component.css']
})
export class PpreportsComponent implements OnInit, AfterViewInit {
  tableauPlaceholder: any;
  tableauTicket: any;
  url: any;
  options: any;
  placeholderDiv: any;
  TableauWebServiceURLConfig: any;
  report: any;
  divHeight: String = '';
  // tableauScriptLibraryUrl: any = 'https://tableaudev.anthem.com/javascripts/api/viz_v1.js';
  // tableauScriptLibraryUrl: any = 'https://tableauuat.anthem.com/javascripts/api/viz_v1.js';
  tableauScriptLibraryUrl: any = '';
  host_url: any = '';
  reportType: any = '';
  tableauReportUrl: any = '';
  reportDetails: any = {
    'TestReport': { value: 'TestProgressreport-ByStatus&#47;TestProgressreport-ByStatus' },
    'PostAuditReport': { value: 'Post-Audit&#47;Post-Audit' }, 'PreAuditReport': { value: 'Pre-Audit&#47;Pre-Audit'  },
    'DefectReport': { value: 'DefectReport&#47;DefectReport'}, 'ClaimCountLinks': {
      value: 'ClaimCountlinkstoObservationID&#47;ClaimCountlinkstoObservationID'
    }
  };
  constructor( @Inject(PpreportsService) private preportsService,
   @Inject(ActivatedRoute) private route , @Inject(ElementRef) private elRef) {
    this.initTableauReportConfig();
  }
  initTableauReportConfig() {
    this.TableauWebServiceURLConfig =  WebServiceConfiguration.getEnvSpecificTableauWebServiceURLConfig();
    this.route.queryParams
       .filter(params => params.report)
       .subscribe(params => {
         // console.log(params); // {order: "popular"}
         // console.log(params.report); // popular
         this.report = params.report;
         this.reportType = this.report;
         console.log(this.reportType );
         this.tableauReportUrl = this.TableauWebServiceURLConfig.baseUrl +
                                 this.TableauWebServiceURLConfig.reportUrls[this.reportType] +
                                 this.TableauWebServiceURLConfig.queryString;
                                 console.log(this.tableauReportUrl );
       });
  }
  @HostListener('window:resize', ['$event'])
  getScreenSize(event?) {
    this.divHeight  = (window.innerHeight - 131) + 'px';
  }
  ngOnInit() {
     /* Commenting Script based Loading
    this.tableauScriptLibraryUrl = this.TableauWebServiceURLConfig.tableauScriptLibraryUrl;
    console.log('tableauScriptLibraryUrl ---> ', this.tableauScriptLibraryUrl);
    this.host_url = 'https%3A%2F%2F' + this.TableauWebServiceURLConfig.tableauReportHostName + '%2F';
    console.log('tableau-host_url ---> ', this.host_url);
    */
   this.divHeight  = (window.innerHeight - 131) + 'px';
   // console.log((window.innerHeight - this.elRef.nativeElement.parentNode.querySelector('.menu').offsetHeight);
  }
  ngAfterViewInit(): void {
    /* Commenting Script based Loading
    // For the time being Directly loading Tableau Report - only Tableau users can view it
    this.loadTableauScriptContext();
    */
    // TableauToken based Report view - For the time being , we are commenting this as token is not recieved[issue]
   //  this.getTableauToken();
  }
 getTableauToken() {
  this.preportsService.getTableauTicket().subscribe(
    (response: any) => {
      if (response) {
        this.tableauTicket = response;
        console.log('###############################tableauTicket##################');
        console.log(this.tableauTicket);
        this.loadTableauScriptContext();
      }
    }, (error: any) => {
       console.log(error);
    }
  );
 }
  loadTableauScriptContext() {
    get(this.tableauScriptLibraryUrl, () => {
      console.log('##############Tableau Script Context has been loaded #######################');
    });
  }


}

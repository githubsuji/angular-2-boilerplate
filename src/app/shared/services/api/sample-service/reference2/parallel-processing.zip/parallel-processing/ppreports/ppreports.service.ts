import { Injectable, Inject } from '@angular/core';
import {
  Http,
  Headers, BaseRequestOptions, Request,
  RequestOptions, RequestOptionsArgs,
  RequestMethod,
  Response, URLSearchParams, ResponseContentType
} from '@angular/http';
import { WebServiceConfiguration } from '../../../common/configuration/WebServiceConfiguration';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Subject } from 'rxjs/Subject';
@Injectable()
export class PpreportsService {
  private context: string;
  constructor(@Inject(Http) private http) {
  //  this.context = WebServiceConfiguration.getEnvSpecificWebServiceURL().concat('parallelprocessing/defect');
  this.context = 'https://tableaudev.anthem.com/trusted';
    console.log(this.context);
  }
  getHeaders(): Headers {
    const headers = new Headers();
    // Add default to each HTTP call
    headers.append('Content-Type', 'application/x-www-form-urlencoded');
    return headers;
  }
  getFormData(): FormData {
    const formData = new FormData();
    console.log('UDERID----->' + localStorage.getItem('userId'));
    formData.append('username', localStorage.getItem('userId'));
    formData.append('target_site', 'VoyagerCVS');
    return formData;
  }
  public getTableauTicket() {
    const options = new RequestOptions({ headers: this.getHeaders() });
    return this.http.post(this.context , this.getFormData(), options)
        .pipe(
            map((res: Response) => {
                return res.text();
            }
            ),
            catchError((error: any) => Observable.throw(error || 'Server error'))
        );
}

}

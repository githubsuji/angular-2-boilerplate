// Angular Modules
import { Component, OnInit, Inject, ViewChild, ElementRef, AfterViewInit, ViewEncapsulation } from '@angular/core';
import { take, takeUntil, map, startWith  } from 'rxjs/operators';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource, MatSnackBar, MatSelect } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

// tslint:disable-next-line:import-blacklist

@Component({
    selector: 'financial-analysis-edit',
    templateUrl: './financial-analysis-edit.component.html',
    styleUrls: ['./financial-analysis-edit.component.css'],
    encapsulation: ViewEncapsulation.None
})

export class FinancialAnalysisEditComponent implements OnInit {

    selectedTab: number;
    fieldsArray:any =[];
    // editFinancialAnalysisForm: FormGroup;

    constructor(public dialogRef: MatDialogRef<FinancialAnalysisEditComponent>, 
        @Inject(MAT_DIALOG_DATA) public data: any,
        // private formBuilder: FormBuilder
    ){
        
    }


    ngOnInit() {


        for(let obj in this.data.file){
            let labelValue = { label: obj, value: this.data.file[obj]};
            this.fieldsArray.push(labelValue);
            
          }
    


    //     const f: DT_Model = this.data.file;
    //     this.selectedTab = this.data.tab;
    //     console.log(this.selectedTab);

    //     this.editFinancialAnalysisForm = this.formBuilder.group({
    //         // Mode: Tab 1
    //         Finance_DefectID: new FormControl({value : f.Finance_DefectID}),
    //         RXC_BASIS_TYPE: new FormControl({value : f.RXC_BASIS_TYPE}),
    //         EDW_ANT_BASIS_OF_COST: new FormControl({value : f.EDW_ANT_BASIS_OF_COST}),
    //         RXC_INGREDIENT_COST: new FormControl({value : f.RXC_INGREDIENT_COST}),
    //         EDW_ANT_INGRED_COST: new FormControl({value : f.EDW_ANT_INGRED_COST}),
    //         RXC_FULL_AWP_DIS: new FormControl({value : f.RXC_FULL_AWP_DIS}),
    //         matchRXC_FULL_MACBasisOfCost: new FormControl({value : f.RXC_FULL_MAC}),
    //         RXC_USUAL_CUSTOMARY: new FormControl({value : f.RXC_USUAL_CUSTOMARY}),
    //         EDW_ANT_FULL_AWP_AMT: new FormControl({value : f.EDW_ANT_FULL_AWP_AMT}),
    //         ANT_USUAL_CUSTOMARY: new FormControl({value : f.ANT_USUAL_CUSTOMARY}),
    //         ANT_DISPENSE_QTY: new FormControl({value : f.ANT_DISPENSE_QTY}),
    //         RXC_DISPENSE_QTY: new FormControl({value : f.RXC_DISPENSE_QTY}),
    //         RXC_PRODUCT_DESCRPTN: new FormControl({value : f.RXC_PRODUCT_DESCRPTN}),
    //         // Mode: Tab 2
    //         RXC_GROSS_COST: new FormControl({value : f.RXC_GROSS_COST}),
    //         EDW_ANT_GROSS_COST_LESS_ADMIN_FEE: new FormControl({value : f.EDW_ANT_GROSS_COST_LESS_ADMIN_FEE}),
    //         ANT_DISPENSING_FEE: new FormControl({value : f.ANT_DISPENSING_FEE}), 
    //         RXC_DISPENSING_FEE: new FormControl({value : f.RXC_DISPENSING_FEE}),
    //         ANT_TOTAL_SALES_TAX: new FormControl({value : f.ANT_TOTAL_SALES_TAX}),
    //         RXC_TOTAL_SALES_TAX: new FormControl({value : f.RXC_TOTAL_SALES_TAX}),
    //         ADMIN_FEE_AMT: new FormControl({value : f.ADMIN_FEE_AMT}),
    //         RXC_CLIENT_AMT_DUE: new FormControl({value : f.RXC_CLIENT_AMT_DUE}),
    //         EDW_ANT_CLIENT_AMT_DUE_LESS_ADM: new FormControl({value : f.EDW_ANT_CLIENT_AMT_DUE_LESS_ADM}),
    //         ANT_PATIENT_PAY : new FormControl({value : f.ANT_PATIENT_PAY}),
    //         RXC_PATIENT_PAY: new FormControl({value : f.RXC_PATIENT_PAY}),
    //         ANT_COPAY_AMOUNT: new FormControl({value : f.ANT_COPAY_AMOUNT}),
    //         RXC_COPAY_AMOUNT: new FormControl({value : f.RXC_COPAY_AMOUNT}),
    //         RXC_DEDUCTIBLE: new FormControl({value : f.RXC_DEDUCTIBLE}),
    //         // Mode: Tab 3
    //         ANT_DEDUCTIBLE: new FormControl({value : f.ANT_DEDUCTIBLE}),
    //         ANT_OTHER_PAY: new FormControl({value : f.ANT_OTHER_PAY}),
    //         ANT_MEMBER_ID: new FormControl({value : f.ANT_MEMBER_ID}),
    //         ANT_PRESCRIPTION_REF: new FormControl({value : f.ANT_PRESCRIPTION_REF}),
    //         ANT_DATE_OF_SERVICE: new FormControl({value : f.ANT_DATE_OF_SERVICE}),
    //         RXC_DEL: new FormControl({value : f.RXC_DEL}),
    //         RXC_DRUG_INDICATOR: new FormControl({value : f.RXC_DRUG_INDICATOR}),
    //         ANT_PHARMACY_NPI_ID: new FormControl({value : f.ANT_PHARMACY_NPI_ID}),
    //         ANT_HRA: new FormControl({value : f.ANT_HRA}),
    //         RXC_HRA: new FormControl({value : f.RXC_HRA}),
    //         RXC_RXOTC: new FormControl({value : f.RXC_RXOTC}),
    //         RXC_TRANSACTION_ID: new FormControl({value : f.RXC_TRANSACTION_ID}),
            
    //     });
    // }

    
    }


    close() {
        this.dialogRef.close();
    }

}
import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { RuleSet } from '../../../model/ppexecuterule/RuleSet';
import { RuleBatch } from '../../../model/ppexecuterule/RuleBatch';
import { RuleBatchLob } from '../../../model/ppexecuterule/RuleBatchLob';
import { RuleBatchFileEvaluationDataModel } from '../../../model/ppexecuterule/RuleBatchFileEvaluationDataModel';
import { RuleExecuteDataModel } from '../../../model/ppexecuterule/RuleExecuteDataModel';
import { AuthService } from '../../../business/modules/service/authentication/AuthService';
import { AuthorizedPermissionInformationModel } from '../../../model/user/AuthorizedPermissionInformation';
import { ParallelProcessingService } from '../../../../shared/services/parallel-processing.service';

@Component({
  moduleId: module.id,
  // tslint:disable-next-line:component-selector
  selector: 'ruleExecute',
  templateUrl: './ruleExecute.html',
  styleUrls: ['./ruleExecute.css'],
  encapsulation: ViewEncapsulation.None
})
export class RuleExecuteComponent implements OnInit {

  private router: Router;
  private activatedRoute: ActivatedRoute;
  authorisationService: AuthService;
  authorizedPermissionInformationModel: AuthorizedPermissionInformationModel;
  busy: Subscription;
  testSetId: string;
  userRole: string;
  userId: string;
  ruleSetId: string;
  batchOrWeekId: string;
  fileId: string;
  batchOrWeekList: RuleBatch[];
  fileList: any[];
  errors: string[];
  messages: string[];
  errorTemplate: Boolean = false;
  successTemplate: Boolean = false;
  warningError: Boolean = false;
  disableExecuteButton: Boolean = false;
  isValidInputFields: Boolean = true;
  unexpectedError: Boolean = false;
  unexpectedErrorMessage: string;
  ruleSetList: RuleSet[];
  dropdownRuleSetList: RuleSet[];
  dropdownBatchList: RuleBatch[];
  dropdownFileList: RuleBatchLob[];
  ruleExecuteDataModel: RuleExecuteDataModel;
  ruleBatchFileEvaluationDataModel: RuleBatchFileEvaluationDataModel;
  resourceCode = 'SCR009';
  displayUIComponents: Boolean = false;
  message: string;
  disableRulestDropDown = false;
  disableBatchDropDown = false;
  disableFileDropDown = false;

  constructor(router: Router, activatedRoute: ActivatedRoute,
     @Inject(ParallelProcessingService) private ppService,
      authorisationService: AuthService) {
    this.router = router;
    this.activatedRoute = activatedRoute;
    this.authorisationService = authorisationService;
  }

  ngOnInit() {
    this.userRole = localStorage.getItem('userRole');
    this.userId = localStorage.getItem('userId');
    // Check Resource Access Permission
    // this.authorizedPermissionInformationModel = JSON.parse(localStorage.getItem('AuthorizationModelScreen9'));
    this.busy = this.authorisationService.getUserGroupPermissions(this.userId, this.resourceCode).subscribe(data => {
      this.authorizedPermissionInformationModel = <AuthorizedPermissionInformationModel>data;
      if (this.authorizedPermissionInformationModel &&
        this.authorizedPermissionInformationModel.resourcePermissions != null &&
        this.authorizedPermissionInformationModel.resourcePermissions !== undefined &&
        this.authorizedPermissionInformationModel.resourcePermissions.length > 0) {
        this.message = '';
        this.displayUIComponents = true;
      } else {
        this.message = 'Access Denied!!!';
        this.displayUIComponents = false;
      }

      if (this.displayUIComponents) {
        this.activatedRoute.queryParams.subscribe((params) => {
          this.testSetId = params['testSetId'];
        });

        this.resetAllFlags();
        this.fetchRuleSetList();
        this.findBatchWeekToExecute();
        this.ruleSetId = 'select';
        this.batchOrWeekId = 'select';
        this.fileId = 'select';
        this.toggleButtonDisable();
        this.setAttribureAccessPermissions();
      }

    });

  }

  executeRuleFile() {
      this.disableExecuteButton = true;
      this.resetAllFlags();

      this.ruleBatchFileEvaluationDataModel = RuleBatchFileEvaluationDataModel.newInstance();
      this.ruleBatchFileEvaluationDataModel.onDemandIndicator = true;
      this.ruleBatchFileEvaluationDataModel.batchFileLobId = this.fileId;
      this.ruleBatchFileEvaluationDataModel.rulesetVersionID = this.ruleSetId;
      this.ruleBatchFileEvaluationDataModel.createdByUserId = this.userId;

      // this.busy = this.ruleExecuteService
      this.busy = this.ppService
      .pushRuleFileToExecute(this.ruleBatchFileEvaluationDataModel)
      .subscribe(data => {
        const ruleBatchFileEvaluationResponse = <RuleBatchFileEvaluationDataModel>data;
        this.successTemplate = true;
      },
      error => {
        this.unexpectedError = true;
        this.unexpectedErrorMessage = 'Unexpected Error Occurred!';
      });
  }

  fetchRuleSetList() {
    this.busy = this.ppService.fetchRuleSetList().subscribe( data => {
    // this.busy = this.ruleExecuteService.fetchRuleSetList().subscribe( data => {
      this.dropdownRuleSetList = <RuleSet[]>data;
      if (this.dropdownRuleSetList !== undefined && this.dropdownRuleSetList != null && this.dropdownRuleSetList.length > 0 ) {
        this.ruleSetList = [];
        for (let i = 0 ; i < this.dropdownRuleSetList.length; i++) {
          this.ruleSetList.push(this.dropdownRuleSetList[i]);
        }
      } else {
        this.unexpectedError = true;
        this.unexpectedErrorMessage = 'No rules available to select.';
      }
      }, error => {
        this.unexpectedError = true;
        this.unexpectedErrorMessage = 'Unexpected Error Occurred!';
    });
  }

  findBatchWeekToExecute() {

    // this.busy = this.ruleExecuteService.findBatchList().subscribe( data => {
      this.busy = this.ppService.findBatchList().subscribe( data => {
      this.dropdownBatchList = <RuleBatch[]>data;
      if (this.dropdownBatchList !== undefined && this.dropdownBatchList != null && this.dropdownBatchList.length > 0 ) {
        this.batchOrWeekList = [];
        for (let i = 0 ; i < this.dropdownBatchList.length; i++) {
          this.batchOrWeekList.push(this.dropdownBatchList[i]);
        }
      } else {
        this.unexpectedError = true;
        this.unexpectedErrorMessage = 'No batches available to select.';
      }
      }, error => {
        this.unexpectedError = true;
        this.unexpectedErrorMessage = 'Unexpected Error Occurred!';
    });
  }

  findFileListToExecute(batchId: string) {
    this.fileList = [];
    this.fileId = 'select';

    if (batchId !== 'select') {
      // this.busy = this.ruleExecuteService.findFileList(batchId).subscribe( data => {
      this.busy = this.ppService.findFileList(batchId).subscribe( data => {
        this.dropdownFileList = <RuleBatchLob[]>data;
        if (this.dropdownFileList !== undefined && this.dropdownFileList != null && this.dropdownFileList.length > 0 ) {
          this.fileList = [];
          for (let i = 0 ; i < this.dropdownFileList.length; i++) {
            this.fileList.push(this.dropdownFileList[i]);
          }
        } else {
          this.unexpectedError = true;
          this.unexpectedErrorMessage = 'No files available to select.';
        }
        }, error => {
          this.unexpectedError = true;
          this.unexpectedErrorMessage = 'Unexpected Error Occurred!';
      });
    }
  }

  toggleButtonDisable() {
    this.resetAllFlags();
    this.disableExecuteButton = true;
    if (this.ruleSetId !== 'select' && this.batchOrWeekId !== 'select'
        && this.fileId !== 'select') {
      this.disableExecuteButton = false;
    }
  }

  resetAllFlags() {
    this.unexpectedError = false;
    this.successTemplate = false;
    this.errorTemplate = false;
  }

  setAttribureAccessPermissions() {
      const attrPermTuple:  [string, number][] = [['SELECT RULESET', 1],
                   ['SELECT BATCH WEEK', 2],
                   ['SELECT FILE', 3],
                   ['EXECUTE', 4]
                 ];

    // checking for attribute permissions
      if (this.authorizedPermissionInformationModel.attributePermissions.length > 0 ) {
          let attrPermIndex = -1 ;
          let isEnable = false;
          for (const val of attrPermTuple) {
              console.log('>>>>>> Field   ' + val[0]);
              console.log('>>>>>> index >>> ' + val[1]);
               attrPermIndex = this.authorizedPermissionInformationModel.attributePermissions.findIndex(x => x.attributeName === val[0]);
               if (attrPermIndex > -1) {
                  isEnable = this.authorizedPermissionInformationModel.attributePermissions[attrPermIndex].permittedActions.includes('EDIT');
               }
               switch (val[1]) {
                  case 1: {
                      this.disableRulestDropDown = !isEnable;
                      break;
                  }
                  case 2: {
                      this.disableBatchDropDown = !isEnable;
                     break;
                  }
                  case 3: {
                      this.disableFileDropDown = !isEnable;
                     break;
                  }
                  case 4: {
                      this.disableExecuteButton =  !isEnable;
                     break;
                  }
               } // end of switch
               isEnable = false;
            } // end of for
          } // end of if attr length

  }

}

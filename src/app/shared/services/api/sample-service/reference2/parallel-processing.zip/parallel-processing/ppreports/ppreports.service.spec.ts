import { TestBed, inject } from '@angular/core/testing';

import { PpreportsService } from './ppreports.service';

describe('PpreportsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PpreportsService]
    });
  });

  it('should be created', inject([PpreportsService], (service: PpreportsService) => {
    expect(service).toBeTruthy();
  }));
});

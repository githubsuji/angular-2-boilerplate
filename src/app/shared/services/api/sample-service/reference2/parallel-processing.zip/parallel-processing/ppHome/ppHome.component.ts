import { Component, ViewEncapsulation, OnInit, TemplateRef, Type } from '@angular/core';
import { UserModel } from '../../../model/user/UserModel';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { Subscription } from 'rxjs/';
import { DashboardService } from '../../../business/modules/service/dashboard/DashboardService';
import { DashboardModel } from '../../../model/dashboard/DashboardModel';
import { AuthService } from '../../../business/modules/service/authentication/AuthService';
import { AuthorizedPermissionInformationModel } from '../../../model/user/AuthorizedPermissionInformation';
import { RxSmartPermissionModel } from '../../../model/util/RxSmartPermission';
import { AuthorizedUserModel } from '../../../model/user/AuthorizedUserModel';
import { WebServiceConfiguration } from '../../../common/configuration/WebServiceConfiguration';


@Component({
    moduleId: module.id,
    selector: 'parallelProcess',
    templateUrl: './ppHome.html',
    styleUrls: ['./ppHome.css'],
    encapsulation: ViewEncapsulation.None
})
export class PPHomeComponent implements OnInit {

    TableauWebServiceURLConfig: any;
    private router: Router;
    busy: Subscription;
    dashboardModel: DashboardModel;
    errorMessage: string;
    testSetId: string;
    authorisationService: AuthService;
    authorizedPermissionInformationModel: AuthorizedPermissionInformationModel;
    message: string;
    fileTrackerDisplayPermission: Boolean = false;
    viewAllocDisplayPermission: Boolean = false;
    detailedViewDisplayPermission: Boolean = false;
    uploadDisplayPermission: Boolean = false;
    defectsDisplayPermission: Boolean = false;
    testingStatusDisplayPermission: Boolean = false;
    financialDisplayPermission: Boolean = false;
    summaryDisplayPermission: boolean = false;
    uploadRuleDisplayPermission: Boolean = false;
    executeRuleDisplayPermission: Boolean = false;
    viewRuleDisplayPermission: Boolean = false;
    memberEligibilityDisplayPermission = false;
    PP_MenuPermissionScreen1: Boolean = false
    loggedInUser : UserModel;

    constructor(router: Router, authorisationService: AuthService) {
        this.router = router;
        this.authorisationService = authorisationService;
        this.TableauWebServiceURLConfig =  WebServiceConfiguration.getEnvSpecificTableauWebServiceURLConfig();
    }
    getTableauReportUrl(reportType: any) {
        const tableauReportUrl: any = this.TableauWebServiceURLConfig.baseUrl +
                                 this.TableauWebServiceURLConfig.reportUrls[reportType] +
                                 this.TableauWebServiceURLConfig.queryString;
        return  tableauReportUrl;
    }
    
	/**
	 * Init  Dashboard
	 */
    ngOnInit() {
        this.authorizedPermissionInformationModel = JSON.parse(localStorage.getItem('AuthorizationModelScreen1'));
        console.log(this.authorizedPermissionInformationModel);
        if (this.authorizedPermissionInformationModel &&
            this.authorizedPermissionInformationModel.resourcePermissions != null &&
            this.authorizedPermissionInformationModel.resourcePermissions != undefined &&
            this.authorizedPermissionInformationModel.resourcePermissions.length > 0) {
            this.PP_MenuPermissionScreen1 = this.authorizedPermissionInformationModel.resourcePermissions[0].permittedActions.includes('VIEW');
        }
        if (this.PP_MenuPermissionScreen1 === false) {
            this.message = "Access Denied!!!"
        } else {
            this.message = null;
            this.loggedInUser = UserModel.newInstance();
            this.loggedInUser.userId = localStorage.getItem('userId');
            this.loggedInUser.userGroup = localStorage.getItem('userRole');

            const resourceCodes: any = ["SCR002", "SCR006"];
            resourceCodes.forEach(resourceCode => {
                this.getUserGroupPermission(resourceCode);

            });

            /* attribute permission block */
            //let resourceCode = "SCR001";
            var attrPermTuple: [string, number][];

            attrPermTuple = [["FILE TRACKER", 1],
            ["DEFECTS", 2],
            ["UPLOAD RULE", 3],
            ["EXECUTE RULE", 4],
            ["VIEW RULE STATUS", 5],
            ["TESTING STATUS REPORT", 6],
            ["FINANCIAL REPORT", 7],
            ["SUMMARY REPORT", 8],
            ["MEMBER ELIGIBILTY SEARCH", 9]
            ];

            //checking for attribute permissions
            if (this.authorizedPermissionInformationModel.attributePermissions &&
                this.authorizedPermissionInformationModel.attributePermissions.length > 0) {
                let attrPermIndex = -1;
                let isEnable = false;
                for (var val of attrPermTuple) {

                    attrPermIndex = this.authorizedPermissionInformationModel.attributePermissions.findIndex(x => x.attributeName === val[0]);
                    if (attrPermIndex > -1) {
                        isEnable = this.authorizedPermissionInformationModel.attributePermissions[attrPermIndex].permittedActions.includes('EDIT');
                    }
                    switch (val[1]) {
                        case 1: {
                            this.fileTrackerDisplayPermission = isEnable;

                            break;
                        }
                        case 2: {
                            this.defectsDisplayPermission = isEnable;
                            break;
                        }
                        case 3: {
                            this.uploadRuleDisplayPermission = isEnable;
                            break;
                        }
                        case 4: {
                            this.executeRuleDisplayPermission = isEnable;
                            break;
                        }
                        case 5: {
                            this.viewRuleDisplayPermission = isEnable;
                            break;
                        }
                        case 6: {
                            this.testingStatusDisplayPermission = isEnable;
                            break;
                        }
                        case 7: {
                            this.financialDisplayPermission = isEnable;
                            break;
                        }
                        case 8: {
                            this.summaryDisplayPermission = isEnable;
                            break;
                        }
                        case 9: {
                            this.memberEligibilityDisplayPermission = isEnable;
                            break;
                        }
                    } //end of switch
                    isEnable = false;
                } // end of for
            } //end of if attr length
            //PP Rule upload page testId
            this.testSetId = 'DummyID';
            this.getReviewrList();
            this.getUserList();
        }
    }
    getUserList() {
        console.log(">>> sessionStorage.getItem : " + sessionStorage.getItem('allUserList'));
        if (null === sessionStorage.getItem('allUserList')) {
            let rxSmartPermission = RxSmartPermissionModel.newInstance();
            rxSmartPermission.resourceCode = 'SCR002';
            rxSmartPermission.actionCode = ['VIEW'];
            rxSmartPermission.attributeName = 'PP_POPUP_GLOBAL_DATA';
            // this.getUsersInDropDown();
            this.authorisationService.getUsers(rxSmartPermission).subscribe(data => {
                const reviewerUserModelList = <AuthorizedUserModel[]>data;
                sessionStorage.setItem('allUserList', JSON.stringify(reviewerUserModelList));
                console.log(">>> sessionStorage.getItem : " + sessionStorage.getItem('allUserList'));
            });
        }
    }

    getReviewrList() {
        console.log(">>> sessionStorage.getItemR : " + sessionStorage.getItem('reviewerList'));
 
        if (null === sessionStorage.getItem('reviewerList')) {
            let rxSmartPermission = RxSmartPermissionModel.newInstance();
            rxSmartPermission.resourceCode = 'SCR002';
            rxSmartPermission.actionCode = ['VIEW'];
            rxSmartPermission.attributeName = 'REVIEWER';
            this.authorisationService.getUsers(rxSmartPermission).subscribe(data => {
                const userModelList = <AuthorizedUserModel[]>data;
                sessionStorage.setItem('reviewerList', JSON.stringify(userModelList));
                console.log(">>> sessionStorage.getItemR : " + sessionStorage.getItem('reviewerList'));
            });
        }
    }


    getUserGroupPermission(rCode: string) {
        console.log("getUserGroupPermissions" + rCode);
        let tempModel: any;
        if (rCode === "SCR002") {
            tempModel = localStorage.getItem('AuthorizationModelScreen2');
        } else {
            tempModel = localStorage.getItem('AuthorizationModelScreen6');
        }
        if (null === tempModel) {
            this.busy = this.authorisationService.getUserGroupPermissions(this.loggedInUser.userId, rCode).subscribe(data => {
                let authorizedPermissionInformationModel = <AuthorizedPermissionInformationModel>data;


                if (rCode === "SCR002") {
                    localStorage.setItem('AuthorizationModelScreen2', JSON.stringify(authorizedPermissionInformationModel));
                }
                if (rCode === "SCR006") {
                    localStorage.setItem('AuthorizationModelScreen6', JSON.stringify(authorizedPermissionInformationModel));
                }
            });
        }
    }



    }



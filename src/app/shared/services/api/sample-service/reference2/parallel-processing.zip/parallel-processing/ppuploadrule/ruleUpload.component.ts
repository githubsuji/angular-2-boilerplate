import { Component, ViewEncapsulation, OnInit, TemplateRef, Type } from '@angular/core';
import { Router, ActivatedRoute } from "@angular/router";
import { Subscription } from 'rxjs/';
import { MatSnackBar } from '@angular/material';
import { RuleUploadService } from '../../../business/modules/service/ppuploadrule/RuleUploadService';
import { RuleUploadDataModel } from '../../../model/ppuploadrule/RuleUploadDataModel';
import { ServiceResponseMessageModel } from '../../../model/util/ServiceResponseMessageModel';
import { AuthService } from '../../../business/modules/service/authentication/AuthService';
import { AuthorizedPermissionInformationModel } from '../../../model/user/AuthorizedPermissionInformation';

import * as _ from 'lodash';

@Component({
  moduleId: module.id,
  selector: 'ruleUpload',
  templateUrl: './ruleUpload.html',
  styleUrls: ['./ruleUpload.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class RuleUploadComponent implements OnInit {

  private ruleUploadService: RuleUploadService;
  private router: Router;
  private activatedRoute: ActivatedRoute;
  private currentRuleFileUpload: File;
  private selectedFiles: FileList;
  busy: Subscription;
  testSetId: string;
  userRole: string;
  userId: string;
  errors: string[];
  messages: string[];
  errorTemplate: Boolean = false;
  successTemplate: Boolean = false;
  successSTTemplate: Boolean = false;
  warningError: Boolean = false;
  disableUploadButton: Boolean = true;
  ruleUploadDataModel: RuleUploadDataModel;
  serviceResponseMessageModel: ServiceResponseMessageModel;
  authorisationService: AuthService;
  authorizedPermissionInformationModel: AuthorizedPermissionInformationModel;
  viewRuleUploadPage: Boolean = false;
  uploadButtonDisplayPermission: Boolean = false;
  DownloadLinkDisplayPermission: Boolean = false;
  PP_MenuPermissionScreen7: Boolean = false;
  message: string;
  operationType: string;
  displayUploadPanel: Boolean = false;
  displaySyncPanel: Boolean = false;
  syncTriggerPermission: Boolean = true;
  syncDownloadPermission: Boolean = true;

  constructor(router: Router, activatedRoute: ActivatedRoute,
    private snackBar: MatSnackBar, ruleUploadService: RuleUploadService, authorisationService: AuthService) {
    this.router = router;
    this.activatedRoute = activatedRoute;
    this.ruleUploadService = ruleUploadService;
    this.authorisationService = authorisationService;
  }

  ngOnInit() {
    //this.authorizedPermissionInformationModel = JSON.parse(localStorage.getItem('AuthorizationModelScreen7'));
    this.userId = localStorage.getItem('userId');
    this.busy = this.authorisationService.getUserGroupPermissions(this.userId, "SCR007").subscribe(data => {
      this.authorizedPermissionInformationModel = <AuthorizedPermissionInformationModel>data;
      if (this.authorizedPermissionInformationModel &&
        this.authorizedPermissionInformationModel.resourcePermissions != null &&
        this.authorizedPermissionInformationModel.resourcePermissions != undefined &&
        this.authorizedPermissionInformationModel.resourcePermissions.length > 0) {
        this.PP_MenuPermissionScreen7 = this.authorizedPermissionInformationModel.resourcePermissions[0].permittedActions.includes('VIEW');
      }

      if (this.PP_MenuPermissionScreen7 === false) {
        this.message = "Access Denied!!!"
      } else {

        this.userRole = localStorage.getItem('userRole');

        this.activatedRoute.queryParams.subscribe((params) => {
          this.testSetId = params['testSetId'];
        });

        /* attribute permission block */

        var attrPermTuple: [string, number][];
        //let fieldPermissions: [attrPermTuple] [];
        attrPermTuple = [['UPLOAD', 1], ['DOWNLOAD LATEST RULE SET', 2]];


        //checking for attribute permissions
        if (this.authorizedPermissionInformationModel.attributePermissions != undefined && this.authorizedPermissionInformationModel.attributePermissions.length > 0) {
          let attrPermIndex = -1;
          let isEnable = false;
          for (var val of attrPermTuple) {
            console.log('>>>>>> Field   ' + val[0]);
            console.log('>>>>>> index >>> ' + val[1]);
            attrPermIndex = this.authorizedPermissionInformationModel.attributePermissions.findIndex(x => x.attributeName === val[0]);
            if (attrPermIndex > -1) {
              isEnable = this.authorizedPermissionInformationModel.attributePermissions[attrPermIndex].permittedActions.includes('EDIT');
            }
            switch (val[1]) {
              case 1: {
                this.uploadButtonDisplayPermission = isEnable;
                break;
              }
              case 2: {
                this.DownloadLinkDisplayPermission = isEnable;
                break;
              }
            } //end of switch
            isEnable = false;
          } // end of for
        } //end of if attr length
      }
    });
  }

  showParallelProcessHome() {
    this.router.navigate(['/landing/parallelProcess']);
  }

  enableUpload() {
    this.disableUploadButton = false;
  }

  selectRuleFile(event) {
    if (event.target.files && event.target.files[0]) {
      let file = event.target.files[0];
      //if((file.type == "application/vnd.ms-excel") || (file.type == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
      if (file.type == 'application/json') {
        this.warningError = false;
        this.disableUploadButton = false;
      } else {
        this.warningError = true;
        this.disableUploadButton = true;
      }
    }
    this.errorTemplate = false;
    this.successTemplate = false;
    this.selectedFiles = event.target.files;

    if (this.currentRuleFileUpload != null || this.currentRuleFileUpload != undefined) {
      this.currentRuleFileUpload = null;
    }
    this.currentRuleFileUpload = this.selectedFiles.item(0);
  }

  uploadRuleFile() {
    this.disableUploadButton = true;
    this.errors = null;
    if (this.operationType == '1') {
      this.uploadTacRule();
    } else {
      this.uploadRXSmartRule();
    }
  }

  uploadTacRule() {
    this.busy = this.ruleUploadService
      .pushRuleFileToStorage(this.currentRuleFileUpload, this.userId)
      .subscribe(data => {
        this.serviceResponseMessageModel = data;
        if (this.serviceResponseMessageModel.successIndicator == 'Y') {
          //success code goes here
          this.successTemplate = true;
        } else {
          this.errorTemplate = true;
        }
      },
        error => {
          this.errors = [];
          this.errors.push('Unexpected Error Occurred!');
        });
  }

  uploadRXSmartRule() {
    this.busy = this.ruleUploadService
      .rxsmartRuleUpload(this.currentRuleFileUpload, this.userId)
      .subscribe(data => {
        this.serviceResponseMessageModel = data;
        if (this.serviceResponseMessageModel.successIndicator == 'Y') {
          // success code goes here
          this.successTemplate = true;
        } else {
          this.errorTemplate = true;
        }
      },
        error => {
          this.errors = [];
          this.errors.push('Unexpected Error Occurred!');
        });
  }

  dowloadRuleSetTemplete() {
    console.log('>>>>>>>>> ' + this.operationType);
    if (this.operationType == '1') {
      console.log('>>>>>>>>> ' + 1);
      this.downloadTacRuleset();
    } else {
      console.log('>>>>>>>>> ' + 2);
      this.downloadSyncRuleset();
    }
  }


  downloadTacRuleset() {
    this.busy = this.ruleUploadService.downloadTacRules().subscribe(data => {
      // console.log(" >>>downloadTacRuleset ");
      // console.log(data.body.size);
      if (data.body.size == 0) {
        this.errors = [];
        this.errors.push('Currently Active Ruleset is in Rxsmart Ruleset Format !!!');
      } else {
        if (window.navigator.msSaveOrOpenBlob) // IE & Edge
        {
          // msSaveBlob only available for IE & Edge
          window.navigator.msSaveBlob(data.body, 'TacRuleSet' + '.json');
        } else {
          let blob = new Blob([data.body], { type: 'application/json' });
          let downloadLink = document.createElement('a');
          downloadLink.href = URL.createObjectURL(blob);
          downloadLink.download = 'TacRuleSet';
          document.body.appendChild(downloadLink);
          downloadLink.click();
        }
      }
    });


  }

  showUploadSyncRule(val: string) {
    this.operationType = val;
    this.errors = null;
    if ((this.operationType == '1') || (this.operationType == '2')) {
      this.displayUploadPanel = true;
      this.displaySyncPanel = false;
    } else if (this.operationType == '3') {
      this.displayUploadPanel = false;
      this.displaySyncPanel = true;
    }
    this.errorTemplate = false;
    this.successTemplate = false;
  }

  syncRuleSet() {
    this.syncTriggerPermission = false;
    this.errorTemplate = false;
    this.successSTTemplate = false;

    this.busy = this.ruleUploadService
      .triggerSynch().subscribe(data => {

        this.serviceResponseMessageModel = data;
        if (this.serviceResponseMessageModel.successIndicator == 'Y') {
          // success code goes here
          this.successSTTemplate = true;
        } else {
          this.errorTemplate = true;
        }
        this.syncTriggerPermission = true;
      },
        error => {
          this.errors = [];
          this.errors.push('Unexpected Error Occurred!');

          this.syncTriggerPermission = true;
        });

  }

  downloadSyncRuleset() {
    this.errorTemplate = false;
    this.successSTTemplate = false;
    this.snackBar.dismiss();

    // var result = this.ruleUploadService.downloadSynchRuleSet();
    this.busy = this.ruleUploadService.downloadSynchRuleSet().subscribe(data => {

      // console.log(" >>>downloadsyncRuleset ");
      // console.log(data.body.size);
      if (data.body.size == 0) {
        this.errors = [];
        this.errors.push('Unable to download Rxsmart Ruleset Format !!!');
      } else {
        let filename = '';
        if (this.operationType == '2') {
          filename = 'RxSmartRuleset';
        } else {
          filename = 'SynchedRuleset';
        }
        if (window.navigator.msSaveOrOpenBlob) // IE & Edge
        {
          // msSaveBlob only available for IE & Edge
          window.navigator.msSaveBlob(data.body, filename + '.json');
        } else {
          const blob = new Blob([data.body], { type: 'application/json' });
          const downloadLink = document.createElement('a');
          downloadLink.href = URL.createObjectURL(blob);
          downloadLink.download = filename;
          document.body.appendChild(downloadLink);
          downloadLink.click();
        }
        this.snackBar.open('Successfully Downloaded!!', 'Close', {
          duration: 2000
        });
      }
    });

  }

}

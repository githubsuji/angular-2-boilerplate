import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  Inject,
  ViewEncapsulation
} from '@angular/core';
// tslint:disable-next-line:import-blacklist
import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { ENTER, COMMA } from '@angular/cdk/keycodes';

/** Forms */
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

/** Angular Material */
import {
  MatAutocompleteSelectedEvent,
  MatChipInputEvent,
  MatDialogRef,
  MatTableDataSource,
  MatSnackBar,
  MAT_DIALOG_DATA,
  ShowOnDirtyErrorStateMatcher,
  MatChipList
} from '@angular/material';

/** Models */
import { Defect } from '../../../model/defect/defect';
import { TacUser } from '../../../model/tacUser/tacUser';

/** Services */
import { AuthenticationService } from '../../../business/modules/service/authentication/AuthenticationService';
import { DefectService } from '../../../business/modules/service/fileTracking/cert-defect.service';
import { AuthService } from '../../../business/modules/service/authentication/AuthService';
import { ParallelProcessingService } from '../../../../shared/services/parallel-processing.service';

@Component({
  selector: 'app-impediment-create',
  templateUrl: './impediment-create.component.html',
  styleUrls: ['../old-tac-styling.css', './impediment-create.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ImpedimentCreateComponent implements OnInit {
  newDefectForm: FormGroup;
  smeArray: string[] = [];
  defectNumbers: string[] = [];
  // certFiles: CertFileTracker[] = [];
  defects = new Array<Defect>();
  fileLength = 0;
  selectable = true;
  removable = true;
  removableFiles = true;
  visible = true;
  addOnBlur = false;
  boolCVS: string = null;
  boolBBT: string = null;
  boolTrack: string = null;
  boolAED = false;
  matcher = new ShowOnDirtyErrorStateMatcher();
  selectedTab: number;
  separatorKeysCodes: number[] = [ENTER, COMMA];
  filePrefix = ['FO', 'Ma', 'MM'];
  fileTypes = ['PP', 'PR', 'RP', 'RR'];
  lobs = ['Commercial', 'Exchange', 'Medicaid'];
  boolStrings = ['True', 'False'];
  states: string[] = [
    'Alabama',
    'Alaska',
    'American Samoa',
    'Arizona',
    'Arkansas',
    'California',
    'Colorado',
    'Connecticut',
    'Delaware',
    'District of Columbia',
    'Federated States of Micronesia',
    'Florida',
    'Georgia',
    'Guam',
    'Hawaii',
    'Idaho',
    'Illinois',
    'Indiana',
    'Iowa',
    'Kansas',
    'Kentucky',
    'Louisiana',
    'Maine',
    'Marshall Islands',
    'Maryland',
    'Massachusetts',
    'Michigan',
    'Minnesota',
    'Mississippi',
    'Missouri',
    'Montana',
    'Nebraska',
    'Nevada',
    'New Hampshire',
    'New Jersey',
    'New Mexico',
    'New York',
    'North Carolina',
    'North Dakota',
    'Northern Mariana Islands',
    'Ohio',
    'Oklahoma',
    'Oregon',
    'Palau',
    'Pennsylvania',
    'Puerto Rico',
    'Rhode Island',
    'South Carolina',
    'South Dakota',
    'Tennessee',
    'Texas',
    'Utah',
    'Vermont',
    'Virgin Island',
    'Virginia',
    'Washington',
    'West Virginia',
    'Wisconsin',
    'Wyoming'
  ];
  stateChips: string[] = [];
  rxrCodeChips: string[] = [];
  antCodeChips: string[] = [];
  lobChips: string[] = [];
  fileTypeChips: string[] = [];
  fileChips: string[] = [];
  defectNumberChips: string[] = [];
  jiraIdChips: string[] = [];
  goLiveDateChips: string[] = [];
  initArray: string[] = [];

  filteredStates: Observable<string[]>;
  filteredLOBs: Observable<string[]>;
  filteredFiles: Observable<string[]>;
  filteredUsers: Observable<string[]>;
  filteredDefectNumbers: Observable<Object[]>;
  permissionMap: Map<string, string[]>;

  @ViewChild('stateInput') stateInput: ElementRef;
  @ViewChild('rxrCodeInput') rxrCodeInput: ElementRef;
  @ViewChild('antCodeInput') antCodeInput: ElementRef;
  @ViewChild('fileInput') fileInput: ElementRef;
  @ViewChild('lobInput') lobInput: ElementRef;
  @ViewChild('fileTypeInput') fileTypeInput: ElementRef;
  @ViewChild('userInput') userInput: ElementRef;
  @ViewChild('iterationInput') iterationInput: ElementRef;
  @ViewChild('defectNumberInput') defectNumberInput: ElementRef;
  @ViewChild('jiraIdInput') jiraIdInput: ElementRef;
  @ViewChild('goLiveDateInput') goLiveDateInput: ElementRef;

  constructor(
    private formBuilder: FormBuilder,
    private defectService: DefectService,
    private authenticationService: AuthenticationService,
    private authService: AuthService,
    @Inject(ParallelProcessingService) private ppService,
    public snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ImpedimentCreateComponent>
  ) { }

  ngOnInit() {
    this.permissionMap = this.data.permissionMap;
    this.selectedTab = this.data.tab;
    this.initializeDefectForm(this.data.mode);
    this.getUsersFromService();
    this.populateDefectNumbers();
  }

  formName() {
    switch (this.data.mode) {
      case 'impediment':
        return 'Submit Impediment';
      case 'add':
        return 'Submit Defect';
      case 'edit':
        if (this.data.defect.status === 'impediment') {
          return 'Update Impediment';
        } else {
          return 'Update Defect';
        }
    }
  }

  initializeDefectForm(mode: string) {
    let editDefect: Defect;

    if (mode === 'edit') {
      editDefect = this.data.defect;
      // console.log(editDefect);
    } else {
      editDefect = Defect.newInstance();
      editDefect.status = 'impediment';
    }

    this.newDefectForm = this.formBuilder.group({
      id: new FormControl({ value: editDefect.id, disabled: true }, []),
      derivedDefectId: new FormControl(
        { value: editDefect.derivedDefectId, disabled: true },
        []
      ),
      jiraId: new FormControl(
        {
          value: editDefect.jiraId,
          disabled: this.checkEditDisabled('JIRA ID')
        },
        []
      ),
      impactedClaims: new FormControl(
        {
          value: editDefect.impactedClaims,
          disabled: this.checkEditDisabled('IMPACTED CLAIMS')
        },
        []
      ),
      assignedSme: new FormControl(
        {
          value: editDefect.assignedSme,
          disabled: this.checkEditDisabled('ASSIGNED SME')
        },
        [Validators.required]
      ),
      defectNumber: new FormControl(
        {
          value: editDefect.defectNumber,
          disabled: this.checkEditDisabled('AED ID')
        },
        []
      ),
      shortDescription: new FormControl(
        {
          value: editDefect.shortDescription,
          disabled: this.checkEditDisabled('SHORT DESCRIPTION')
        },
        [Validators.required]
      ),
      status: new FormControl(
        {
          value: editDefect.status,
          disabled: this.checkEditDisabled('STATUS')
        },
        [Validators.required]
      ),
      workstream: new FormControl(
        {
          value: editDefect.workstream,
          disabled: this.checkEditDisabled('WORK STREAM')
        },
        [Validators.required]
      ),
      defectDescription: new FormControl(
        {
          value: editDefect.defectDescription,
          disabled: this.checkEditDisabled('DEFECT DESCRIPTION')
        },
        [Validators.required]
      ),
      rxcexplncat: new FormControl(
        {
          value: editDefect.rxcexplncat,
          disabled: this.checkEditDisabled('RXC EXPLAINABLE DIFFERENCE')
        },
        [Validators.required]
      ),
      rxclocalmsg: new FormControl(
        {
          value: editDefect.rxclocalmsg,
          disabled: this.checkEditDisabled('RXC LOCAL MESSAGE')
        },
        []
      ),
      rxccomments: new FormControl(
        {
          value: editDefect.rxccomments,
          disabled: this.checkEditDisabled('RXC COMMENTS')
        },
        []
      ),
      antProductDescription: new FormControl(
        {
          value: editDefect.antProductDescription,
          disabled: this.checkEditDisabled('ANTHEM PRODUCT DESCRIPTION')
        },
        [Validators.required]
      ),
      fileTypes: new FormControl(
        {
          value: editDefect.fileTypes,
          disabled: this.checkEditDisabled('FILE TYPES')
        },
        [Validators.required]
      ),
      lob: new FormControl(
        { value: editDefect.lob, disabled: this.checkEditDisabled('LOBs') },
        [Validators.required]
      ),
      antRejectCodes: new FormControl(
        {
          value: editDefect.antRejectCodes,
          disabled: this.checkEditDisabled('ANTHEM REJECT CODES')
        },
        []
      ),
      rxRejectCodes: new FormControl(
        {
          value: editDefect.rxRejectCodes,
          disabled: this.checkEditDisabled('RX REJECT CODES')
        },
        []
      ),
      statesPlans: new FormControl(
        {
          value: editDefect.statesPlans,
          disabled: this.checkEditDisabled('STATES OF COVERAGE')
        },
        []
      ),
      withCVSPendingWork: new FormControl(
        {
          value: editDefect.withCVSPendingWork,
          disabled: this.checkEditDisabled('WITH CVS PENDING WORK')
        },
        []
      ),
      trackedInModelParallel: new FormControl(
        {
          value: editDefect.trackedInModelParallel,
          disabled: this.checkEditDisabled('TRACKED IN MODEL OFFICE')
        },
        []
      ),
      reason: new FormControl(
        {
          value: editDefect.reason,
          disabled: this.checkEditDisabled('REASON FOR D/R')
        },
        []
      ),
      testerReasoning: new FormControl(
        {
          value: editDefect.testerReasoning,
          disabled: this.checkEditDisabled('TESTER REASONING')
        },
        []
      ),
      associatedFiles: new FormControl(
        {
          value: editDefect.associatedFiles,
          disabled: this.checkEditDisabled('ASSOCIATED FILES')
        },
        []
      ),
      reportedBy: new FormControl(
        { value: editDefect.reportedBy, disabled: true },
        []
      ),
      assignDateCVS: new FormControl(
        { value: null, disabled: this.checkEditDisabled('ASSIGN DATE CVS') },
        []
      ),
      goLiveDate: new FormControl({ value: editDefect.goLiveDate, disabled: this.checkEditDisabled('FLEX 1') }, []),
      statusNotes: new FormControl({ value: editDefect.statusNotes, disabled: this.checkEditDisabled('FLEX 1') }, []),
      projectOwner: new FormControl({ value: editDefect.projectOwner, disabled: this.checkEditDisabled('FLEX 1') }, []),
      implementationDate: new FormControl({ value: editDefect.implementationDate, disabled: this.checkEditDisabled('FLEX 1') }, []),
      closeDateCVS: new FormControl({ value: null, disabled: true }, []),
      createDate: new FormControl({ value: null, disabled: true }, []),
      closeDate: new FormControl({ value: null, disabled: true }, []),
      dateOfService: new FormControl({ value: null, disabled: this.checkEditDisabled('DATE OF SERVICE') }, []),
      validUntilDate: new FormControl(
        { value: null, disabled: this.checkEditDisabled('STATUS VALID UNTIL') },
        []
      ),
      memberImpact: new FormControl(
        {
          value: editDefect.memberImpact,
          disabled: this.checkEditDisabled('FLEX 1')
        },
        []
      ),
      flex1: new FormControl(
        { value: editDefect.flex1, disabled: this.checkEditDisabled('FLEX 1') },
        []
      ),
      flex2: new FormControl(
        { value: editDefect.flex2, disabled: this.checkEditDisabled('FLEX 2') },
        []
      ),
      flex3: new FormControl(
        { value: editDefect.flex3, disabled: this.checkEditDisabled('FLEX 3') },
        []
      ),
      flex4: new FormControl(
        { value: editDefect.flex4, disabled: this.checkEditDisabled('FLEX 4') },
        []
      ),
      flex5: new FormControl(
        { value: editDefect.flex5, disabled: this.checkEditDisabled('FLEX 5') },
        []
      )
    });

    if (editDefect.assignDateCVS) {
      this.newDefectForm.controls['assignDateCVS'].setValue(
        new Date(editDefect.assignDateCVS).toISOString()
      );
    }
    if (editDefect.closeDateCVS) {
      this.newDefectForm.controls['closeDateCVS'].setValue(
        new Date(editDefect.closeDateCVS).toISOString()
      );
    }
    if (editDefect.closeDate) {
      this.newDefectForm.controls['closeDate'].setValue(
        new Date(editDefect.closeDate).toISOString()
      );
    }
    if (editDefect.createDate) {
      this.newDefectForm.controls['createDate'].setValue(
        new Date(editDefect.createDate).toISOString()
      );
    }
    if (editDefect.dateOfService) {
      this.newDefectForm.controls['dateOfService'].setValue(
        new Date(editDefect.dateOfService).toISOString()
      );
    }
    if (editDefect.validUntilDate) {
      this.newDefectForm.controls['validUntilDate'].setValue(
        new Date(editDefect.validUntilDate).toISOString()
      );
    }
    if (editDefect.status === 'impediment') {
      this.newDefectForm.controls['impactedClaims'].setValue(null);
    }
    // console.log(this.newDefectForm.controls);

    if (editDefect.statesPlans === undefined) {
      this.newDefectForm.controls['statesPlans'].setValue(new Array<string>());
    }
    this.initEditChips(editDefect);

    this.filteredStates = this.newDefectForm.controls[
      'statesPlans'
    ].valueChanges.pipe(
      startWith(''),
      map(value =>
        this.states.filter(state =>
          value
            ? state.toLowerCase().includes(value.toString().toLowerCase())
            : this.states
        )
      )
    );

    this.filteredLOBs = this.newDefectForm.controls['lob'].valueChanges.pipe(
      startWith(''),
      map(value =>
        this.lobs.filter(lob =>
          value
            ? lob.toLowerCase().includes(value.toString().toLowerCase())
            : this.lobs
        )
      )
    );

    this.filteredDefectNumbers = this.newDefectForm.controls[
      'defectNumber'
    ].valueChanges.pipe(
      startWith(''),
      map(value =>
        this.defectNumbers.filter(dn =>
          value
            ? dn.toLowerCase().includes(value.toString().toLowerCase())
            : this.defectNumbers
        )
      )
      // map(value => typeof value === 'string' ? value : value.defectNumber),
      // map(defectNumber => defectNumber ? this._defectnumberfilter(defectNumber) : this.defectNumbers.slice())
    );

    this.filteredUsers = this.newDefectForm.controls[
      'assignedSme'
    ].valueChanges.pipe(
      startWith(''),
      map(value =>
        this.smeArray.filter(sme =>
          value
            ? sme.toLowerCase().includes(value.toString().toLowerCase())
            : this.smeArray
        )
      )
    );
  }

  changeClient(value: string) {
    if (value === 'closed') {
      this.newDefectForm.controls['closeDate'].setValue(
        new Date().toISOString());
    }
    if (value !== 'closed') {
      this.newDefectForm.controls['closeDate'].setValue(null);
    }
  }

  checkEditDisabled(permissionName: string): boolean {
    const actions = this.permissionMap.get(permissionName);

    if (actions && actions.includes('EDIT')) {
      return false;
    }

    return true;
  }

  initEditChips(defect: Defect) {
    this.stateChips = this.newDefectForm.controls['statesPlans'].value;
    this.rxrCodeChips = this.newDefectForm.controls['rxRejectCodes'].value;
    this.newDefectForm.controls['rxRejectCodes'].setValue(new Array<string>());
    this.antCodeChips = this.newDefectForm.controls['antRejectCodes'].value;
    this.newDefectForm.controls['antRejectCodes'].setValue(new Array<string>());
    this.lobChips = this.newDefectForm.controls['lob'].value;
    this.fileTypeChips = this.newDefectForm.controls['fileTypes'].value;
    this.fileChips = this.newDefectForm.controls['associatedFiles'].value;
    this.goLiveDateChips = this.newDefectForm.controls['goLiveDate'].value;
    this.newDefectForm.controls['goLiveDate'].setValue(new Array<string>());
    this.newDefectForm.controls['associatedFiles'].setValue(
      new Array<string>()
    );

    if (this.newDefectForm.controls['defectNumber'].value) {
      this.defectNumberChips = this.newDefectForm.controls[
        'defectNumber'
      ].value.split(' ');
    }
    if (this.newDefectForm.controls['jiraId'].value) {
      this.jiraIdChips = this.newDefectForm.controls['jiraId'].value.split(' ');
    }
  }

  submit() {
    const derivedDefectId = this.getDerivedDefectId();
    this.newDefectForm.controls['derivedDefectId'].setValue(derivedDefectId);

    let joinedDefectNumbers = '';
    let joinedJiraIds = '';

    joinedDefectNumbers = this.defectNumberChips.join(' ').trim();
    joinedJiraIds = this.jiraIdChips.join(' ').trim();

    this.newDefectForm.controls['defectNumber'].setValue(joinedDefectNumbers);
    this.newDefectForm.controls['jiraId'].setValue(joinedJiraIds);


    if (this.data.mode === 'edit') {
      this.submitUpdate();
    } else {
      this.submitCreate();
    }
  }

  submitCreate() {

    const  loggedinUser  =  localStorage.getItem('firstName')  +  ' '  +  localStorage.getItem('lastName');
    this.newDefectForm.controls['reportedBy'].patchValue(loggedinUser);

        /* fix for IE11 = empty arraycontrol are passed as string that cauee error in IE */
        let arrValue =  this.newDefectForm.controls['rxRejectCodes'].value;
        if ((null == arrValue) || (arrValue.length <= 0)) {
          this.newDefectForm.controls['rxRejectCodes'].setValue(this.initArray);
        }

        arrValue =  this.newDefectForm.controls['antRejectCodes'].value;
        if ((null == arrValue) || (arrValue.length <= 0)) {
          this.newDefectForm.controls['antRejectCodes'].setValue(this.initArray);
        }
        this.newDefectForm.controls['antRejectCodes'].setValue(this.antCodeChips);

        arrValue =  this.newDefectForm.controls['associatedFiles'].value;
        if ((null == arrValue) || (arrValue.length <= 0)) {
          this.newDefectForm.controls['associatedFiles'].setValue(this.initArray);
        }

        arrValue =  this.newDefectForm.controls['goLiveDate'].value;
        if ((null == arrValue) || (arrValue.length <= 0)) {
          this.newDefectForm.controls['goLiveDate'].setValue(this.initArray);
        }
        /*End IE fix */

    this.defectService
      .addDefect(this.newDefectForm.getRawValue(), this.boolAED)
      .subscribe(
        (succ: Defect) => {
          this.snackBar.open('Successfully created defect.', 'Close', {
            duration: 3000
          });
          this.ppService
            .defectSpinSummary(succ.derivedDefectId, status)
            .subscribe(data => console.log(data));
          this.dialogRef.close(succ);
        },
        err => {
          this.snackBar.open('Failed to create defect.', 'Close', {
            duration: 3000
          });
          this.dialogRef.close();
        }
      );
  }

  submitUpdate() {
    this.newDefectForm.controls['antRejectCodes'].setValue(this.antCodeChips);
    this.newDefectForm.controls['rxRejectCodes'].setValue(this.rxrCodeChips);

    /* fix for IE11 = empty arraycontrol are passed as string that cauee error in IE */
    let arrValue =  this.newDefectForm.controls['rxRejectCodes'].value;
    if ((null == arrValue) || (arrValue.length <= 0)) {
      this.newDefectForm.controls['rxRejectCodes'].setValue(this.initArray);
    }

    arrValue =  this.newDefectForm.controls['antRejectCodes'].value;
    if ((null == arrValue) || (arrValue.length <= 0)) {
      this.newDefectForm.controls['antRejectCodes'].setValue(this.initArray);
    }
    this.newDefectForm.controls['antRejectCodes'].setValue(this.antCodeChips);

    arrValue =  this.newDefectForm.controls['associatedFiles'].value;
    if ((null == arrValue) || (arrValue.length <= 0)) {
      this.newDefectForm.controls['associatedFiles'].setValue(this.initArray);
    }

    arrValue =  this.newDefectForm.controls['goLiveDate'].value;
    if ((null == arrValue) || (arrValue.length <= 0)) {
      this.newDefectForm.controls['goLiveDate'].setValue(this.initArray);
    }
    /*End IE fix */

    this.defectService
      .editDefect(this.newDefectForm.getRawValue(), this.boolAED)
      .subscribe(
        (succ: Defect) => {
          this.snackBar.open('Successfully updated defect.', 'Close', {
            duration: 3000
          });

          this.dialogRef.close(succ);

          const derivedDefectId = this.newDefectForm.controls['derivedDefectId']
            .value;
          const status = this.newDefectForm.controls['status'].value;
          this.ppService
            .defectSpinSummary(derivedDefectId, status)
            .subscribe(data => console.log(data));
        },
        err => {
          this.snackBar.open('Failed to update defect.', 'Close', {
            duration: 3000
          });
          this.dialogRef.close();
        }
      );
  }

  getDerivedDefectId(): string {
    let derivedDefectId = '';

    const jiraId = this.newDefectForm.controls['jiraId'].value;
    const defectNumber = this.newDefectForm.controls['defectNumber'].value;
    const impedimentId = this.newDefectForm.controls['id'].value;

    if (defectNumber) {
      derivedDefectId += defectNumber + ' ';
    }
    if (jiraId) {
      derivedDefectId += jiraId;
    }

    derivedDefectId = derivedDefectId.trim();

    if (!derivedDefectId) {
      return impedimentId;
    }

    return derivedDefectId;
  }

  getUsersFromService() {
    this.authenticationService.loadTestUsers().subscribe(succ => {
      this.smeArray = succ.map(a => a.firstName + ' ' + a.lastName);
    });
  }

  getLOBs() {
    const lobArr = new Array<string>(4);
    let i = 0;
    while (i < this.newDefectForm.controls['associatedFiles'].value.length) {
      const lob = this.newDefectForm.controls['associatedFiles'].value[i]
        .lineOfBusiness;
      if (lob.includes('comm')) {
        lobArr[0] = 'Comm';
      } else if (lob.includes('caid')) {
        lobArr[1] = 'Caid';
      } else if (lob.includes('Ex')) {
        lobArr[2] = 'Ex';
      } else if (lob.includes('care')) {
        lobArr[3] = 'Care';
      }
      i++;
    }
    this.newDefectForm.controls['lob'].setValue(lobArr);
  }

  generateAED() {
    if (!this.checkEditDisabled('AED ID')) {
      if (!this.boolAED) {
        this.newDefectForm.controls['defectNumber'].setValue('');
        this.newDefectForm.controls['defectNumber'].disable();
        this.boolAED = true;
      } else {
        this.newDefectForm.controls['defectNumber'].enable();
        this.boolAED = false;
      }
    }
  }

  populateDefectNumbers() {
    this.defectService.getAllDefectNumbers().subscribe(succ => {
      for (const d of succ) {
        if (d.defectNumber !== '') {
          if (!this.defectNumbers.includes(d.defectNumber)) {
            this.defectNumbers.push(d.defectNumber);
          }
        }
      }
    });
  }

  private _userfilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.smeArray.filter(user =>
      user.toLowerCase().includes(filterValue)
    );
  }

  private _defectnumberfilter(value: string): string[] {
    const filterValue = value.toLowerCase();
    return this.defectNumbers.filter(dn =>
      dn.toLowerCase().includes(filterValue)
    );
  }

  selectAllStates() {
    this.stateChips = this.states;
    this.newDefectForm.controls['statesPlans'].setValue(this.states);
  }

  removeAllStates() {
    this.stateChips = [];
    this.newDefectForm.controls['statesPlans'].setValue(new Array<string>());
  }

  selectAllLOBs() {
    this.lobChips = this.lobs;
    this.newDefectForm.controls['lob'].setValue(this.lobChips);
  }

  removeAllLOBs() {
    this.lobChips = [];
    this.newDefectForm.controls['lob'].setValue(new Array<string>());
  }

  removeDefectNumber(defectNumber: string): void {
    const index = this.defectNumberChips.indexOf(defectNumber);
    if (index >= 0) {
      this.defectNumberChips.splice(index, 1);
    }
  }

  removeJiraId(jiraId: string): void {
    const index = this.jiraIdChips.indexOf(jiraId);
    if (index >= 0) {
      this.jiraIdChips.splice(index, 1);
    }
  }

  stateInputBlur() {
    this.stateInput.nativeElement.value = '';
  }

  defectNumberInputBlur() {
    this.defectNumberInput.nativeElement.value = '';
  }

  jiraIdInputBlur() {
    const val = this.jiraIdInput.nativeElement.value;
    if (val !== '') {
      this.jiraIdAdd({ input: this.jiraIdInput.nativeElement, value: val });
    }
    this.jiraIdInput.nativeElement.value = '';
  }

  lobInputBlur() {
    this.lobInput.nativeElement.value = '';
  }

  fileTypeInputBlur() {
    this.fileTypeInput.nativeElement.value = '';
  }

  rxrCodeInputBlur() {
    const val = this.rxrCodeInput.nativeElement.value;
    // console.log('code', val);
    if (val !== '') {
      this.rxrCodeAdd({ input: this.rxrCodeInput.nativeElement, value: val });
    }
    this.rxrCodeInput.nativeElement.value = '';
  }

  antCodeInputBlur() {
    const val = this.antCodeInput.nativeElement.value;
    // console.log('code', val);
    if (val !== '') {
      this.antCodeAdd({ input: this.antCodeInput.nativeElement, value: val });
    }
    this.antCodeInput.nativeElement.value = '';
  }

  goLiveDateInputBlur() {
    const val = this.goLiveDateInput.nativeElement.value;
    // console.log('code', val);
    if (val !== '') {
      this.goLiveDateInput.nativeElement.value = '';
    }
  }

  fileInputBlur() {
    const val = this.fileInput.nativeElement.value;
    // console.log('code', val);
    if (val !== '') {
      this.fileAdd({ input: this.fileInput.nativeElement, value: val });
    }
    this.fileInput.nativeElement.value = '';
  }

  removeState(state: string): void {
    if (this.checkEditDisabled('STATES OF COVERAGE')) {
      return;
    }
    const index = this.stateChips.indexOf(state);
    if (index >= 0) {
      this.stateChips.splice(index, 1);
    }
  }

  removeLob(lob: string): void {
    if (this.checkEditDisabled('LOBs')) {
      return;
    }
    const index = this.lobChips.indexOf(lob);
    if (index >= 0) {
      this.lobChips.splice(index, 1);
    }
  }

  removeFileType(fileType: string): void {
    if (this.checkEditDisabled('FILE TYPES')) {
      return;
    }
    const index = this.fileTypeChips.indexOf(fileType);
    if (index >= 0) {
      this.fileTypeChips.splice(index, 1);
    }
  }

  removeRXRCode(code: string): void {
    if (this.checkEditDisabled('RX REJECT CODES')) {
      return;
    }
    const index = this.rxrCodeChips.indexOf(code);
    if (index >= 0) {
      this.rxrCodeChips.splice(index, 1);
    }
  }

  removeGoLiveDate(code: string): void {
    const index = this.goLiveDateChips.indexOf(code);
    if (index >= 0) {
      this.goLiveDateChips.splice(index, 1);
    }
  }

  removeAntCode(code: string): void {
    if (this.checkEditDisabled('ANTHEM REJECT CODES')) {
      return;
    }
    const index = this.antCodeChips.indexOf(code);
    if (index >= 0) {
      this.antCodeChips.splice(index, 1);
    }
  }

  removeFile(code: string): void {
    const index = this.fileChips.indexOf(code);
    if (index >= 0) {
      this.fileChips.splice(index, 1);
    }
  }

  stateClick() {
    this.newDefectForm.controls['statesPlans'].setValue(this.stateChips);
  }

  lobClick() {
    this.newDefectForm.controls['lob'].setValue(this.lobChips);
  }

  fileTypeClick() {
    this.newDefectForm.controls['fileTypes'].setValue(this.fileTypeChips);
  }

  defectNumberClick() {
    this.newDefectForm.controls['defectNumber'].setValue(
      this.defectNumberChips.join(' ').trim()
    );
  }

  jiraIdClick() {
    this.newDefectForm.controls['jiraId'].setValue(
      this.jiraIdChips.join(' ').trim()
    );
  }

  rxrCodeAdd(event: MatChipInputEvent) {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.rxrCodeChips.push(value.trim());
      this.newDefectForm.controls['rxRejectCodes'].setValue(this.rxrCodeChips);
    }

    if (input) {
      input.value = '';
    }
  }

  antCodeAdd(event: MatChipInputEvent) {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.antCodeChips.push(value.trim());
      this.newDefectForm.controls['antRejectCodes'].setValue(this.antCodeChips);
    }

    if (input) {
      input.value = '';
    }
  }

  goLiveDateAdd(event: MatChipInputEvent) {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.goLiveDateChips.push(value.trim());
      this.newDefectForm.controls['goLiveDate'].setValue(this.goLiveDateChips);
    }

    if (input) {
      input.value = '';
    }
  }

  fileAdd(event: MatChipInputEvent) {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.fileChips.push(value);
      this.newDefectForm.controls['associatedFiles'].setValue(this.fileChips);
    }

    if (input) {
      input.value = '';
    }
  }

  defectNumberAdd(event: MatChipInputEvent) {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.defectNumberChips.push(value);
      this.newDefectForm.controls['defectNumber'].setValue(
        this.defectNumberChips
      );
    }

    if (input) {
      input.value = '';
    }
  }

  jiraIdAdd(event: MatChipInputEvent) {
    const input = event.input;
    const value = event.value;
    if ((value || '').trim()) {
      this.jiraIdChips.push(value);
      this.newDefectForm.controls['jiraId'].setValue(this.jiraIdChips);
    }

    if (input) {
      input.value = '';
    }
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.stateChips.push(event.option.value);
    this.removable = true;
    this.stateInput.nativeElement.value = '';
    this.newDefectForm.controls['statesPlans'].setValue(this.stateChips);
  }

  selectedLob(event: MatAutocompleteSelectedEvent): void {
    this.lobChips.push(event.option.value);
    this.removable = true;
    this.lobInput.nativeElement.value = '';
    this.newDefectForm.controls['lob'].setValue(this.lobChips);
  }

  selectedFileType(event: MatAutocompleteSelectedEvent): void {
    this.fileTypeChips.push(event.option.value);
    this.removable = true;
    this.fileTypeInput.nativeElement.value = '';
    this.newDefectForm.controls['fileTypes'].setValue(this.fileTypeChips);
  }

  selectedFile(event: MatAutocompleteSelectedEvent): void {
    this.fileChips.push(event.option.value);
    this.removableFiles = true;
    this.fileInput.nativeElement.value = '';
    this.newDefectForm.controls['associatedFiles'].setValue(this.fileChips);
  }

  selectedDefectNumber(event: MatAutocompleteSelectedEvent): void {
    this.defectNumberChips.push(event.option.value);
    this.removable = true;
    this.defectNumberInput.nativeElement.value = '';
    this.newDefectForm.controls['defectNumber'].setValue(
      this.defectNumberChips
    );
  }

  selectedJiraId(event: MatAutocompleteSelectedEvent): void {
    this.jiraIdChips.push(event.option.value);
    this.removable = true;
    this.jiraIdInput.nativeElement.value = '';
    this.newDefectForm.controls['jiraId'].setValue(this.jiraIdChips);
  }

  selectedSme(event: MatAutocompleteSelectedEvent): void { }

  displayFnUser(user?: TacUser): string {
    return user ? user.firstName + ' ' + user.lastName : '';
  }

  displayFnDefectNumber(dn?: Defect): string {
    return dn ? dn.defectNumber : '';
  }
}

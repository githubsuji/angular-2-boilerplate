import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PpreportsComponent } from './ppreports.component';

describe('PpreportsComponent', () => {
  let component: PpreportsComponent;
  let fixture: ComponentFixture<PpreportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PpreportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PpreportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

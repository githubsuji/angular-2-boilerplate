import { Component, OnInit, ViewEncapsulation, Query, Inject, ChangeDetectorRef } from '@angular/core';
import { BatchTypeInfoModel } from '../../../../model/testautomation/BatchTypeInfo';
import { StateList } from '../../../../model/testautomation/StateList';
import { BatchInfoModel } from '../../../../model/testautomation/BatchInfo';
import { BatchParameterInfo } from '../../../../model/testautomation/BatchParameterInfo';
import { StndBatchFileMeta } from '../../../../model/testautomation/StndBatchFileMedia';
import { FormBuilder, FormControl, Validators, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { BatchReport } from '../../../../model/testautomation/BatchReport';
import { BusinessFunctionalTestingService } from '../../../../../shared/services/business-functional-testing.service';
import { SharedMessageService } from '../../../../../shared/data-bus/shared-message-services/shared-message.service';


@Component({
  selector: 'app-create-batch',
  templateUrl: './create-batch.component.html',
  styleUrls: ['./create-batch.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CreateBatchComponent implements OnInit {
  batchList: BatchTypeInfoModel[];
  selectedBatch: BatchTypeInfoModel;
  batchType: string;
  isEnableQueryOutputContainer: Boolean = false;
  isEnableCalimvalidContainer: Boolean = false;
  stateList: StateList[];
  selectedState: StateList;
  batchInfo: BatchInfoModel;
  batchParameterInfo: BatchParameterInfo;

  stndQueryOutputFileFileMeta: StndBatchFileMeta;
  stndMedispanFileMeta: StndBatchFileMeta;
  stndFormularyReportFileMeta: StndBatchFileMeta;

  // disableUploadButton: boolean;
  errors: any[];
  userId: string;
  warningError: boolean;
  errorTemplate: boolean;
  selectedFiles: StndBatchFileMeta[];
  currentFileUpload: File;
  selectedFiles_medispan: FileList;
  currentFileUpload_medispan: File;
  currentFileUpload_formulary: File;
  selectedFiles_formulary: FileList;
  selectedFiles_query: FileList;
  currentFileUpload_query: FileList;
  disableUploadButtonMedispan: boolean;
  disableUploadButtonFormulary: boolean;
  disableUploadButtonQuery: boolean;
  batchInfoString: string;
  fileUploadedList: File[];
  fileTypeArr: File[];
  medispanText: any;
  formularyText: string;
  queryText: string;
  message: string;
  stateControl = new FormControl(null, [Validators.required]);
  formularyControl = new FormControl(null, []);
  isNoFileSelected: Boolean = true;
  queryFiles = new FormControl('');
  formularyFiles = new FormControl('');
  medispanFiles = new FormControl('');
  router: Router;
  fileTypeFormulary: string;
  fileTypeQuery: string;
  fileTypeMedispan: string;
  selectedFormularyReport: BatchReport;
  reportList: any;
  medispanReportList: any;
  formularyReportList: any;
  selectedMedispanReport: BatchReport;
  disableButtonFormularyReport: boolean;
  disableButtonMedispanReport: boolean;
  medispanControl = new FormControl(null, []);
  warningUpload: string;
  isEnableBenefitContainer: Boolean = false;

  constructor(@Inject(BusinessFunctionalTestingService) private bftService,
    private formBuilder: FormBuilder,
    router: Router, @Inject(ChangeDetectorRef) private cdr,
    @Inject(SharedMessageService) private sharedMessageService) {
    this.router = router;
  }

  ngOnInit() {
    this.loadBatchDropDownList();
    this.disableUploadButtonFormulary = true;
    this.disableUploadButtonMedispan = true;
    this.disableUploadButtonQuery = true;
    this.disableButtonMedispanReport = true;
    this.disableButtonFormularyReport = true;
    this.isNoFileSelected = true;
    this.loadStateList();
    this.loadFormularyReport();
    this.loadMedispanReport();
    this.clearAllErrMsg();
  }

  loadBatchDropDownList() {
    this.selectedBatch = BatchTypeInfoModel.newInstance();
    this.batchList = [];
    this.bftService.loadbatchList().subscribe(data => {
      this.batchList = data;
      
      if (this.batchList && this.batchList.length) {
        for (const list of this.batchList) {
           if ((list.name).indexOf('Clinical Formulary Query Output') > -1) {
            if (list.requiredFileTypes && list.requiredFileTypes.length) {
              this.fileTypeFormulary = list.requiredFileTypes[1].fileType + '';
              this.fileTypeMedispan = list.requiredFileTypes[2].fileType + '';
              this.fileTypeQuery = list.requiredFileTypes[0].fileType + '';
              this.formularyText = list.requiredFileTypes[1].name + '';
              this.medispanText = list.requiredFileTypes[2].name + '';
              this.queryText = list.requiredFileTypes[0].name + '';
            }
          }
          if ((list.name).indexOf('Clinical Formulary Claim Validation') > -1) {
            if (list.requiredFileTypes && list.requiredFileTypes.length) {
              this.sharedMessageService.sendMessage(list.requiredFileTypes, 'clinicalBatchTypeArrSubject');
            }
          }
          if ((list.name).indexOf('Benefits Query Validation') > -1) {
            if (list.requiredFileTypes && list.requiredFileTypes.length) {
              this.sharedMessageService.sendMessage(list.requiredFileTypes, 'benefitBatchTypeArrSubject');
            }
          }
        }
      }
    });
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    if (this.batchList && this.batchList.length) {
      localStorage.setItem('batchTypeArr', null);
    }
  }
  sourceDropDownChange(val: string) {
    this.batchType = val;
    if (this.batchType === 'Clinical Formulary Query Output') {
      this.isEnableQueryOutputContainer = true;
      this.isEnableCalimvalidContainer = false;
      this.isEnableBenefitContainer = false;
    } else if (this.batchType === 'Clinical Formulary Claim Validation') {
      this.isEnableQueryOutputContainer = false;
      this.isEnableCalimvalidContainer = true;
      this.isEnableBenefitContainer = false;
    } else if (this.batchType === 'Benefits Query Validation') {
      this.isEnableQueryOutputContainer = false;
      this.isEnableCalimvalidContainer = false;
      this.isEnableBenefitContainer = true;
    } else {
      this.isEnableQueryOutputContainer = false;
      this.isEnableCalimvalidContainer = false;
      this.isEnableBenefitContainer = false;
    }
  }

  loadStateList() {
    this.selectedState = StateList.newInstance();
    this.bftService.loadStateList().subscribe(data => {
      this.stateList = data;
    });
  }

  uploadBatchFiles() {
    this.batchInfo = BatchInfoModel.newInstance();
    this.batchParameterInfo = BatchParameterInfo.newInstance();

    this.stndQueryOutputFileFileMeta = StndBatchFileMeta.newInstance();
    this.stndMedispanFileMeta = StndBatchFileMeta.newInstance();
    this.stndFormularyReportFileMeta = StndBatchFileMeta.newInstance();

    this.batchInfo.batchParams = [];
    this.batchInfo.fileMetadata = [];
    this.fileUploadedList = [];
    const userModel = JSON.parse(localStorage.getItem('userModel'));
    this.userId = userModel.userId;
    this.batchInfo.userId = this.userId;
    this.batchInfo.batchType = this.batchType;
    this.batchParameterInfo.name = 'State';
    this.batchParameterInfo.value = this.selectedState.value;
    this.batchInfo.batchParams.push(this.batchParameterInfo);
    // formulary
    if (null != this.currentFileUpload_formulary) {
      this.stndFormularyReportFileMeta.fileNames.push(this.currentFileUpload_formulary.name);
      this.fileUploadedList.push(this.currentFileUpload_formulary);
    } else if (this.selectedFormularyReport) {
      this.stndFormularyReportFileMeta.fileNames.push(this.selectedFormularyReport.fileName);
    }
    this.stndFormularyReportFileMeta.fileType = this.fileTypeFormulary;
    // medispan
    if (null != this.currentFileUpload_medispan) {
      this.stndMedispanFileMeta.fileNames.push(this.currentFileUpload_medispan.name);
      this.fileUploadedList.push(this.currentFileUpload_medispan);
    } else if (this.selectedMedispanReport) {
      this.stndMedispanFileMeta.fileNames.push(this.selectedMedispanReport.fileName);
    }
    this.stndMedispanFileMeta.fileType = this.fileTypeMedispan;
    // query output
    if (null != this.currentFileUpload_query) {
      for (let i = 0; i < this.currentFileUpload_query.length; i++) {
        this.stndQueryOutputFileFileMeta.fileNames.push(this.currentFileUpload_query[i].name);
        this.stndQueryOutputFileFileMeta.fileType = this.fileTypeQuery;
        this.fileUploadedList.push(this.currentFileUpload_query[i]);
      }
    }
    // batch metadata
    this.batchInfo.fileMetadata.push(this.stndQueryOutputFileFileMeta);
    this.batchInfo.fileMetadata.push(this.stndMedispanFileMeta);
    this.batchInfo.fileMetadata.push(this.stndFormularyReportFileMeta);
    this.batchInfoString = JSON.stringify(this.batchInfo);

    this.bftService.uploadBatchFiles(this.fileUploadedList, this.batchInfoString).subscribe(data => {
      const dataFileResponse = data;
      this.router.navigate(['/landing/batch-list/'], { queryParams: { batchID: dataFileResponse.id } });
    },
      error => {
        console.log('error!');
        this.message = 'Unexpected Error Occurred!';
      });
    this.selectedFiles = undefined;
  }


  enableUploadQuery() {
    this.disableUploadButtonQuery = false;
    this.clearAllErrMsg();
  }

  enableUploadFormulary() {
    this.disableUploadButtonFormulary = false;
    this.clearAllErrMsg();
  }

  enableUploadMedispan() {
    this.disableUploadButtonMedispan = false;
    this.clearAllErrMsg();
  }

  enableFormularyReport() {
    this.disableButtonFormularyReport = false;
    this.clearAllErrMsg();
  }

  enableMedispanReport() {
    this.disableButtonMedispanReport = false;
    this.clearAllErrMsg();
  }

  doCancel() {
    this.selectedState = StateList.newInstance();
    this.selectedMedispanReport = BatchReport.newInstance();
    this.selectedFormularyReport = BatchReport.newInstance();
    this.queryFiles.reset();
    this.formularyFiles.reset();
    this.medispanFiles.reset();
    this.router.navigate(['/landing/batch-list'], { queryParams: { batchID: '' } });
  }

  clearMedispan() {
    this.selectedMedispanReport = BatchReport.newInstance();
    this.medispanFiles.reset();
    this.medispanControl.reset();
    this.cdr.detectChanges();
    this.disableButtonMedispanReport = true;
    this.disableUploadButtonMedispan = true;
    this.clearAllErrMsg();
  }

  clearFormulary() {
    this.selectedFormularyReport = BatchReport.newInstance();
    this.formularyFiles.reset();
    this.formularyControl.reset();
    this.cdr.detectChanges();
    this.disableUploadButtonFormulary = true;
    this.disableButtonFormularyReport = true;
    this.clearAllErrMsg();
  }

  clearAllErrMsg() {
    this.warningUpload = '';
    this.message = '';
    this.warningError = false;
  }

  selectFileQuery(event) {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      if ((file.type === 'application/vnd.ms-excel') ||
        (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {
        this.warningError = false;
        this.disableUploadButtonQuery = false;
        this.checkForUploadButtonEnable();
      } else {
        this.warningError = true;
        // this.disableUploadButton = true;
      }
    }
    this.errorTemplate = false;
    this.selectedFiles_query = event.target.files;
    if (this.currentFileUpload_query != null || this.currentFileUpload_query !== undefined) {
      this.currentFileUpload_query = null;
    }
    this.currentFileUpload_query = (this.selectedFiles_query);
  }

  selectFileFormulary(event) {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      if ((file.type === 'application/vnd.ms-excel') ||
        (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {
        this.warningError = false;
        // this.disableUploadButton = false;
        this.disableUploadButtonFormulary = false;
        this.checkForUploadButtonEnable();
      } else {
        this.warningError = true;
        // this.disableUploadButton = true;
      }
    }
    this.errorTemplate = false;
    this.selectedFiles_formulary = event.target.files;
    if (this.currentFileUpload_formulary != null || this.currentFileUpload_formulary !== undefined) {
      this.currentFileUpload_formulary = null;
    }
    this.currentFileUpload_formulary = this.selectedFiles_formulary.item(0);
  }


  selectFileMedispan(event) {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      if ((file.type === 'application/vnd.ms-excel') ||
        (file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')) {
        this.warningError = false;
        this.disableUploadButtonMedispan = false;
        this.checkForUploadButtonEnable();
      } else {
        this.warningError = true;
        // this.disableUploadButton = true;
      }
    }
    this.errorTemplate = false;
    this.selectedFiles_medispan = event.target.files;
    if (this.currentFileUpload_medispan != null || this.currentFileUpload_medispan !== undefined) {
      this.currentFileUpload_medispan = null;
    }
    this.currentFileUpload_medispan = this.selectedFiles_medispan.item(0);
  }

  checkForUploadButtonEnable() {
    this.clearAllErrMsg();
    if ((!this.disableUploadButtonFormulary && !this.disableButtonFormularyReport)) {
      this.clearFormulary();
      this.warningUpload = 'Formulary';
      this.isNoFileSelected = true;
    } else if ((!this.disableUploadButtonMedispan && !this.disableButtonMedispanReport)) {
      this.clearMedispan();
      this.warningUpload = 'Medispan';
      this.isNoFileSelected = true;
    } else if (this.disableUploadButtonQuery ||
      (this.disableUploadButtonMedispan && this.disableButtonMedispanReport) ||
      (this.disableUploadButtonFormulary && this.disableButtonFormularyReport)) {
      this.isNoFileSelected = true;
    } else {
      this.isNoFileSelected = false;
    }
  }

  loadFormularyReport() {
    this.selectedFormularyReport = BatchReport.newInstance();
    if (this.selectedFormularyReport.fileName) {
      this.enableFormularyReport();
    }
    this.bftService.getFormularyReport().subscribe(data => {
      this.formularyReportList = data;
      if (this.formularyReportList && this.formularyReportList.length) {
        this.fileTypeFormulary = this.formularyReportList[0].fileType + '';
      }
    });
  }

  loadMedispanReport() {
    this.selectedMedispanReport = BatchReport.newInstance();
    if (this.selectedMedispanReport.fileName) {
      this.enableMedispanReport();
    }
    this.bftService.getMedispanReport().subscribe(data => {
      this.medispanReportList = data;
      if (this.medispanReportList && this.medispanReportList.length) {
        this.fileTypeMedispan = this.medispanReportList[0].fileType + '';
      }
    });
  }

  onChangeMedispanReport(event) {
    if (event.value && event.value.fileName) {
      this.disableButtonMedispanReport = false;
      this.checkForUploadButtonEnable();
    }
  }

  onChangeFormularyReport(event) {
    if (event.value && event.value.fileName) {
      this.disableButtonFormularyReport = false;
      this.checkForUploadButtonEnable();
    }
  }

}

import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { BatchTypeInfoModel } from '../../../../model/testautomation/BatchTypeInfo';
import { StndBatchFileMeta } from '../../../../model/testautomation/StndBatchFileMedia';
import { BatchInfoModel } from '../../../../model/testautomation/BatchInfo';
import { BatchParameterInfo } from '../../../../model/testautomation/BatchParameterInfo';
import { BusinessFunctionalTestingService } from '../../../../../shared/services/business-functional-testing.service';
import { SharedMessageService } from '../../../../../shared/data-bus/shared-message-services/shared-message.service';


export interface DropDownList {
  value: string;
  name: string;
}

@Component({
  selector: 'app-claim-validation',
  templateUrl: './claim-validation.component.html',
  styleUrls: ['./claim-validation.component.css']
})
export class ClaimValidationComponent implements OnInit {


  lobList: DropDownList[] = [
    { value: 'Commercial', name: 'LOB' },
    { value: 'Exchange', name: 'LOB' },
    { value: 'Medicaid', name: 'LOB' },
    { value: 'Medicare', name: 'LOB' }
  ];

  validationCriteriaList: DropDownList[] = [
    { value: 'MOB', name: 'ValidationCriteria' },
    { value: 'New Build/Catchup', name: 'ValidationCriteria' }
  ];

  validationScenarioList: DropDownList[] = [
    { value: 'FM-Tier with PA Formulary', name: 'ValidationScenario' },
    { value: 'FM-Tier without PA Formulary', name: 'ValidationScenario' }
    // { value: 'FM-NC NF scenarios', name: 'ValidationScenario' },
    // { value: 'UM-PA without LBP', name: 'ValidationScenario' },
    // { value: 'UM-PA with LBP', name: 'ValidationScenario' },
    // { value: 'UM-QVT', name: 'ValidationScenario' },
    // { value: 'UM-step therapy', name: 'ValidationScenario' },
    // { value: 'UM-smart edit', name: 'ValidationScenario' }
  ];

  router: Router;
  message: string;

  isEnableLoadXML: Boolean = false;
  clinicalFormularyClaimvalid: FormGroup;
  batchList: BatchTypeInfoModel[];
  fileUploadedList: File[];

  selectedLOB: BatchParameterInfo;
  selectedCriteria: BatchParameterInfo;
  selectedScenario: BatchParameterInfo;

  loadRTMFileMeta: StndBatchFileMeta;
  loadReqFileMeta: StndBatchFileMeta;
  loadClaimOutputFileMeta: StndBatchFileMeta;
  loadXMLFileMeta: StndBatchFileMeta;

  currentFileUpload_Req: File;
  currentFileUpload_RTM: File;
  currentFileUpload_Claim: FileList;
  currentFileUpload_XML: File;

  selectedFiles_Req: FileList;
  selectedFiles_RTM: FileList;
  selectedFiles_Claim: FileList;
  selectedFiles_XML: FileList;

  fileTypeRTM: string;
  fileTypeRequirement: string;
  fileTypeOutput: string;
  fileTypeBenefit: string;

  batchInfoModel: BatchInfoModel;
  batchParams: BatchParameterInfo[];
  fileMetaData: StndBatchFileMeta[];

  batchInfoString: string;
  sharedMessageServiceClinicalSubscriber: any;
  requiredFileTypes: any;
  constructor(@Inject(BusinessFunctionalTestingService) private btfService,
    private formBuilder: FormBuilder, router: Router,
    @Inject(SharedMessageService) private sharedMessageService
  ) {
    this.router = router;
  }

  ngOnInit() {

    this.clinicalFormularyClaimvalid = new FormGroup({
      lob: new FormControl('', [Validators.required]),
      validCriteria: new FormControl('', [Validators.required]),
      validScenario: new FormControl('', [Validators.required]),
      uploadFiles: new FormGroup({
        loadReq: new FormControl('', [Validators.required]),
        loadRtm: new FormControl('', [Validators.required]),
        loadOutputFiles: new FormControl('', [Validators.required]),
        loadXml: new FormControl('')
      })
    });

    this.loadBatchDropDownList();
    this.selectedLOB = BatchParameterInfo.newInstance();
    this.selectedLOB.value = 'Commercial';

    this.selectedCriteria = BatchParameterInfo.newInstance();
    this.selectedCriteria.value = 'MOB';
  }

  scenarioDropDownChange(target) {
    // const scenario = target.find(e => e.value === 'FM-NC NF scenarios');

    if ( target.value === 'FM-NC NF scenarios') {
      // if (target.includes('FM-NC NF scenarios')) {
      this.isEnableLoadXML = true;
    } else {
      this.isEnableLoadXML = false;
    }
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.clinicalFormularyClaimvalid.controls[controlName].hasError(errorName);
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    if (this.sharedMessageServiceClinicalSubscriber) {
      this.sharedMessageServiceClinicalSubscriber.unsubscribe();
    }
  }
  loadBatchDropDownList() {
    this.sharedMessageService.createSubject('clinicalBatchTypeArrSubject');
    this.sharedMessageServiceClinicalSubscriber = this.sharedMessageService.getMessage('clinicalBatchTypeArrSubject').subscribe((data: any) => {
      // console.log('Data Received', data);
      if (data != null) {
        this.requiredFileTypes = data.data;
        if (this.requiredFileTypes && this.requiredFileTypes.length) {
          this.fileTypeRTM = this.requiredFileTypes[1].fileType + '';
          this.fileTypeRequirement = this.requiredFileTypes[3].fileType + '';
          this.fileTypeOutput = this.requiredFileTypes[0].fileType + '';
          this.fileTypeBenefit = this.requiredFileTypes[2].fileType + '';
        }
      }
    });
  }

  uploadFiles() {
    this.fileUploadedList = [];
    this.batchInfoModel = BatchInfoModel.newInstance();
    this.loadClaimOutputFileMeta = StndBatchFileMeta.newInstance();
    this.loadRTMFileMeta = StndBatchFileMeta.newInstance();
    this.loadReqFileMeta = StndBatchFileMeta.newInstance();
    this.loadXMLFileMeta = StndBatchFileMeta.newInstance();

    const userId = localStorage.getItem('userId');
    this.batchInfoModel.userId = userId;
    this.batchInfoModel.batchType = 'Clinical Formulary Claim Validation';
    this.selectedLOB.name = 'LOB';
    this.selectedCriteria.name = 'ValidationCriteria';
    this.batchParams = [];
    this.batchInfoModel.fileMetadata = [];
    this.batchParams.push(this.selectedCriteria);
    this.batchParams.push(this.selectedLOB);
    // this.batchInfoModel.batchParams = this.batchParams.concat(this.selectedScenario);
    this.batchParams.push(this.selectedScenario);
    this.batchInfoModel.batchParams = this.batchParams;
    if (null !== this.currentFileUpload_Req && undefined !== this.currentFileUpload_Req) {
      this.loadReqFileMeta.fileNames.push(this.currentFileUpload_Req.name);
      this.fileUploadedList.push(this.currentFileUpload_Req);
      this.loadReqFileMeta.fileType = this.fileTypeRequirement;
      this.batchInfoModel.fileMetadata.push(this.loadReqFileMeta);
    }

    if (null !== this.currentFileUpload_RTM && undefined !== this.currentFileUpload_RTM) {
      this.loadRTMFileMeta.fileNames.push(this.currentFileUpload_RTM.name);
      this.fileUploadedList.push(this.currentFileUpload_RTM);
      this.loadRTMFileMeta.fileType = this.fileTypeRTM;
      this.batchInfoModel.fileMetadata.push(this.loadRTMFileMeta);
    }

    if (null !== this.currentFileUpload_Claim && undefined !== this.currentFileUpload_Claim) {
      for (let i = 0; i < this.currentFileUpload_Claim.length; i++) {
        this.loadClaimOutputFileMeta.fileNames.push(this.currentFileUpload_Claim[i].name);
        this.loadClaimOutputFileMeta.fileType = this.fileTypeOutput;
        this.fileUploadedList.push(this.currentFileUpload_Claim[i]);

      }
      this.batchInfoModel.fileMetadata.push(this.loadClaimOutputFileMeta);
    }


    if (null !== this.currentFileUpload_XML && undefined !== this.currentFileUpload_XML) {
      this.loadXMLFileMeta.fileNames.push(this.currentFileUpload_XML.name);
      this.fileUploadedList.push(this.currentFileUpload_XML);
      this.loadXMLFileMeta.fileType = this.fileTypeBenefit;
      this.batchInfoModel.fileMetadata.push(this.loadXMLFileMeta);
    }

    this.batchInfoString = JSON.stringify(this.batchInfoModel);
    this.btfService.uploadBatchFiles(this.fileUploadedList, this.batchInfoString).subscribe(data => {
      const dataFileResponse = data;
      this.router.navigate(['/landing/batch-list/'], { queryParams: { batchID: dataFileResponse.id } });
    },
      error => {
        console.log('error!');
        this.message = 'Unexpected Error Occurred!';
      });

  }

  selectFileReq(event) {
    this.selectedFiles_Req = event.target.files;
    this.currentFileUpload_Req = this.selectedFiles_Req.item(0);
  }

  selectFileRTM(event) {
    this.selectedFiles_RTM = event.target.files;
    this.currentFileUpload_RTM = this.selectedFiles_RTM.item(0);
  }

  selectFileClaim(event) {
    this.selectedFiles_Claim = event.target.files;
    this.currentFileUpload_Claim = this.selectedFiles_Claim;
  }

  selectFileXML(event) {
    this.selectedFiles_XML = event.target.files;
    this.currentFileUpload_XML = this.selectedFiles_XML.item(0);
  }

  doCancel() {
    this.selectedLOB = BatchParameterInfo.newInstance();
    this.selectedCriteria = BatchParameterInfo.newInstance();
    this.selectedScenario = BatchParameterInfo.newInstance();
    this.router.navigate(['/landing/batch-list'], { queryParams: { batchID: '' } });
  }
}

import { Component, OnInit, Inject } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { BusinessFunctionalTestingService } from '../../../../../shared/services/business-functional-testing.service';
import { BatchTypeInfoModel } from '../../../../model/testautomation/BatchTypeInfo';
import { StndBatchFileMeta } from '../../../../model/testautomation/StndBatchFileMedia';
import { BatchInfoModel } from '../../../../model/testautomation/BatchInfo';
import { BatchParameterInfo } from '../../../../model/testautomation/BatchParameterInfo';
import { SharedMessageService } from '../../../../../shared/data-bus/shared-message-services/shared-message.service';
import { DropDownList } from '../claim-validation/claim-validation.component';

@Component({
  selector: 'app-benefit-query-validation',
  templateUrl: './benefit-query-validation.component.html',
  styleUrls: ['./benefit-query-validation.component.css']
})
export class BenefitQueryValidationComponent implements OnInit {

  lobList: DropDownList[] = [
    { value: 'Commercial', name: 'LOB' },
    { value: 'Exchange', name: 'LOB' },
    { value: 'Medicaid', name: 'LOB' },
    { value: 'Medicare', name: 'LOB' }
  ];

  batchList: BatchTypeInfoModel[];
  fileUploadedList: File[];
  batchInfoModel: BatchInfoModel;
  batchParams: BatchParameterInfo[];
  fileMetaData: StndBatchFileMeta[];
  benefitTestingValidation: FormGroup;
  router: Router;
  batchInfoString: string;
  message: string;

  fileTypeRTM: string;
  fileTypeHCR: string;
  fileTypeBenefit: string;
  fileTypeQuery: string;
  fileTypeDrugX: string;
  fileTypeSpider: string;

  fileNameRTM: string;
  fileNameHCR: string;
  fileNameBenefit: string;
  fileNameQuery: string;
  fileNameDrugX: string;
  fileNameSpider: string;

  selectedFiles_RTM: FileList;
  selectedFiles_HCR: FileList;
  selectedFiles_benefit: FileList;
  selectedFiles_query: FileList;
  selectedFiles_spider: FileList;
  selectedFiles_drug: FileList;

  currentFileUpload_drug: File;
  currentFileUpload_RTM: File;
  currentFileUpload_benefit: File;
  currentFileUpload_query: File;
  currentFileUpload_spider: File;
  currentFileUpload_HCR: File;

  loadRTMFileMeta: StndBatchFileMeta;
  loadQueryFileMeta: StndBatchFileMeta;
  loadBenefitFileMeta: StndBatchFileMeta;
  loadDrugFileMeta: StndBatchFileMeta;
  loadHCRFileMeta: StndBatchFileMeta;
  loadSpiderFileMeta: StndBatchFileMeta;
  requiredFileTypesArr: any[];
  sharedMessageServiceBenefitSubscriber: any;
  requiredFileTypes: any;

  selectedLOB: BatchParameterInfo;

  constructor(@Inject(BusinessFunctionalTestingService) private bftService,
    private formBuilder: FormBuilder, router: Router,
    @Inject(SharedMessageService) private sharedMessageService) {
    this.router = router;
  }
  ngOnInit() {
    this.benefitTestingValidation = new FormGroup({
      uploadFiles: new FormGroup({
        lob: new FormControl('', [Validators.required]),
        loadRTM: new FormControl('', [Validators.required]),
        loadQuery: new FormControl('', [Validators.required]),
        loadHCR: new FormControl('', [Validators.required]),
        loadDrugX: new FormControl('',[Validators.required]),
        loadBenefit: new FormControl('',[Validators.required]),
        loadSpider: new FormControl('',[Validators.required]),
      })
    });
    this.loadBatchDropDownList();
     this.selectedLOB = BatchParameterInfo.newInstance();
     this.selectedLOB.value = 'Commercial';
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    if (this.sharedMessageServiceBenefitSubscriber) {
      this.sharedMessageServiceBenefitSubscriber.unsubscribe();
    }
  }
  loadBatchDropDownList() {
    this.sharedMessageService.createSubject('benefitBatchTypeArrSubject');
    this.sharedMessageServiceBenefitSubscriber = this.sharedMessageService.getMessage('benefitBatchTypeArrSubject').subscribe((data: any) => {
      console.log('Data Received', data);
      if (data != null) {
        this.requiredFileTypes = data.data;
        if (this.requiredFileTypes && this.requiredFileTypes.length) {
          this.fileTypeRTM = this.requiredFileTypes[0].fileType + '';
          this.fileTypeQuery = this.requiredFileTypes[1].fileType + '';
          this.fileTypeHCR = this.requiredFileTypes[3].fileType + '';
          this.fileTypeBenefit = this.requiredFileTypes[5].fileType + '';
          this.fileTypeDrugX = this.requiredFileTypes[2].fileType + '';
          this.fileTypeSpider = this.requiredFileTypes[4].fileType + '';

          this.fileNameRTM = this.requiredFileTypes[0].name + '';
          this.fileNameQuery = this.requiredFileTypes[1].name + '';
          this.fileNameHCR = this.requiredFileTypes[3].name + '';
          this.fileNameBenefit = this.requiredFileTypes[5].name + '';
          this.fileNameDrugX = this.requiredFileTypes[2].name + '';
          this.fileNameSpider = this.requiredFileTypes[4].name + '';
        }
      }
    });
  }

  uploadFiles() {
    this.fileUploadedList = [];
    this.batchInfoModel = BatchInfoModel.newInstance();
    this.loadBenefitFileMeta = StndBatchFileMeta.newInstance();
    this.loadDrugFileMeta = StndBatchFileMeta.newInstance();
    this.loadHCRFileMeta = StndBatchFileMeta.newInstance();
    this.loadQueryFileMeta = StndBatchFileMeta.newInstance();
    this.loadRTMFileMeta = StndBatchFileMeta.newInstance();
    this.loadSpiderFileMeta = StndBatchFileMeta.newInstance();

    const userId = localStorage.getItem('userId');
    this.batchInfoModel.userId = userId;
    this.batchInfoModel.batchType = 'Benefits Query Validation';
    this.selectedLOB.name = 'LOB';
    this.batchParams = [];
    this.batchInfoModel.fileMetadata = [];
    this.batchParams.push(this.selectedLOB);
    this.batchInfoModel.batchParams = this.batchParams;

    if (null !== this.currentFileUpload_RTM && undefined !== this.currentFileUpload_RTM) {
      this.loadRTMFileMeta.fileNames.push(this.currentFileUpload_RTM.name);
      this.fileUploadedList.push(this.currentFileUpload_RTM);
      this.loadRTMFileMeta.fileType = this.fileTypeRTM;
      this.batchInfoModel.fileMetadata.push(this.loadRTMFileMeta);
    }
    if (null !== this.currentFileUpload_query && undefined !== this.currentFileUpload_query) {
      this.loadQueryFileMeta.fileNames.push(this.currentFileUpload_query.name);
      this.fileUploadedList.push(this.currentFileUpload_query);
      this.loadQueryFileMeta.fileType = this.fileTypeQuery;
      this.batchInfoModel.fileMetadata.push(this.loadQueryFileMeta);
    }
    if (null !== this.currentFileUpload_drug && undefined !== this.currentFileUpload_drug) {
      this.loadDrugFileMeta.fileNames.push(this.currentFileUpload_drug.name);
      this.fileUploadedList.push(this.currentFileUpload_drug);
      this.loadDrugFileMeta.fileType = this.fileTypeDrugX;
      this.batchInfoModel.fileMetadata.push(this.loadDrugFileMeta);
    }
    if (null !== this.currentFileUpload_HCR && undefined !== this.currentFileUpload_HCR) {
      this.loadHCRFileMeta.fileNames.push(this.currentFileUpload_HCR.name);
      this.fileUploadedList.push(this.currentFileUpload_HCR);
      this.loadHCRFileMeta.fileType = this.fileTypeHCR;
      this.batchInfoModel.fileMetadata.push(this.loadHCRFileMeta);
    }
    if (null !== this.currentFileUpload_spider && undefined !== this.currentFileUpload_spider) {
      this.loadSpiderFileMeta.fileNames.push(this.currentFileUpload_spider.name);
      this.fileUploadedList.push(this.currentFileUpload_spider);
      this.loadSpiderFileMeta.fileType = this.fileTypeSpider;
      this.batchInfoModel.fileMetadata.push(this.loadSpiderFileMeta);
    }
    if (null !== this.currentFileUpload_benefit && undefined !== this.currentFileUpload_benefit) {
      this.loadBenefitFileMeta.fileNames.push(this.currentFileUpload_benefit.name);
      this.fileUploadedList.push(this.currentFileUpload_benefit);
      this.loadBenefitFileMeta.fileType = this.fileTypeBenefit;
      this.batchInfoModel.fileMetadata.push(this.loadBenefitFileMeta);
    }
    this.batchInfoString = JSON.stringify(this.batchInfoModel);
    this.bftService.uploadBatchFiles(this.fileUploadedList, this.batchInfoString).subscribe(data => {
      const dataFileResponse = data;
      this.router.navigate(['/landing/batch-list/'], { queryParams: { batchID: dataFileResponse.id } });
    },
      error => {
        console.log('error!');
        this.message = 'Unexpected Error Occurred!';
      });


  }
  selectFileRTM(event) {
    this.selectedFiles_RTM = event.target.files;
    this.currentFileUpload_RTM = this.selectedFiles_RTM.item(0);
  }

  selectFileQuery(event) {
    this.selectedFiles_query = event.target.files;
    this.currentFileUpload_query = this.selectedFiles_query.item(0);
  }
  selectFileHCR(event) {
    this.selectedFiles_HCR = event.target.files;
    this.currentFileUpload_HCR = this.selectedFiles_HCR.item(0);
  }

  selectFileDrug(event) {
    this.selectedFiles_drug = event.target.files;
    this.currentFileUpload_drug = this.selectedFiles_drug.item(0);
  }

  selectFileBenefit(event) {
    this.selectedFiles_benefit = event.target.files;
    this.currentFileUpload_benefit = this.selectedFiles_benefit.item(0);
  }

  selectFileSpider(event) {
    this.selectedFiles_spider = event.target.files;
    this.currentFileUpload_spider = this.selectedFiles_spider.item(0);
  }

  doCancel() {
    this.router.navigate(['/landing/batch-list'], { queryParams: { batchID: '' } });
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.benefitTestingValidation.controls[controlName].hasError(errorName);
  }

}

import { Component, OnInit, ViewEncapsulation, Inject } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SimpleColumn } from '../../../simple-search-table/simple-search-table.component';
import { Subscription } from 'rxjs/Subscription';
import { MatSnackBar } from '@angular/material';
import { StndBatchFileMeta } from '../../../../model/testautomation/StndBatchFileMedia';
import { BusinessFunctionalTestingService } from '../../../../../shared/services/business-functional-testing.service';

@Component({
  selector: 'app-validation-results',
  templateUrl: './validation-results.component.html',
  styleUrls: ['./validation-results.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class ValidationResultsComponent implements OnInit {


  busy: Subscription;
  isLoading: boolean;
  router: Router;

  batchResObj: any;
  batchId: string;
  batchResults: any[];
  batchResFileDetails: StndBatchFileMeta[];
  batchResultColumns: SimpleColumn[] = [
    // { displayName: 'space0', fieldName: '', class: 'cell-32px', type: null, functionCond: null, function: null, icon: null, iconColor: null },
    { displayName: 'Batch File', fieldName: 'id', class: 'cell-420px', type: 'string', functionCond: null, function: null, icon: null, iconColor: null },
    { displayName: 'Total Records', fieldName: 'totalRecords', class: 'cell-96px-grow', type: 'string', functionCond: null, function: null, icon: null, iconColor: null },
    { displayName: '# Passed', fieldName: 'passed', class: 'cell-70px-grow', type: 'string', functionCond: null, function: null, icon: null, iconColor: null },
    { displayName: '# Failed', fieldName: 'failed', class: 'cell-70px-grow', type: 'string', functionCond: null, function: null, icon: null, iconColor: null },
    { displayName: 'Download Results', fieldName: '', class: 'cell-64px', type: null, functionCond: (a) => true, function: (a) => this.downloadFile(a), icon: 'get_app', iconColor: 'primary' },
    { displayName: 'Comments', fieldName: 'comments', class: 'cell-320px', type: 'string', functionCond: null, function: null, icon: null, iconColor: null },
  ];
  isBatchFailed: Boolean;

  constructor(@Inject(BusinessFunctionalTestingService) private bftService, private route: ActivatedRoute,
    private snackBar: MatSnackBar, router: Router) {
    this.router = router;
  }

  ngOnInit() {
    this.batchId = this.route.snapshot.queryParamMap.get('batchId');
   // console.log();
    this.isBatchFailed = false;
    this.getBatchResultsFromService();
  }


  getBatchResultsFromService() {
    this.bftService.getBatchResults(this.batchId).subscribe(data => {
      // console.log(data);
      this.batchResults = data.fileResults;
      this.batchResObj = data;
      this.batchResFileDetails = data.fileDetails;
      this.isBatchFailed = this.batchResObj && this.batchResObj.reason ? true : false;
    });
  }

  downloadFile(a: any) {
    const filename = this.batchId + '__' + a.id; // stnd_file id changed to batchid_filename
    this.busy = this.bftService.downloadResults(filename).subscribe(data => {
      // console.log('>>>> download');
     // console.log(data);
      if (data !== null) {
        if (window.navigator.msSaveOrOpenBlob) {
          // msSaveBlob only available for IE & Edge
          window.navigator.msSaveBlob(data.body, filename);
        } else {
          const blob = new Blob([data.body], { type: 'text/csv' });
          const downloadLink = document.createElement('a');
          downloadLink.href = URL.createObjectURL(blob);
          downloadLink.download = filename;
          document.body.appendChild(downloadLink);
          downloadLink.click();
        }

        this.isLoading = false;
        this.snackBar.open('Successfully Downloaded!!', 'Close', {
          duration: 3000
        });
      }
    },
      err => {
        this.isLoading = false;
        this.snackBar.open('Failed to Download!', 'Close', {
          duration: 3000
        });
      });
  }

  goToBatchList() {
    this.router.navigate(['/landing/batch-list']);
  }
}

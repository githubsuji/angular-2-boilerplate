import { Component, OnInit, Inject, ViewEncapsulation, AfterViewInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { TestAutomationBatchModel } from '../../../../model/testautomation/TestAutomationBatchModel';
import { SimpleColumn } from '../../../simple-search-table/simple-search-table.component';
import { BatchTypeInfoModel } from '../../../../model/testautomation/BatchTypeInfo';
import { BatchSearchRequestModel } from '../../../../model/testautomation/BatchSearchrequest';
import { errorHandler } from '@angular/platform-browser/src/browser';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BusinessFunctionalTestingService } from '../../../../../shared/services/business-functional-testing.service';


@Component({
  selector: 'app-batch-list',
  templateUrl: './batch-list.component.html',
  styleUrls: ['./batch-list.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BatchListComponent implements OnInit,  AfterViewInit, OnDestroy {

  // selectedBatch:BatchFileInfoModel;
  router: Router;
  searchData: BatchSearchRequestModel;
  batchDataModel: TestAutomationBatchModel;
  batchSearchRequest: BatchSearchRequestModel;
  batchSearchForm: FormGroup;
  isEnableBatchListTable = false;
  selected = true;
  isEnableErrorMsg = false;
  isEnableSearch = false;
  batchTypeInfoList: BatchTypeInfoModel[];
  batchList: BatchTypeInfoModel[];
  selectedBatch: BatchTypeInfoModel;
  testAutomationBatchModelList: TestAutomationBatchModel[];
  totalCount: string;
  messages: string;

  batchColumns: SimpleColumn[] = [
    // { displayName: 'space0', fieldName: '', class: 'cell-32px', type: null, functionCond: null, function: null, icon: null, iconColor: null },
    { displayName: 'Batch Id', fieldName: 'batchId', class: 'cell-320px', type: 'string', functionCond: null, function: null, icon: null, iconColor: null },
    { displayName: 'Batch Type', fieldName: 'batchType.name', class: 'cell-256px', type: 'json', functionCond: null, function: null, icon: null, iconColor: null },
    { displayName: 'Status', fieldName: 'status', class: 'cell-96px', type: 'string', functionCond: null, function: null, icon: null, iconColor: null },
    { displayName: 'Results', fieldName: '', class: 'cell-64px', type: null, functionCond: (a) => a.status === 'COMPLETE' || a.status === 'FAILED', function: (a) => this.viewBatchResults(a), icon: 'visibility', iconColor: 'primary' },
    { displayName: 'Reason', fieldName: 'reason', class: 'cell-238px', type: 'string', functionCond: null, function: null, icon: null, iconColor: null },
    { displayName: 'Last Modified Date', fieldName: 'lastModifiedDate', class: 'cell-192px', type: 'string', functionCond: null, function: null, icon: null, iconColor: null }
    // { displayName: 'date', fieldName: 'date', class: 'cell-160px', type: 'date', functionCond: null, function: null, icon: null, iconColor: null },
  ];
  // selectedBatch:BatchFileInfoModel;
  userId: string;
  createdBatchId: string = null;
  timeInterval: any;
  batchTypeInfo: BatchTypeInfoModel;


  constructor(@Inject(BusinessFunctionalTestingService) private bftService, private formBuilder: FormBuilder,
    private snackBar: MatSnackBar,
    router: Router, private activatedRoute: ActivatedRoute) {
    this.router = router;
  }

  ngOnInit() {
    window.scroll(0, 0);
    this.createdBatchId = null;
    this.activatedRoute.queryParams.subscribe((params) => {
        this.createdBatchId = params['batchID'];
        params = null;
  });

    this.searchData = BatchSearchRequestModel.newInstance();
    this.batchSearchRequest = BatchSearchRequestModel.newInstance();
    this.loadBatchDropDownList();
    this.batchSearchRequest.status = 'All';
    this.batchSearchRequest.batchType = 'All';
    this.userId = localStorage.getItem('userId');
    this.searchData.userId = this.userId;
    this.batchSearchRequest.userId = this.userId;
    // this.isEnableBatchListTable = true;
    this.loadBatchList();
    const timeOut = setTimeout(() => {
      this.initRefreshBathList();
      clearTimeout(timeOut);
    }, 20);
  }
  initRefreshBathList() {
    this.timeInterval = setInterval(() => {
      console.log(new Date().getMilliseconds());
      this.loadBatchList();
    }, 30000); // 30 sec
  }
  resetRefreshInterval() {
    if (this.timeInterval) {clearInterval(this.timeInterval); }
  }

  ngAfterViewInit(): void {
    if (this.createdBatchId != null && this.createdBatchId !== '') {
      setTimeout(() => {
      this.snackBar.open('Successfully Created Batch with BatchID : ' + this.createdBatchId, 'Close', {
        duration: 3000 });
      });
    }
  }
  ngOnDestroy(): void {
    this.resetRefreshInterval();
  }

  searchBatchList() {
    this.resetRefreshInterval();
    this.isEnableBatchListTable = false;
    this.messages = null;
    if ((this.batchSearchRequest.batchType === '' || this.batchSearchRequest.batchType === undefined) && (this.batchSearchRequest.status === '' || this.batchSearchRequest.status === undefined)) {
      this.isEnableErrorMsg = true;
    } else {
      this.searchData.batchType = this.batchSearchRequest.batchType;
      this.searchData.status = this.batchSearchRequest.status;
      if (this.batchSearchRequest.status === 'All') {
        this.searchData.status = '';
      }
      if (this.batchSearchRequest.batchType === 'All') {
        this.searchData.batchType = '';
      }
      this.loadBatchList();
      this.initRefreshBathList();
      // setTimeout(() => {
      //   this.sharedMessageService.sendMessage(this.batchSearchRequest, 'searchDataModel');
      // });

    }
  }

  loadBatchDropDownList() {
    this.batchTypeInfo = BatchTypeInfoModel.newInstance();
    this.selectedBatch = BatchTypeInfoModel.newInstance();
    this.bftService.loadbatchList().subscribe(data => {
      this.batchTypeInfoList = data;
      this.batchTypeInfo.name = 'All';
      this.batchTypeInfoList.push(this.batchTypeInfo);
      this.batchList = this.batchTypeInfoList;      
    });
  }

  loadBatchList() {
    this.isEnableBatchListTable = true;
    let mapresult: any;
    this.isEnableErrorMsg = false;
    this.bftService.getBatchList(this.searchData).subscribe(data => {
      mapresult = data;
      this.totalCount = mapresult.totalCount;
      this.testAutomationBatchModelList = mapresult.batchList;
      console.log(this.testAutomationBatchModelList);
    }, error => {
      this.messages = null;
      this.messages = 'No Batches Available !!!';
      this.isEnableBatchListTable = false;
    });
  }

  viewBatchResults(batch: TestAutomationBatchModel) {
    this.router.navigate(['/landing/batch-results'], { queryParams: { batchId: batch.batchId } });
  }

}
